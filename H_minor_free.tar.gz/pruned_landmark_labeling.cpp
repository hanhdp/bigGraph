#include <malloc.h>
#include <stdint.h>
#include <xmmintrin.h>
#include <sys/time.h>
#include <climits>
#include <iostream>
#include <sstream>
#include <string>
#include <vector>
#include <stack>
#include <queue>
#include <set>
#include <algorithm>
#include <fstream>
#include <utility>
#include <limits>
#include <omp.h>
#include "jlog.hpp"
#include "pruned_landmark_labeling.hpp"
using namespace std;

#define all(c) (c).begin(), (c).end()
#define iter(c) __typeof((c).begin())
#define cpresent(c, e) (find(all(c), (e)) != (c).end())
#define rep(i, n) for (int i = 0; i < (int)(n); i++)
#define tr(c, i) for (iter(c) i = (c).begin(); i != (c).end(); ++i)
#define pb(e) push_back(e)
#define mp(a, b) make_pair(a, b)


namespace {
  const double time_limit = 100;
  int max_threads;
  // Return the number of threads that would be executed in parallel regions
  int get_max_threads() {
#ifdef _OPENMP
    return omp_get_max_threads();
#else
    return 1;
#endif
  }

  // Set the number of threads that would be executed in parallel regions
  void set_num_threads(int num_threads) {
#ifdef _OPENMP
    omp_set_num_threads(num_threads);
#else
    if (num_threads != 1) {
      assert(!"compile with -fopenmp");
    }
#endif
  }

  int get_thread_id() {
#ifdef _OPENMP
    return omp_get_thread_num();
#else
    return 0;
#endif
  }

  template<typename T>
  struct parallel_vector {
    parallel_vector(size_t size_limit)
      : v(max_threads, vector<T>(size_limit)),
        n(max_threads, 0) {}

    void push_back(const T &x) {
      int id = get_thread_id();
      v[id][n[id]++] = x;
    }

    void clear() {
      for (int i = 0; i < max_threads; ++i) n[i] = 0;
    }

    vector<vector<T> > v;
    vector<size_t> n;
  };


  double GetCurrentTimeSec() {
    struct timeval tv;
    gettimeofday(&tv, NULL);
    return tv.tv_sec + tv.tv_usec * 1e-6;
  }

  long long GetMemoryUsage() {
    //  http://stackoverflow.com/questions/669438/how-to-get-memory-usage-at-run-time-in-c

    std::ifstream stat_stream("/proc/self/stat", std::ios_base::in);
    if (!stat_stream) {
      return 0;
    }

    std::string pid, comm, state, ppid, pgrp, session, tty_nr;
    std::string tpgid, flags, minflt, cminflt, majflt, cmajflt;
    std::string utime, stime, cutime, cstime, priority, nice;
    std::string O, itrealvalue, starttime;
    long long vm_usage, rss;

    stat_stream >> pid >> comm >> state >> ppid >> pgrp >> session >> tty_nr
    >> tpgid >> flags >> minflt >> cminflt >> majflt >> cmajflt
    >> utime >> stime >> cutime >> cstime >> priority >> nice
    >> O >> itrealvalue >> starttime >> vm_usage >> rss;
    stat_stream.close();

    // in bytes
    long long page_size = sysconf(_SC_PAGE_SIZE);
    long long resident_set = rss * page_size;

    return resident_set;
    // return vm_usage;
  }
}

const uint8_t PrunedLandmarkLabeling::INF8 = 100;  // We require |INF8 + INF8| fits in |uint8_t|
const uint32_t PrunedLandmarkLabeling::INF32 = std::numeric_limits<int32_t>::max();  // signed for safety
const int PrunedLandmarkLabeling::kInitialLabelCapacity = 8;

bool PrunedLandmarkLabeling
::ConstructIndex(const char *filename) {
  ifstream ifs(filename);
  return ifs && ConstructIndex(ifs);
}

bool PrunedLandmarkLabeling
::ConstructIndex(istream &ifs) {
  vector<pair<int, int> > es;
  for (int v, w; ifs >> v >> w; ) {
    es.push_back(make_pair(v, w));
  }
  if (ifs.bad()) return false;
  ConstructIndex(es);
  return true;
}

bool PrunedLandmarkLabeling
::ConstructIndex(const vector<pair<int, int> > &es) {
  time_indexing_ = -GetCurrentTimeSec();

  //
  // Prepare the adjacency list and index space
  //
  Free();
  time_load_ = -GetCurrentTimeSec();
  
  int &V = num_v_;
  V = 0;
  for (size_t i = 0; i < es.size(); ++i) {
    V = max(V, max(es[i].first, es[i].second) + 1);
  }
  rep(dir, 2){
    adj_[dir].resize(V);
  }
  
  for (size_t i = 0; i < es.size(); ++i) {
    int v = es[i].first, w = es[i].second;
    adj_[0][v].push_back(w);
    adj_[1][w].push_back(v);
  }
  time_load_ += GetCurrentTimeSec();

  rep(dir, 2){
    index_[dir] = (index_t*)memalign(64, V * sizeof(index_t));
    index_l_[dir] = V;
  }
  if (index_ == NULL) {
    num_v_ = 0;
    return false;
  }

  rep(dir, 2){
    for (int v = 0; v < V; ++v) {
      index_[dir][v].spt_v = NULL;
      index_[dir][v].spt_p = NULL;
      index_[dir][v].spt_d = NULL;
      index_[dir][v].spt_l = 0;
    }
  }
  
  //
  // Order vertices by decreasing order of degree
  //
  vector<int> &inv = ord_;  // new label -> old label
  vector<vector<int> > adj[2];  // Do not confuse with |adj_| (TODO: fix)
  rep(dir, 2){
    adj[dir].resize(V);
  }
  
  {
    // Order
    vector<pair<float, int> > deg(V);
    for (int v = 0; v < V; ++v) {
      // We add a random value here to diffuse nearby vertices
      deg[v] = make_pair(adj_[0][v].size()+adj_[1][v].size() + float(rand()) / RAND_MAX, v);
    }
    // puts("TODO: SORT");
    sort(deg.rbegin(), deg.rend());
    for (int i = 0; i < V; ++i) {
      int v = deg[i].second;
      if (!adj_[0][v].empty() || !adj_[1][v].empty()) inv.pb(v);  // We ignore isolated vertices here (to decide the ordering later)
    }

    // Relabel the vertex IDs
    vector<int> rank(V);
    for (int i = 0; i < V; ++i) rank[deg[i].second] = i;
    rep(dir, 2) rep(v, V){
      for (int w : adj_[dir][v]){
        adj[dir][rank[v]].push_back(rank[w]);
      }
    }
  }

  vector<bool> usd(V, false);  // Used as root? (in new label)

  //
  // Pruned labeling
  //
  max_threads = get_max_threads();
  {
    // Sentinel (V, INF8) is added to all the vertices
    vector<pair<vector<int>, vector<uint8_t> > > tmp_idx[2];
    vector<vector<int> > tmp_par[2];
    rep(dir, 2){
      tmp_idx[dir] = vector<pair<vector<int>, vector<uint8_t> > >
        (V, make_pair(vector<int>(1, INF32), vector<uint8_t>(1, INF8)));
      tmp_par[dir] = vector<vector<int> >(V, vector<int>(1, -1));
    }

    //vector<bool> vis(V);
    vector<uint8_t> vis(V / 8 + 1);
    vector<int> que_v(V);
    vector<int> que_p(V);
    vector<uint8_t> dst_r(V + 1, INF8);

    parallel_vector<int> pdiff_nxt_que_v(V);
    parallel_vector<int> pdiff_nxt_que_p(V);

    for (int r = 0; r < V; ++r) {
      if (r % 100 == 0 &&
          (GetCurrentTimeSec() + time_indexing_ > 30 ||
           GetMemoryUsage() > 8LL * 1024 * 1024 * 1024)) {
        cerr << "STOP INDEX CONSTRUCTION!!" << endl;
        break;
      }
      
      rep(dir, 2){
        if (usd[r] || (adj[dir][r].empty() && adj[!dir][r].empty())) continue;
      
        const auto &tmp_idx_r = tmp_idx[dir][r];
        for (size_t i = 0; i < tmp_idx_r.first.size() - 1; ++i) {
          dst_r[tmp_idx_r.first[i]] = tmp_idx_r.second[i];
        }

        int que_t0 = 0, que_t1 = 0, que_h = 0;
        que_v[que_h] = r;
        que_p[que_h] = -1;
        que_h++;
        vis[r / 8] |= 1 << (r % 8);
        que_t1 = que_h;
        
        for (int d = 0; que_t0 < que_h; ++d) {

#pragma omp parallel for schedule(guided, 1)
          for (int que_i = que_t0; que_i < que_t1; ++que_i) {
            int v = que_v[que_i];
            int p = que_p[que_i];
            auto &tmp_idx_v = tmp_idx[1 - dir][v];
            auto &tmp_idx_p = tmp_par[1 - dir][v];
            assert(v < (int)inv.size());

            // Prefetch
            _mm_prefetch(&tmp_idx_v.first[0], _MM_HINT_T0);
            _mm_prefetch(&tmp_idx_v.second[0], _MM_HINT_T0);

            // Prune?
            if (usd[v]) continue;
          
            for (size_t i = 0; i < tmp_idx_v.first.size() - 1; ++i) {
              int w  = tmp_idx_v.first[i];
              int td = tmp_idx_v.second[i] + dst_r[w];
              if (td <= d) goto pruned;
            }

            // Traverse
            tmp_idx_v.first .back() = r;
            tmp_idx_v.second.back() = d;
            tmp_idx_p.back() = p;
            tmp_idx_v.first .push_back(INF32);
            tmp_idx_v.second.push_back(INF8);
            tmp_idx_p.push_back(-1);

            for (int w : adj[dir][v]){
              for (;;) {
                uint8_t m = vis[w / 8];
                if (m & (1 << (w % 8))) break;
                if (__sync_bool_compare_and_swap(&vis[w / 8], m, m | (1 << (w % 8)))) {
                  pdiff_nxt_que_v.pb(w);
                  pdiff_nxt_que_p.pb(v);
                  break;
                }
              }
            }
          pruned:
            {}
          }

          for (int i = 0; i < max_threads; ++i) {
            for (int j = 0; j < (int)pdiff_nxt_que_v.n[i]; ++j) {
              que_v[que_h] = pdiff_nxt_que_v.v[i][j];
              que_p[que_h] = pdiff_nxt_que_p.v[i][j];
              que_h++;
            }
          }

          que_t0 = que_t1;
          que_t1 = que_h;
          pdiff_nxt_que_v.clear();
          pdiff_nxt_que_p.clear();
        }

        for (int i = 0; i < que_h; ++i) vis[que_v[i] / 8] = 0;
        for (size_t i = 0; i < tmp_idx_r.first.size() - 1; ++i) {
          dst_r[tmp_idx_r.first[i]] = INF8;
        }
      }
      usd[r] = true;
    }
    

    for (int v = 0; v < (int)inv.size(); ++v) {
      rep(dir, 2){
        int k = tmp_idx[dir][v].first.size();
        index_[dir][inv[v]].spt_v = (uint32_t*)memalign(64, k*sizeof(uint32_t));
        index_[dir][inv[v]].spt_p = (uint32_t*)memalign(64, k*sizeof(uint32_t));
        index_[dir][inv[v]].spt_d = (uint8_t *)memalign(64, k*sizeof(uint8_t ));
        index_[dir][inv[v]].spt_l = k;
        if (!index_[dir][inv[v]].spt_v || !index_[dir][inv[v]].spt_d || !index_[dir][inv[v]].spt_p) {
          Free();
          return false;
        }
        rep(i, k) index_[dir][inv[v]].spt_v[i] = tmp_idx[dir][v].first[i];
        rep(i, k) index_[dir][inv[v]].spt_p[i] = inv[tmp_par[dir][v][i]];
        rep(i, k) index_[dir][inv[v]].spt_d[i] = tmp_idx[dir][v].second[i];
        tmp_idx[dir][v].first.clear();
        tmp_idx[dir][v].second.clear();
        tmp_par[dir][v].clear();
      }
    }
    
    rep (i, V) rep(dir, 2) if (adj_[dir][i].empty() && adj_[!dir][i].empty()) {
      assert(index_[dir][i].spt_v == NULL);
      index_[dir][i].spt_v = (uint32_t*)memalign(64, 1 * sizeof(uint32_t));
      index_[dir][i].spt_p = (uint32_t*)memalign(64, 1 * sizeof(uint32_t));
      index_[dir][i].spt_d = (uint8_t *)memalign(64, 1 * sizeof(uint8_t ));
      index_[dir][i].spt_v[0] = INF32;
    }
  }

  time_indexing_ += GetCurrentTimeSec();
  return true;
}

vector<int> PrunedLandmarkLabeling
::QueryShortestPath(int v, int w) {
  if (v == w) return vector<int>(1, v);
  if (v >= num_v_ || w >= num_v_) return vector<int>();

  const index_t &idx_v = index_[0][v];
  const index_t &idx_w = index_[1][w];
  

  _mm_prefetch(&idx_v.spt_v[0], _MM_HINT_T0);
  _mm_prefetch(&idx_w.spt_v[0], _MM_HINT_T0);
  _mm_prefetch(&idx_v.spt_d[0], _MM_HINT_T0);
  _mm_prefetch(&idx_w.spt_d[0], _MM_HINT_T0);
  int best_dist  = INF8;
  int best_label = -1;
  
  for (int i1 = 0, i2 = 0; ; ) {
    uint32_t v1 = idx_v.spt_v[i1], v2 = idx_w.spt_v[i2];
    if (v1 == v2) {
      if (v1 == INF32) break;  // Sentinel
      // printf(" %d->%d->%d: %d+%d\n", v, ord_[v1], w, idx_v.spt_d[i1], idx_w.spt_d[i2]);
      int td = idx_v.spt_d[i1] + idx_w.spt_d[i2];
      if (td < best_dist){
        best_dist  = td;
        best_label = v1;
      }
      ++i1;
      ++i2;
    } else {
      i1 += v1 < v2 ? 1 : 0;
      i2 += v1 > v2 ? 1 : 0;
    }
  }
  
  if (best_dist >= INF8 - 2){
    return vector<int>();
  } else {
    assert(best_label != -1);
    vector<int> forward_p, backward_p;
    // forward_p.push_back(v);
    
    // while (v != best_label){
    //   const auto &iv = index_[0][v];
    //   int idx = lower_bound(iv.spt_v, iv.spt_v+iv.spt_l, best_label) - iv.spt_v;
    //   assert(int(iv.spt_v[idx]) == best_label);
    //   v = iv.spt_p[idx];
    //   forward_p.push_back(v);
    // }
    
    // backward_p.push_back(w);
    // while (w != best_label){
    //   const auto &iw = index_[1][w];
    //   int idx = lower_bound(iw.spt_v, iw.spt_v+iw.spt_l, best_label) - iw.spt_v;
    //   assert(int(iw.spt_v[idx]) == best_label);
    //   w = iw.spt_p[idx];
    //   backward_p.push_back(w);
    // }
    // assert(forward_p.back() == best_label && backward_p.back() == best_label);

    // reverse(backward_p.begin(), backward_p.end());
    // for (size_t i = 1; i < backward_p.size(); ++i){
    //   forward_p.push_back(backward_p[i]);
    // }
    return forward_p;
  }
}


void PrunedLandmarkLabeling
::Free() {
  rep(dir, 2) rep(v, num_v_){
    free(index_[dir][v].spt_v);
    free(index_[dir][v].spt_p);
    free(index_[dir][v].spt_d);
  }
  rep(dir, 2){
    free(index_[dir]);
    index_[dir] = NULL;
  }
  num_v_ = 0;
}


double PrunedLandmarkLabeling
::GetAverageLabelSize() {
  // cout << "load time: "     << time_load_     << " seconds" << endl;
  // cout << "indexing time: " << time_indexing_ << " seconds" << endl;
  double s = 0.0;
  for (int v = 0; v < num_v_; ++v) {
    rep(dir, 2){
      for (int i = 0; index_[dir][v].spt_v[i] != INF32; ++i) {
        ++s;
      }
    }
  }
  return s /= num_v_;
}
