#!/bin/bash
make clean
/bin/tar czf submission.tar.gz run.sh compile.sh package.sh README *.cpp *.hpp Makefile k-path-cover
