#ifndef DETERMINE_NETWORK_H
#define DETERMINE_NETWORK_H

#include <vector>

/*
  <average dist for connected pair, connected ratio in random query>
*/
std::pair<double, double> get_average_dist(int n, const std::vector<std::pair<int, int> >& es, int num_sample = 200);
  

#endif /* DETERMINE_NETWORK_H */
