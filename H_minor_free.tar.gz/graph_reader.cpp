#include "graph_reader.hpp"
#include <cstdio>
#include <cctype>
#include <iostream>
#include <algorithm>
using namespace std;

int GraphReader::Read(vector<pair<int, int> > &es){
  char c; int u, v, n = 0;
  es.clear();
  // es.reserve(20 * 1000 * 1000);
  while (true){
    while ((c = getc(stdin)) && isspace(c)){
      ;
    }
    
    if (c != 'S'){
      ungetc(c, stdin);
      scanf("%d%d", &u, &v);
      es.emplace_back(u, v);
      n = max({n, u + 1, v + 1});
    } else {
      break;
    }
  }
  return n;
}
