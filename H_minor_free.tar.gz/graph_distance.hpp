#ifndef GRAPH_DISTANCE_H
#define GRAPH_DISTANCE_H

#include <vector>
#include <tuple>
#include <set>
#include <map>
#include <array>
#include <stdint.h>
#include "two_level_queue.hpp"
#include "pruned_landmark_labeling.hpp"

#define fst first
#define snd second

class GraphDistance {
  typedef std::tuple<char, int, int> query_t;
  const uint32_t ALIVE   = 0;
  const uint32_t DEAD    = 1;
  const uint32_t UNKNOWN = 2;
  const uint32_t MASK    = 3;
  
  inline uint32_t GetID(uint32_t v) const { return v >> 2; }
  inline uint32_t GetEdgeState(uint32_t v) const { return v & MASK; }
  inline uint32_t ToEdge(uint32_t v) const { assert(v >= 0); return (v << 2) | ALIVE;}

  int connected_counter = 0;
  double update_time1 = 0;
  double update_time2 = 0;
  double query_time= 0;
  bool use_pll = true;

  std::vector<std::tuple<int, int, int, char> > updates; // <source, target, timestamp, type>
  std::vector<std::tuple<int, int, int> > queries; // <source, target, timestamp>
  std::map<char, int> query_counter;
  std::vector<std::vector<uint8_t> > Ds;
  std::vector<std::vector<uint32_t> > G[2], zeroG[2];
  std::vector<int> outdegree[2];
  std::vector<std::vector<TwoLevelQueue<int> > > Qs;
  std::vector<int> S[2];
  double time_connected = 0;
  double time_disconnected = 0;
  std::vector<int> forward_visit, backward_visit, st_dist;
  PrunedLandmarkLabeling pll;
  
  int inline QueryDistance(int u, int v, int time,
                           const std::vector<std::tuple<int, int, int, char> > &qs);
  void InsertEdgeIntoGraph(std::vector<uint32_t> &vs, uint32_t v, bool);
  void DeleteEdgeFromGraph(std::vector<uint32_t> &vs, uint32_t v, bool);
public:
  std::vector<int> ProcessBatch(const std::vector<query_t> &batch);
  void Build(int n, const std::vector<std::pair<int, int> > &es);
  ~GraphDistance();
  void NotUsePLL(){ use_pll = false; };
};

#endif /* GRAPH_DISTANCE_H */
