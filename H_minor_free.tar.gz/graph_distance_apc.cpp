#include <cassert>
#include <algorithm>
#include <omp.h>
#include "jlog.hpp"
#include "graph_distance_apc.hpp"

using namespace std;

namespace {

double update_time1 = 0;
double update_time2 = 0;
double update_time_collect_changed_vs = 0;
double update_time_manage_changed_vs = 0;
double query_time= 0;
double second_slowest_query_time = 0;
double fastest_thread = 0;
double omp_query = 0;
double process_batch_time = 0;
vector<double> last_step;
double original_graph_search = 0;
double overlay_graph_search = 0;

  bool inline Check(int v, int w, int time, uint32_t state,
                    const vector<tuple<int, int, int, char> > &qs){
    
    auto iter = lower_bound(qs.begin(), qs.end(), make_tuple(v, w, time, 0));
    if (qs.empty() || iter == qs.begin()){
      return (state & 1) == 0;
    }
    
    auto last = *(--iter);
    if (v == get<0>(last) && w == get<1>(last)){
      return get<3>(last) == 'A';
    } else {
      return (state & 1) == 0;
    }
  }
}


int GraphDistanceApc::QueryDistance(int s, int t, int time,
                                 const vector<tuple<int, int, int, char> > &qs){
  double start = jlog_internal::get_current_time_sec();  
  if (s == t) {   return 0;  }

  auto &D = Ds[omp_get_thread_num()];
  auto &cost = costs[omp_get_thread_num()];
  const int D_unit = sizeof(D[0]) * 4;

  auto is_visit = [&](int v, int dir) {
    return D[v / D_unit] & (1 << (dir + v % D_unit * 2));
  };

  auto set_visit = [&](int v, int dir) -> void {
    D[v / D_unit] |= (1 << (dir + v % D_unit * 2));
  };
  
  auto & used_vs = used_vss[omp_get_thread_num()];
  used_vs.clear();
  int res = G[0].size() + 1;
  auto& PQ = PQs[omp_get_thread_num()];
  int max_cost[2] = {0, 0};
  int min_cost[2] = {0, 0};
  int num_visit[2] = {0, 0};
  
  {
    queue<pair<int, int> > q;
    for (int dir = 0; dir < 2; dir++){
      int v = dir == 0 ? s : t;    
      q.push({0, v});
      used_vs.push_back(v);
      set_visit(v, dir);
      cost[dir][v] = 0;
      while (!q.empty()) {
        int cv = q.front().second;
        int cc = q.front().first;
        num_visit[dir]++;
        q.pop();
        
        if (cc + 1 >= res) continue;
        if (is_cover[cv]) {
          if (PQ[dir].size() < cc + 1u){
            PQ[dir].resize(cc + 1u);
          }
          max_cost[dir] = max(max_cost[dir], cc);
          PQ[dir][cc].push(cv);
          continue;
        }
      
        for (auto w_ : G[dir][cv]) {
          if (cc + 1 >= res) break;
          auto w = GetID(w_);
          if (is_visit(w, dir)) continue;
          uint32_t state = GetEdgeState(w_);

          if (state == ALIVE || ((state & UNKNOWN) &&
                                 (dir == 0 ?
                                  Check(cv, w, time, state, qs) :
                                  Check(w, cv, time, state, qs)))){
            if (is_visit(w, dir ^ 1)) {
              res = min(res, cc + 1 + cost[dir ^ 1][w]);
            }
            
            if ((int)(w) == (dir == 0 ? t : s))
              res = min(res, cc + 1);
            
            set_visit(w, dir);
            cost[dir][w] = cc + 1;
            q.push({cc + 1, w});
            used_vs.push_back(w);
          }
        }
      }
    }
  }

  original_graph_search += jlog_internal::get_current_time_sec() - start;
  start = jlog_internal::get_current_time_sec();
  
  while (min_cost[0] <= max_cost[0] &&
         min_cost[1] <= max_cost[1]){
    int dir = num_visit[0] <= num_visit[1] ? 0 : 1;
    int sum = min_cost[0] + min_cost[1];
    int cc  = min_cost[dir]++;
    auto &PQ_dir = PQ[dir];
    auto &C_dir  = cost[dir];
    const auto &OG = overlay_graph[dir];
      
    while (!PQ_dir[cc].empty()) {
      int cv = PQ_dir[cc].front(); PQ_dir[cc].pop();
      if (sum + 1 > res || C_dir[cv] < cc) continue;
      
      for (auto w_ : OG[cv]) {
        if (cc + 1 >= res) break;
        int next_cost = cc + w_.second;
        if (next_cost >= res) continue;
        auto w = GetID(w_.first);
        if (is_visit(w, dir) && C_dir[w] <= next_cost){
          continue;
        }
        
        uint32_t state = GetEdgeState(w_.first);
        if (state == ALIVE ||
            ((state & UNKNOWN) &&
             (dir == 0 ?
              Check(cv, w, time, state, qs) :
              Check(w, cv, time, state, qs)))){

          if (is_visit(w, dir ^ 1)) {
            res = min(res, next_cost + cost[dir ^ 1][w]);
          }
          
          if (next_cost + min_cost[dir ^ 1] < res) {
            if (!is_visit(w, dir) && !is_visit(w, dir ^ 1)){
              used_vs.push_back(w);
            }
            set_visit(w, dir);
            C_dir[w] = next_cost;
            if (PQ_dir.size() < C_dir[w] + 1u) {
              PQ_dir.resize(C_dir[w] + 1u);
            }
            max_cost[dir] = max<int>(max_cost[dir], C_dir[w]);
            PQ_dir[C_dir[w]].push(w);
            num_visit[dir]++;
          }
        }
      }
    }
  }

  for (int v : used_vs) {
    D[v / D_unit] = false;
  }
  for (int dir = 0; dir < 2; dir++){
    while (min_cost[dir] <= max_cost[dir]){
      while (!PQ[dir][min_cost[dir]].empty()){
        PQ[dir][min_cost[dir]].pop();
      }
      min_cost[dir]++;
    }
  }
  
  overlay_graph_search += jlog_internal::get_current_time_sec() - start;
  
  return res > (int)G[0].size() ? -1 : res;
}

void GraphDistanceApc::InsertEdgeIntoGraph(vector<uint32_t> &vs, uint32_t v, bool unknown){
  auto iter = lower_bound(vs.begin(), vs.end(), v);
  if (iter != vs.end() && GetID(*iter) == GetID(v)){
    if (unknown){
      *iter |= UNKNOWN;
    } else {
      *iter = ToEdge(GetID(v)) | ALIVE;
    }
  } else {
    if (unknown){
      vs.insert(iter, ToEdge(GetID(v)) | DEAD | UNKNOWN);
    } else {
      vs.insert(iter, ToEdge(GetID(v)) | ALIVE);
    }
  }
}

void GraphDistanceApc::DeleteEdgeFromGraph(vector<uint32_t> &vs, uint32_t v, bool unknown){
  auto iter = lower_bound(vs.begin(), vs.end(), v);
  if (iter != vs.end() && GetID(*iter) == GetID(v)){
    if (unknown){
      *iter |= UNKNOWN;
    } else {
      *iter = ToEdge(GetID(v)) | DEAD;
    }
  }
}

void GraphDistanceApc::Build(int n, vector<pair<int, int> > es, int level){
  // omp_set_num_threads(min<int>(cur, es.size() / 750000));
  
  Ds.clear();
  
  for (int t = 0; t < omp_get_max_threads(); t++){
    Ds.emplace_back(n / (sizeof(Ds[t][0]) * 4) + 1);
    costs.emplace_back(2);
    for (int dir = 0; dir < 2; ++dir) 
      costs[t][dir].resize(n);
    used_vss.emplace_back(n);
    PQs.push_back({vector<queue<int> >(sqrt(n)), vector<queue<int> >(sqrt(n))});
  }

  graphUtils::Graph g(n);

  is_cover.resize(n);
  for (auto &e : es){
    g[e.fst].push_back(e.snd);
    g[e.snd].push_back(e.fst);
  }

  
  for (int v = 0; v < n; v++) {
    sort(g[v].begin(), g[v].end());    
    g[v].erase(unique(g[v].begin(), g[v].end()), g[v].end());
  }
  
  HierarchicalApc hpc(g, LL_DEG);
  hpc.constructApc(level);


  
  for (int v = 0; v < n; ++v) {
    if (hpc.vertexLevel[v] != level) continue;
    // if (g[v].size() == 2) continue;
    is_cover[v] = true;
  }

  {
    vector<pair<int, int> > table;
    for (int v = 0; v < n; ++v) {
      table.emplace_back(!is_cover[v], v);
    }
    sort(table.begin(), table.end());
    vtable.resize(n);
    is_cover.clear();
    is_cover.resize(n);
    
    for (int v = 0; v < n; ++v) {
      vtable[table[v].second] = v;
      is_cover[v] = !table[v].first;
    }
    
  }

  for (auto &e : es) {
    e.fst = vtable[e.fst];
    e.snd = vtable[e.snd];
  }
  
  G[0].resize(n);
  G[1].resize(n);
  
  for (auto &e : es){
    G[0][e.fst].push_back(ToEdge(e.snd));
    G[1][e.snd].push_back(ToEdge(e.fst));
  }
  
  for (int v = 0; v < n; v++){
    sort(G[0][v].begin(), G[0][v].end());
    sort(G[1][v].begin(), G[1][v].end());
  }
  
  JLOG_PUT("apc_v", hpc.numVC.back());
  JLOG_PUT("apc_e", hpc.numEdge.back());
  // JLOG_PUT("apc_max_d", hpc.maxDegree.back());
  // overlayvertex v <-> hpc.vertexLevel[v] == level


  
  for (int dir = 0; dir < 2; ++dir) {
    overlay_graph[dir].resize(n);
    auto &overG = overlay_graph[dir];
    vector<int> vis(n);
    int vcnt = 1;
    
    for (int v = 0; v < n; ++v) {
      if (!is_cover[v]) continue;

      queue<pair<int, int> > q;
      q.push({v, 0});
      ++vcnt;
      vis[v] = vcnt;
      
      while (!q.empty()) {
        int cv = q.front().first;
        int cc = q.front().second;
        q.pop();

        for (auto w_ : G[dir][cv]) {
          auto w = GetID(w_);
          if (vis[w] == vcnt) continue;
          vis[w] = vcnt;
          if (is_cover[w])
            overG[v].emplace_back(ToEdge(w), cc + 1);
          else
            q.push({w, cc + 1});
        }
      }
      sort(overG[v].begin(), overG[v].end());
    }
  }
  size_t num_es = 0;
  for (int v = 0; v < n; ++v){
    num_es += overlay_graph[0][v].size();
  }
  cerr << "num_es: " << num_es << endl;

  for (int dir = 0; dir < 2; dir++){
    bool update = true;
    int num_iter = 0;
      
    while (update){
      cerr << ++num_iter << "-th iteration." << endl;
      update = false;
      const int INF = 1e9;
      vector<int> dist(n, INF);
      vector<vector<int> > D(n);
      
      for (int u = 0; u < n; ++u){
        if (!is_cover[u]) continue;
        vector<int> update_vs;
        for (auto v_ : overlay_graph[dir][u]){
          int v  = GetID(v_.first);
          int cv = v_.second;
          for (auto w_ : overlay_graph[dir][v]){
            int w = GetID(w_.first);
            int cw = w_.second;
            if (v == u || v == w) continue;
            update_vs.push_back(w);
            dist[w] = min(dist[w], cv + cw);
          }
        }

        for (size_t i = 0; i < overlay_graph[dir][u].size(); ++i){
          auto v_ = overlay_graph[dir][u][i];
          int v  = GetID(v_.first);
          D[u].push_back(dist[v]);
        }
        for (int v : update_vs){
          dist[v] = INF;
        }
      }

      for (int u = 0; u < n; ++u){
        size_t m = 0;
        for (size_t i = 0; i < overlay_graph[dir][u].size(); ++i){
          auto v_ = overlay_graph[dir][u][i];
          int cv = v_.second;
          if (cv < D[u][i]) {
            overlay_graph[dir][u][m++] = v_;
          }
        }
        
        if(m <  overlay_graph[dir][u].size()){
          update = true;
          overlay_graph[dir][u].resize(m);
        }
        
      }
    }
  }
   num_es = 0;
  for (int v = 0; v < n; ++v){
    num_es += overlay_graph[0][v].size();
  }
  cerr << "num_es: " << num_es << endl;
  // assert(false);
}

void GraphDistanceApc::UpdateOverlayGraphBeforeQuerying(const vector<tuple<int, int, int, char> > &updates){

  update_time_collect_changed_vs -= jlog_internal::get_current_time_sec();
  vector<vector<int> > has_change(omp_get_max_threads());
  set<int> deleted_vs;
  set<int> covered;
  
  // 頂点被覆を更新
  for (auto query : updates){
    char cmd; int u, v, i;
    tie(u, v, i, cmd) = query;
    is_cover[u] = is_cover[v] = true;
    covered.insert(u);
    covered.insert(v);
    has_change[0].push_back(u);
    has_change[0].push_back(v);
    if (cmd == 'D'){
      deleted_vs.insert(u);
      deleted_vs.insert(v);
    }
  }

  vector<int> vcovered(covered.begin(), covered.end());
  
  // has_changeがあるためparallelはダメ

#pragma omp parallel for schedule(guided)  
  for (auto vidx = 0u; vidx < vcovered.size(); ++vidx) {
    int s = vcovered[vidx];
    auto &D = Ds[omp_get_thread_num()];
    auto &used_vs = used_vss[omp_get_thread_num()];
    used_vs.clear();
    const auto D_unit = sizeof(D[0]) * 4;
    
    for (int dir = 0; dir < 2; dir++){
      queue<pair<int, int> > q;
      q.push({s, 0});
      D[s / D_unit] |= 1 << (dir + s % D_unit * 2);
      used_vs.push_back(s);
      
      auto& overG = overlay_graph[dir][s];
      overG.clear();
      
      while (!q.empty()) {
        int cv = q.front().first;
        int cc = q.front().second;
        q.pop();

        for (auto w_ : G[dir][cv]) {
          auto w = GetID(w_);
          auto state = GetEdgeState(w_);
          if ((state & UNKNOWN)) {
            assert(cc == 0);
            overG.emplace_back(ToEdge(w) | state, cc + 1);
            continue;
          }
          
          if (state & DEAD) continue;
          
          auto& d = D[w / D_unit];
          if (d & (1 << (dir + w % D_unit * 2))) continue;
          d |= 1 << (dir + w % D_unit * 2);
          used_vs.push_back(w);
          
          if (is_cover[w]) {
            overG.emplace_back(ToEdge(w), cc + 1);
            has_change[omp_get_thread_num()].push_back(w);
          } else
            q.push({w, cc + 1});
        }
      }
      sort(overG.begin(), overG.end());
    }
    
    for (auto v : used_vs){
      D[v / D_unit] = 0;
    }
  }

  

  update_time_collect_changed_vs += jlog_internal::get_current_time_sec();
  update_time_manage_changed_vs  -= jlog_internal::get_current_time_sec();

  
  vector<int> vhas_change;
  {
    auto& D = Ds[0];
    const auto D_unit = sizeof(D[0]) * 8;
    for (auto s : covered) D[s / D_unit] |= 1 << (s % D_unit);
    
    for (int i = 0; i < omp_get_max_threads(); ++i){
      for (auto s : has_change[i]){
        if (D[s / D_unit] & (1 << (s % D_unit))) continue;
        D[s / D_unit] |= 1 << (s % D_unit);
        vhas_change.push_back(s);
      }
    }
    
    for (auto s : covered) D[s / D_unit] = 0;
    for (auto s : vhas_change) D[s / D_unit] = 0;
  }
  
#pragma omp parallel for schedule(guided)
  for (auto vidx = 0u; vidx < vhas_change.size(); ++vidx) {
    int s = vhas_change[vidx];
    auto &D = Ds[omp_get_thread_num()];
    auto &used_vs = used_vss[omp_get_thread_num()];
    used_vs.clear();
    const auto D_unit = sizeof(D[0]) * 4;
    
    for (int dir = 0; dir < 2; dir++){
      queue<pair<int, int> > q;
      q.push({s, 0});
      D[s / D_unit] |= 1 << (dir + s % D_unit * 2);
      used_vs.push_back(s);
      
      auto& overG = overlay_graph[dir][s];
      overG.clear();
      
      while (!q.empty()) {
        int cv = q.front().first;
        int cc = q.front().second;
        q.pop();

        for (auto w_ : G[dir][cv]) {
          auto w = GetID(w_);
          auto state = GetEdgeState(w_);
          if ((state & UNKNOWN)) {
            assert(cc == 0);
            overG.emplace_back(ToEdge(w) | state, cc + 1);
            continue;
          }
          
          if (state & DEAD) continue;

          auto& d = D[w / D_unit];
          if (d & (1 << (dir + w % D_unit * 2))) continue;
          d |= 1 << (dir + w % D_unit * 2);
          used_vs.push_back(w);
          
          if (is_cover[w])
            overG.emplace_back(ToEdge(w), cc + 1);
          else
            q.push({w, cc + 1});
        }
      }
      sort(overG.begin(), overG.end());
    }
    
    for (auto v : used_vs)
      D[v / D_unit] = 0;    
  }
  update_time_manage_changed_vs  += jlog_internal::get_current_time_sec();
}
  

void GraphDistanceApc::UpdateBeforeQuerying(const vector<tuple<int, int, int, char> > &updates){
#pragma omp parallel for
  for (int dir = 0; dir < 2; ++dir){
    for (auto query : updates){
      char cmd; int u, v, i;
      tie(u, v, i, cmd) = query;
      
      if (int(G[dir].size()) < max(u, v) + 1){
        int V = max(u, v) + 1;
        G[dir].resize(V);
        if (dir){
          for (int t = 0; t < omp_get_max_threads(); t++){
            Ds[t].resize(V / (sizeof(Ds[t][0]) * 4) + 1);
          }
        }
      }
      
      switch(cmd){
      case 'A':
        InsertEdgeIntoGraph(G[dir][dir ? v : u], ToEdge(dir ? u : v), true);
        break;
      case 'D':
        DeleteEdgeFromGraph(G[dir][dir ? v : u], ToEdge(dir ? u : v), true);
        break;
      default:
        assert(false);
      }
    }
  }
  
  UpdateOverlayGraphBeforeQuerying(updates);
}

void GraphDistanceApc::UpdateOverlayGraphAfterQuerying(const vector<tuple<int, int, int, char> > &updates){
  // 各updatesに対応する辺のunknownフラグをなくすだけ.

  auto remove_unknown = [this](int u, int v, int dir, char cmd) {
    auto& edges = overlay_graph[dir][u];
    auto iter = lower_bound(edges.begin(), edges.end(),
                            pair<int, int>(ToEdge(v), 0));
    
    while (iter != edges.end() &&
           (int)GetID(iter->first) ==v &&
           iter->second != 1)
      ++iter;
    
    if (iter != edges.end() && (int)GetID(iter->first) == v &&
        iter->second == 1)
      iter->first = ToEdge(v) | (cmd == 'A' ? ALIVE : DEAD);
  };
  
  for (auto upd : updates) {
    char cmd; int u, v, t;
    tie(u, v, t, cmd) = upd;
    remove_unknown(u, v, 0, cmd);
    remove_unknown(v, u, 1, cmd);
  }
  
}
 

void GraphDistanceApc::UpdateAfterQuerying(const vector<tuple<int, int, int, char> > &updates){
  for (auto upd : updates){
    char cmd; int u, v, t;
    tie(u, v, t, cmd) = upd;
    switch (cmd){
    case 'A':
      InsertEdgeIntoGraph(G[0][u], ToEdge(v), false);
      InsertEdgeIntoGraph(G[1][v], ToEdge(u), false);
      break;
    case 'D':
      DeleteEdgeFromGraph(G[0][u], ToEdge(v), false);
      DeleteEdgeFromGraph(G[1][v], ToEdge(u), false);
      break;
    default:
      assert(false);
    }
  }
  UpdateOverlayGraphAfterQuerying(updates);
}

vector<int> GraphDistanceApc::ProcessBatch(const vector<query_t> &batch){
  double process_start = jlog_internal::get_current_time_sec();
  double start= jlog_internal::get_current_time_sec();
  
  // read query
  for (size_t i = 0; i < batch.size(); ++i){
    auto query = batch[i];
    char cmd; int u, v;
    tie(cmd, u, v) = query;
    u = vtable[u];
    v = vtable[v];
    switch (cmd){
    case 'A':
    case 'D':
      updates.push_back(make_tuple(u, v, i, cmd));
      break;
    case 'Q':
      queries.push_back(make_tuple(u, v, i));
      break;
    default:
      assert(false);
    }
  }
  
  // Update data structures
  UpdateBeforeQuerying(updates);
  
  sort(updates.begin(), updates.end());
  update_time1 += jlog_internal::get_current_time_sec() - start;
  vector<int> res(queries.size());
  start= jlog_internal::get_current_time_sec();
  vector<double> query_time_thread(omp_get_max_threads());
  last_step.resize(omp_get_max_threads());
#pragma omp parallel for schedule(dynamic)
  for (size_t i = 0; i < queries.size(); i++){
    // cerr << "query " << i + 1 << " / " << queries.size() << endl;
    double qstart = jlog_internal::get_current_time_sec();
    auto q = queries[i];
    res[i] = QueryDistance(get<0>(q), get<1>(q), get<2>(q), updates);
    query_time_thread[omp_get_thread_num()] += jlog_internal::get_current_time_sec() - qstart;
  }

  omp_query += jlog_internal::get_current_time_sec() - start;
  
  sort(query_time_thread.begin(), query_time_thread.end(), greater<double>());
  
  query_time += query_time_thread[0];
  if (1 < query_time_thread.size())
    second_slowest_query_time += query_time_thread[1];

  for (int i = (int)query_time_thread.size() - 1; i >= 0; --i) {
    if (query_time_thread[i] > 0) {
      fastest_thread += query_time_thread[i];
      break;
    }
  }
  
  start = jlog_internal::get_current_time_sec();
  // Update data structures
  UpdateAfterQuerying(updates);
  queries.clear();
  updates.clear();
  update_time2 += jlog_internal::get_current_time_sec() - start;

  process_batch_time += jlog_internal::get_current_time_sec() - process_start;
  return res;
}

GraphDistanceApc::~GraphDistanceApc(){
  // JLOG_PUT("insert", query_counter['A']);
  // JLOG_PUT("delete", query_counter['D']);
  // JLOG_PUT("query", query_counter['Q']);
  // JLOG_PUT("query_disconnected", query_counter['Q'] - connected_counter);
  // JLOG_PUT("query_disconnected_time", time_disconnected);
  // JLOG_PUT("second_query_time", second_slowest_query_time);
  // JLOG_PUT("fastest_query", fastest_thread);
  // JLOG_PUT("last_step_time_sum", accumulate(last_step.begin(), last_step.end(), 0.0));
  // JLOG_PUT("last_step_time_max", *max_element(last_step.begin(), last_step.end()));
  // JLOG_PUT("query_time", query_time);
  JLOG_PUT("original_graph_search", original_graph_search);
  JLOG_PUT("overlay_graph_search", overlay_graph_search);
  JLOG_PUT("update_before_query", update_time1);
  JLOG_PUT("update_overlay_step1", update_time_collect_changed_vs);
  JLOG_PUT("update_overlay_step2", update_time_manage_changed_vs);
  JLOG_PUT("omp_query_time", omp_query);
  JLOG_PUT("process_time", process_batch_time);
  // JLOG_PUT("update_after_query", update_time2);
  
  // JLOG_PUT("avg_forward_visit", average(forward_visit));
  // JLOG_PUT("avg_backward_visit", average(backward_visit));
  // JLOG_PUT("avg_st_dist", average(st_dist));
}


void GraphDistanceApc::PrintGraph() {
  for (int dir = 0; dir < 2; ++dir) {
    cerr << "dir " << dir << endl;
    for (auto i = 0u; i < G[dir].size(); ++i) {
      cerr << i << ": ";      
      for (auto e : G[dir][i])
        cerr << "(" << GetID(e) << ", "
             << GetEdgeState(e) << "), ";
      cerr << endl;
    }
  }
}


void GraphDistanceApc::PrintOverlayGraph() {
  for (int dir = 0; dir < 2; ++dir) {
    cerr << "dir " << dir << endl;
    const auto& overG = overlay_graph[dir];
    for (auto i = 0u; i < overG.size(); ++i) {
      cerr << i << ": ";
      for (auto e : overG[i])
        cerr << "(" << GetID(e.first) << ", "
             << GetEdgeState(e.first) << ", "
             << e.second << "), ";
      cerr << endl;
    }
  }
}
