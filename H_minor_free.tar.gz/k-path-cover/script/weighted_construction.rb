#!/usr/bin/env ruby

require 'fileutils'
require 'rubygems'
require 'json'
require 'gnuplot'

if __FILE__ == $0
  files = Dir.glob("../result/json/weighted_construction/*")

  for file in files
    base = File.basename(file, ".json").split(".").join("_")
    json = JSON.parse(open(file).read)
    k = json["experiment"]["k"]

    res = json["results"]
    statsfile = open("../result/stats/weighted_construction/" + base + ".txt", "w")

    datax = Array.new
    datay = Array.new

    #
    # stats
    #

    statsfile.puts(format("input file: %s", json["experiment"]["input_file"]))
    statsfile.puts(format("K: %s", 2**k))
    for i in 0..4
      statsfile.puts(format("[%s]", res[i]["heuristic"]))
      statsfile.puts(format("\telapsed: %f", res[i]["elapsed"]))
      statsfile.puts(format("\t#vertex = %d\n\t#edge = %d\n\tmax_degree = %d", res[i]["layer"][k-1]["V"], res[i]["layer"][k-1]["E"], res[i]["layer"][k-1]["max_degree"])) 
    end


    #
    # figures
    #

    for i in 0..k
      datax << 2**i
    end

    # number of vertices
    Gnuplot.open do |gp|
      Gnuplot::Plot.new(gp) do |plot|
        plot.title format("comparison of VC heuristics (#vertices) [%s]", json["experiment"]["input_file"])
        plot.set "logscale x"
        plot.output "../result/img/weighted_construction/" + base + "_v" + ".eps"
        plot.set format("xtics (%s)", (datax.map {|x| x.to_s}).join(","))
        plot.set 'terminal postscript eps enhanced font "Helvetica,18" color'
        plot.xrange format("[1:%d]", 2**k)
        plot.yrange "[0:]"
        plot.xlabel "k"
        plot.ylabel "#vertices"

        for j in 0..4
          datay = Array.new
          for i in 0..k
            datay << res[j]["layer"][i]["V"]
          end
          
          plot.data << Gnuplot::DataSet.new([datax, datay]) do |ds|
            ds.with = "lines"
            ds.linewidth = 5
            ds.title = res[j]["heuristic"].gsub("_", "\\_")
          end
        end
      end
    end

    # number of edges
    Gnuplot.open do |gp|
      Gnuplot::Plot.new(gp) do |plot|
        plot.title format("comparison of VC heuristics (#edges) [%s]", json["experiment"]["input_file"])
        plot.set "logscale x"
        plot.output "../result/img/weighted_construction/" + base + "_e" + ".eps"
        plot.set format("xtics (%s)", (datax.map {|x| x.to_s}).join(","))
        plot.set 'terminal postscript eps enhanced font "Helvetica,18" color'
        plot.xrange format("[1:%d]", 2**k)
        plot.yrange "[0:]"
        plot.xlabel "k"
        plot.ylabel "#edges"

        for j in 0..4
          datay = Array.new
          for i in 0..k
            datay << res[j]["layer"][i]["E"]
          end
          
          plot.data << Gnuplot::DataSet.new([datax, datay]) do |ds|
            ds.with = "lines"
            ds.linewidth = 5
            ds.title = res[j]["heuristic"].gsub("_", "\\_")
          end
        end
      end
    end

    Gnuplot.open do |gp|
      Gnuplot::Plot.new(gp) do |plot|
        plot.title format("comparison of VC heuristics (max degree) [%s]", json["experiment"]["input_file"])
        plot.set "logscale x"
        plot.output "../result/img/weighted_construction/" + base + "_d" + ".eps"
        plot.set format("xtics (%s)", (datax.map {|x| x.to_s}).join(","))
        plot.set 'terminal postscript eps enhanced font "Helvetica,18" color'
        plot.xrange format("[1:%d]", 2**k)
        plot.yrange "[0:]"
        plot.xlabel "k"
        plot.ylabel "max degree"
        plot.set "key left top"

        for j in 0..4
          datay = Array.new
          for i in 0..k
            datay << res[j]["layer"][i]["max_degree"]
          end
          
          plot.data << Gnuplot::DataSet.new([datax, datay]) do |ds|
            ds.with = "lines"
            ds.linewidth = 5
            ds.title = res[j]["heuristic"].gsub("_", "\\_")
          end
        end
      end
    end

  end
end
