#!/usr/bin/env ruby

require 'fileutils'
require 'rubygems'
require 'json'
require 'gnuplot'

class Integer
  def to_comma
    self.to_s.gsub(/(\d)(?=(\d{3})+(?!\d))/, '\1,')
  end
end

if __FILE__ == $0
  files = Dir.glob("../result/json/construction16-h/*")
  FileUtils.mkdir_p("../result/stats/construction16")
  tablefile = open("../result/stats/construction16/table.txt", "w")

  for file in files
    base = File.basename(file, ".json")
    json = JSON.parse(open(file).read)
    jsonf = JSON.parse(open("../result/json/construction16-f/" + base + ".json").read)
    k = json["experiment"]["k"]

    res = json["results"]
    resf = jsonf["results"]
    statsfile = open("../result/stats/construction16/" + base + ".txt", "w")

    datax = Array.new
    datay = Array.new

    #
    # stats
    #

    statsfile.puts(format("input file: %s", json["experiment"]["input_file"]))
    statsfile.puts(format("k: %s", k))
    statsfile.puts(format("V: %s", json["experiment"]["V"]))
    statsfile.puts(format("E: %s", json["experiment"]["E"]))

    for i in 0..4
      statsfile.puts(format("[%s]", res[i]["heuristic"]))
      statsfile.puts(format("\telapsed: %f", res[i]["elapsed"]))
      statsfile.puts(format("\t#vertex = %d\n\t#edge = %d\n\tmax_degree = %d", res[i]["V"], res[i]["E"], res[i]["max_degree"])) 
    end
    statsfile.puts("[Funke]")
    statsfile.puts(format("\telapsed: %f", resf[0]["elapsed"]))
    statsfile.puts(format("\t#vertex = %d\n\t#edge = %d\n\tmax_degree = %d", resf[0]["V"], resf[0]["E"], resf[0]["max_degree"])) 

    statsfile.puts()

    statsfile.print(format(" $|C|$ & ", json["experiment"]["input_file"]))
    statsfile.print(format(" & %s", resf[0]["V"].to_comma))
    for i in 0...5
      statsfile.print(format(" & %s", res[i]["V"].to_comma))
    end
    statsfile.puts(" \\\\")
    statsfile.print(" $|E_O|$ & ")
    statsfile.print(format(" & %s", resf[0]["E"].to_comma))
    for i in 0...5
      statsfile.print(format(" & %s", res[i]["E"].to_comma))
    end
    statsfile.puts(" \\\\")
=begin
    #
    # figures
    #

    for i in 0..k
      datax << 2**i
    end

    # number of vertices
    Gnuplot.open do |gp|
      Gnuplot::Plot.new(gp) do |plot|
        plot.title format("comparison of VC heuristics (#vertices) [%s]", json["experiment"]["input_file"])
        plot.set "logscale x"
        plot.output "../result/img/construction/" + base + "_v" + ".eps"
        plot.set format("xtics (%s)", (datax.map {|x| x.to_s}).join(","))
        plot.set 'terminal postscript eps enhanced font "Helvetica,18" color'
        plot.xrange format("[1:%d]", 2**k)
        plot.yrange "[0:]"
        plot.xlabel "k"
        plot.ylabel "#vertices"

        for j in 0..4
          datay = Array.new
          for i in 0..k
            datay << res[j]["layer"][i]["V"]
          end
          
          plot.data << Gnuplot::DataSet.new([datax, datay]) do |ds|
            ds.with = "lines"
            ds.linewidth = 5
            ds.title = res[j]["heuristic"].gsub("_", "\\_")
          end
        end
      end
    end

    # number of edges
    Gnuplot.open do |gp|
      Gnuplot::Plot.new(gp) do |plot|
        plot.title format("comparison of VC heuristics (#edges) [%s]", json["experiment"]["input_file"])
        plot.set "logscale x"
        plot.output "../result/img/construction/" + base + "_e" + ".eps"
        plot.set format("xtics (%s)", (datax.map {|x| x.to_s}).join(","))
        plot.set 'terminal postscript eps enhanced font "Helvetica,18" color'
        plot.xrange format("[1:%d]", 2**k)
        plot.yrange "[0:]"
        plot.xlabel "k"
        plot.ylabel "#edges"

        for j in 0..4
          datay = Array.new
          for i in 0..k
            datay << res[j]["layer"][i]["E"]
          end
          
          plot.data << Gnuplot::DataSet.new([datax, datay]) do |ds|
            ds.with = "lines"
            ds.linewidth = 5
            ds.title = res[j]["heuristic"].gsub("_", "\\_")
          end
        end
      end
    end

    Gnuplot.open do |gp|
      Gnuplot::Plot.new(gp) do |plot|
        plot.title format("comparison of VC heuristics (max degree) [%s]", json["experiment"]["input_file"])
        plot.set "logscale x"
        plot.output "../result/img/construction/" + base + "_d" + ".eps"
        plot.set format("xtics (%s)", (datax.map {|x| x.to_s}).join(","))
        plot.set 'terminal postscript eps enhanced font "Helvetica,18" color'
        plot.xrange format("[1:%d]", 2**k)
        plot.yrange "[0:]"
        plot.xlabel "k"
        plot.ylabel "max degree"
        plot.set "key left top"

        for j in 0..4
          datay = Array.new
          for i in 0..k
            datay << res[j]["layer"][i]["max_degree"]
          end
          
          plot.data << Gnuplot::DataSet.new([datax, datay]) do |ds|
            ds.with = "lines"
            ds.linewidth = 5
            ds.title = res[j]["heuristic"].gsub("_", "\\_")
          end
        end
      end
    end
=end
  end
end
