#!/usr/bin/env ruby

require 'fileutils'
require 'rubygems'
require 'json'
require 'gnuplot'

if __FILE__ == $0
  files = Dir.glob("../result/json/construction/*")

  for file in files
    base = File.basename(file, ".json").split(".").join("_")
    json = JSON.parse(open(file).read)
    k = json["experiment"]["k"]

    next unless json["experiment"]["input_file"] == "USA-road.USA.tsv"

    res = json["results"]

    datax = Array.new
    datay = Array.new

    #
    # figures
    #

    for i in 0..k
      datax << 2**i
    end

    # number of vertices
    Gnuplot.open do |gp|
      Gnuplot::Plot.new(gp) do |plot|
        plot.title format("comparison of VC heuristics (#vertices) [%s]", json["experiment"]["input_file"])
        plot.set "logscale x"
        plot.output "../result/img/construction/" + base + "_v_c" + ".eps"
        plot.set format("xtics (%s)", (datax.map {|x| x.to_s}).join(","))
        plot.set 'terminal postscript eps enhanced font "Helvetica,18" color'
        plot.xrange format("[1:%d]", 2**k)
        plot.yrange "[0:]"
        plot.xlabel "k"
        plot.ylabel "#vertices"

        for j in 0..4
          datay = Array.new
          for i in 0..k
            datay << res[j]["layer"][i]["V"]
          end
          
          plot.data << Gnuplot::DataSet.new([datax, datay]) do |ds|
            ds.with = "lines"
            ds.linewidth = 5
            ds.title = res[j]["heuristic"].gsub("_", "\\_")
          end
        end

        datax = [1, 2, 4, 8, 16, 32]
        datay = [23947347, 11910322, 6676239, 3776360, 2351124, 1603267]
        plot.data << Gnuplot::DataSet.new([datax, datay]) do |ds|
          ds.with = "lines"
          ds.linewidth = 5
          ds.title = "Funke+"
        end
      end
    end
  end
end
