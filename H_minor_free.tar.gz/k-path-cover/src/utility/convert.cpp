#include <bits/stdc++.h>

#define rep(i,n) for(int i=0;i<(int)(n);i++)
#define each(it,n) for(__typeof((n).begin()) it=(n).begin();it!=(n).end();++it)

using namespace std;

int main() {
    string line;
    while (getline(cin, line)) {
        stringstream ss;
        ss << line;
        string a, b, c;
        ss >> a >> b >> c;
        if (a == "a") {
            cout << b << " " << c << endl;
        }
    }
    return 0;
}
