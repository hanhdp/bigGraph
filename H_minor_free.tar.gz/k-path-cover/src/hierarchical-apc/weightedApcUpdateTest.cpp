#include "weightedHierarchicalApc.hpp"
#include "weightedFlatApc.hpp"
#include "../common/graphUtils.hpp"
#include "../common/jlog.h"
#include <iostream>
#include <string>
#include <random>
#include <algorithm>
#include <gflags/gflags.h>

DEFINE_int32(k, 2, "value of k");

using namespace std;
using namespace graphUtils;

string heuristicsName[5] = {"LR_DEG", "LR_ADAPTIVE", "LL_DEG", "LL_ADAPTIVE", "ED"};

int main(int argc, char** argv) {
    JLOG_INIT(&argc, argv);
    google::ParseCommandLineFlags(&argc, &argv, true);
    const int K = FLAGS_k;
    
    if (argc <= 1) {
        cout << "Usage: ./hierarchical_bench [input file]" << endl;
        return 0;
    }

    random_device seed_gen;
    unsigned int seed = seed_gen();
    default_random_engine engine(seed);

    WeightedGraph G = readWeightedGraph(argv[1]);

    cerr << "load" << endl;

    vector<pair<pair<int, int>, int> > edges;
    for (int i = 0; i < G.V; i++) {
        for (int j = 0; j < (int)G.adj[i].size(); j++) {
            WeightedEdge e = G.adj[i][j];
            edges.push_back({{i, e.to}, e.weight});
        }
    }

    const int numQuery = min(10000, (int)edges.size());

    // random shuffle
    for (int i = 0; i < numQuery; i++) {
        uniform_int_distribution<> distr(0, (int)edges.size() - 1 - i);
        swap(edges[i], edges[distr(engine) + i]);
    }

    JLOG_OPEN("experiment") {
        JLOG_PUT("input_file", basename(argv[1]));
        JLOG_PUT("k", 1 << K);
        JLOG_PUT("num_query", numQuery);
        JLOG_PUT("seed", seed);
    }

    JLOG_OPEN("results") {
        WeightedHierarchicalApc hapc(G, LL_ADAPTIVE);
        WeightedFlatApc fapc(G);
        JLOG_PUT_BENCHMARK("hapc.elapsed") {
            hapc.constructApc(K);
        }
        JLOG_PUT_BENCHMARK("fapc.elapsed") {
            fapc.constructApcViaHierarchical(K, LL_ADAPTIVE);
        }

        int updated = 0;
        JLOG_PUT_BENCHMARK("hapc.update_time_decrease") {
            for (int j = 0; j < numQuery; j++) {
                updated += hapc.updateWeight(edges[j].first.first, edges[j].first.second, edges[j].second / 2);
            }
        }
        JLOG_PUT("hapc.updated_edge_decrease", updated);

        updated = 0;
        JLOG_PUT_BENCHMARK("fapc.update_time_decrease") {
            for (int j = 0; j < numQuery; j++) {
                updated += fapc.updateWeight(edges[j].first.first, edges[j].first.second, edges[j].second / 2);
            }
        }
        JLOG_PUT("fapc.updated_edge_decrease", updated);

        // verify
        assert(hapc.G[K].adj == fapc.G1.adj);

        updated = 0;
        JLOG_PUT_BENCHMARK("hapc.update_time_increase") {
            for (int j = numQuery - 1; j >= 0; j--) {
                updated += hapc.updateWeight(edges[j].first.first, edges[j].first.second, edges[j].second);
            }
        }
        JLOG_PUT("hapc.updated_edge_increase", updated);

        updated = 0;
        JLOG_PUT_BENCHMARK("fapc.update_time_increase") {
            for (int j = numQuery - 1; j >= 0; j--) {
                updated += fapc.updateWeight(edges[j].first.first, edges[j].first.second, edges[j].second);
            }
        }
        JLOG_PUT("fapc.updated_edge_increase", updated);

        assert(hapc.G[K].adj == fapc.G1.adj);
    }

    return 0;
}
