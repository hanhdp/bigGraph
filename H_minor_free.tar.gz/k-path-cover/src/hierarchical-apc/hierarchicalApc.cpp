#include <queue>
#include <vector>
#include <cassert>
#include <set>
#include <iostream>
#include "../common/graphUtils.hpp"
#include "hierarchicalApc.hpp"

using namespace std;
using namespace graphUtils;

HierarchicalApc::HierarchicalApc(const Graph &G, VCHeuristics heuristic) : 
    V(G.size()),
    originalGraph(G),
    overlayGraph(G),
    vertexLevel(vector<int>(V, 0)),
    K(0),
    heuristic(heuristic) {
    for (int i = 0; i < V; i++) {
        for (int j = 0; j < (int)G[i].size(); j++) {
            edgeSet.insert({i, G[i][j]});
        }
    }
}


// use vertices around low-degree vertices
vector<int> HierarchicalApc::findVertexCoverLRDeg(int level) {
    vector<int> ans;
    Graph &G = this->overlayGraph;
    int V = G.size();
    bool* used = new bool[V];

    for (int i = 0; i < V; i++) {
        used[i] = false;
    }

    priority_queue<pair<int, int>, vector<pair<int, int> >, greater<pair<int, int> > > q;
    
    for (int i = 0; i < V; i++) {
        if (this->vertexLevel[i] < level) continue;
        int degree = 0;
        for (int j = 0; j < (int)G[i].size(); j++) {
            if (vertexLevel[G[i][j]] < level) continue;
            degree++;
        }

        q.push({degree, i}); //degree, id
    }

    while (!q.empty()) {
        pair<int, int> e = q.top();
        q.pop();

        //int d = e.first;
        int v = e.second;

        if (!used[v]) {
            for (int i = 0; i < (int)G[v].size(); i++) {
                int u = G[v][i];
                if (this->vertexLevel[u] < level) continue;
                if (!used[u]) {
                    used[u] = true;
                    ans.push_back(u);
                }
            }
        }
    }

    delete[] used;

    return ans;
}

// use high-adaptive-degree vertices
vector<int> HierarchicalApc::findVertexCoverLLAdaptive(int level) {
    vector<int> ans;
    Graph &G = this->overlayGraph;
    int V = G.size();
    bool* used = new bool[V];
    vector<int> adaptiveDegree(V);

    for (int i = 0; i < V; i++) {
        used[i] = false;
    }

    priority_queue<pair<int, int> > q;
    
    for (int i = 0; i < V; i++) {
        if (this->vertexLevel[i] < level) continue;
        int degree = 0;
        for (int j = 0; j < (int)G[i].size(); j++) {
            if (vertexLevel[G[i][j]] < level) continue;
            degree++;
        }
        q.push({degree, i}); //degree, id
        adaptiveDegree[i] = degree;
    }

    while (!q.empty()) {
        pair<int, int> e = q.top();
        q.pop();

        int d = e.first;
        int v = e.second;

        if (d == 0) break;
        if (used[v]) continue;
        if (d != adaptiveDegree[v]) continue;

        used[v] = true;
        ans.push_back(v);
        for (int i = 0; i < (int)G[v].size(); i++) {
            int u = G[v][i];
            if (this->vertexLevel[u] < level) continue;
            if (!used[u]) {
                adaptiveDegree[u]--;
                q.push({adaptiveDegree[u], u});
            }
        }
    }

    delete[] used;

    return ans;
}

// use vertices around low-adaptive-degree vertices
vector<int> HierarchicalApc::findVertexCoverLRAdaptive(int level) {
    vector<int> ans;
    Graph &G = this->overlayGraph;
    int V = G.size();
    bool* used = new bool[V];
    vector<int> adaptiveDegree(V);

    for (int i = 0; i < V; i++) {
        used[i] = false;
    }

    priority_queue<pair<int, int>, vector<pair<int, int> >, greater<pair<int, int> > > q;
    
    for (int i = 0; i < V; i++) {
        if (this->vertexLevel[i] < level) continue;
        int degree = 0;
        for (int j = 0; j < (int)G[i].size(); j++) {
            if (vertexLevel[G[i][j]] < level) continue;
            degree++;
        }
        q.push({degree, i}); //degree, id
        adaptiveDegree[i] = degree;
    }

    while (!q.empty()) {
        pair<int, int> e = q.top();
        q.pop();

        int d = e.first;
        int v = e.second;

        if (used[v]) continue;
        if (d != adaptiveDegree[v]) continue;

        used[v] = true;
        for (int i = 0; i < (int)G[v].size(); i++) {
            int u = G[v][i];
            if (this->vertexLevel[u] < level) continue;
            if (used[u]) continue;
            used[u] = true;
            ans.push_back(u);
            
            for (int j = 0; j < (int)G[u].size(); j++) {
                int w = G[u][j];
                if (this->vertexLevel[w] < level) continue;
                if (v == w) continue;
                if (used[w]) continue;

                adaptiveDegree[w]--;
                q.push({adaptiveDegree[w], w});
            }
        }
    }

    delete[] used;

    return ans;
}

// use high-degree vertices
vector<int> HierarchicalApc::findVertexCoverLLDeg(int level) {
    vector<int> ans;
    Graph &G = this->overlayGraph;
    int V = G.size();
    bool* used = new bool[V];

    for (int i = 0; i < V; i++) {
        used[i] = false;
    }

    priority_queue<pair<int, int>, vector<pair<int, int> > > q;
    
    for (int i = 0; i < V; i++) {
        if (this->vertexLevel[i] < level) continue;
        int degree = 0;
        for (int j = 0; j < (int)G[i].size(); j++) {
            if (vertexLevel[G[i][j]] < level) continue;
            degree++;
        }
        q.push({degree, i}); //degree, id
    }

    while (!q.empty()) {
        pair<int, int> e = q.top();
        q.pop();
        
        //int d = e.first;
        int v = e.second;

        used[v] = true;

        bool flag = true;
        for (int i = 0; i < (int)G[v].size(); i++) {
            int u = G[v][i];
            if (this->vertexLevel[u] < level) continue;
            flag &= used[u];
        }
        if (!flag) ans.push_back(v);
    }

    delete[] used;

    return ans;
}

vector<int> HierarchicalApc::findVertexCoverED(int level) {
    vector<int> ans;
    Graph &G = this->overlayGraph;
    int V = G.size();
    bool* used = new bool[V];

    for (int i = 0; i < V; i++) {
        used[i] = false;
    }

    priority_queue<pair<int, int>, vector<pair<int, int> > > q;
    
    for (int i = 0; i < V; i++) {
        if (this->vertexLevel[i] < level) continue;
        int degree = 0;
        for (int j = 0; j < (int)G[i].size(); j++) {
            if (vertexLevel[G[i][j]] < level) continue;
            degree++;
        }
        q.push({degree, i}); //degree, id
    }

    while (!q.empty()) {
        pair<int, int> e = q.top();
        q.pop();

        //int d = e.first;
        int v = e.second;

        if (used[v]) continue;

        for (int i = 0; i < (int)G[v].size(); i++) {
            int u = G[v][i];
            if (vertexLevel[u] < level) continue;
            if (used[v] == false && used[u] == false) {
                used[v] = true;
                used[u] = true;
                ans.push_back(v);
                ans.push_back(u);
                break;
            }
        }
    }

    delete[] used;

    return ans;
}

vector<int> HierarchicalApc::findVertexCover(int level) {
    vector<int> ans;
    switch (this->heuristic) {
    case LR_DEG:
        ans = findVertexCoverLRDeg(level);
        break;
    case LR_ADAPTIVE:
        ans = findVertexCoverLRAdaptive(level);
        break;
    case LL_DEG:
        ans = findVertexCoverLLDeg(level);
        break;
    case LL_ADAPTIVE:
        ans = findVertexCoverLLAdaptive(level);
        break;
    case ED:
        ans = findVertexCoverED(level);
        break;
    }

    return ans;
}

void HierarchicalApc::addEdgeToOverlayGraph(int u, int v) {
    if (overlayEdgeSet.find({u, v}) == overlayEdgeSet.end()) {
        overlayEdgeSet.insert({u, v});
        overlayEdgeSet.insert({v, u});
        overlayGraph[u].push_back(v);
        overlayGraph[v].push_back(u);
    }
}

// construct 2^K APC
void HierarchicalApc::constructApc(int K) {
    if (this->K >= K) return;
    this->K = K;

    overlayGraph = originalGraph;
    overlayEdgeSet = edgeSet;

    numVC = vector<int>(K + 1);
    numEdge = vector<int>(K + 1);
    maxDegree = vector<int>(K + 1);

    numVC[0] = V;
    for (int i = 0; i < V; i++) {
        numEdge[0] += overlayGraph[i].size();
        maxDegree[0] = max(maxDegree[0], (int)overlayGraph[i].size());
    }
    numEdge[0] /= 2;

    for (int i = 0; i < K; i++) {
        vector<int> vc = findVertexCover(i);
        this->createOverlayGraph(vc, i);

        numVC[i + 1] = vc.size();
        for (int j = 0; j < V; j++) {
            if (vertexLevel[j] != i + 1) continue;
            numEdge[i + 1] += overlayGraph[j].size();
            maxDegree[i + 1] = max(maxDegree[i + 1], (int)overlayGraph[j].size());
        }
        numEdge[i + 1] /= 2;
    }
}
                                              
bool HierarchicalApc::checkVertexCover(const vector<int>& vc, int level) {
    Graph &G = overlayGraph;
    int V = G.size();
    bool* used = new bool[V];

    for (int i = 0; i < V; i++) {
        used[i] = false;
    }

    for (int i = 0; i < (int)vc.size(); i++) {
        used[vc[i]] = true;
    }

    bool ans = true;

    for (int i = 0; i < V; i++) {
        int d = G[i].size();
        int v = i;
        if (vertexLevel[v] < level) continue;
        for (int j = 0; j < d; j++) {
            int u = G[v][j];
            if (vertexLevel[u] < level) continue;
            if (!used[v] && !used[u]) assert(false);
        }
    }
    
    delete[] used;
    
    return ans;
}

void HierarchicalApc::createOverlayGraph(const vector<int> &vc, int level) {
    Graph &G = overlayGraph;
    //checkVertexCover(vc, level);
    int V = G.size();    

    set<pair<int, int> > used;

    for (int i = 0; i < (int)vc.size(); i++) {
        int v = vc[i];
        vertexLevel[v] = level + 1;
    }

    for (int i = 0; i < V; i++) {
        if (vertexLevel[i] == level) {
            for (int j = 0; j < (int)G[i].size(); j++) {
                int v = G[i][j];
                assert(vertexLevel[v] == level + 1);
                for (int k = j + 1; k < (int)G[i].size(); k++) {
                    int u = G[i][k];
                    assert(vertexLevel[u] == level + 1);
                    if (v == u) continue;
                    addEdgeToOverlayGraph(u, v);
                }
            }
        }
    }

    
    for (int i = 0; i < V; i++) {
        if (vertexLevel[i] == level + 1) {
            vector<int> newAdj;
            for (int j = 0; j < (int)G[i].size(); j++) {
                int v = G[i][j];
                if (vertexLevel[v] == level + 1) {
                    newAdj.push_back(v);
                }
            }
            G[i] = newAdj;
        }
    }

}

int HierarchicalApc::getNumEdge(const Graph &G) {
    int ans = 0;
    for (int i = 0; i < (int)G.size(); i++) {
        ans += G[i].size();
    }
    return ans / 2;
}
