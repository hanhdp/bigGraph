#pragma once
#include <queue>
#include <vector>
#include <cassert>
#include <set>
#include "../common/graphUtils.hpp"

enum VCHeuristics {
    LR_DEG,
    LR_ADAPTIVE,
    LL_DEG,
    LL_ADAPTIVE,
    ED
};

class HierarchicalApc {
public:
    HierarchicalApc(const graphUtils::Graph &G, VCHeuristics heuristc);

    int V;

    graphUtils::Graph originalGraph;
    graphUtils::Graph overlayGraph;
    std::vector<int> vertexLevel;
    std::set<std::pair<int, int> > edgeSet;
    std::set<std::pair<int, int> > overlayEdgeSet;
    std::vector<int> numVC;
    std::vector<int> numEdge;
    std::vector<int> maxDegree;
    int K;
    
    VCHeuristics heuristic;

    std::vector<int> findVertexCoverLRDeg(int level);
    std::vector<int> findVertexCoverLRAdaptive(int level);
    std::vector<int> findVertexCoverLLDeg(int level);
    std::vector<int> findVertexCoverLLAdaptive(int level);
    std::vector<int> findVertexCoverED(int level);
    std::vector<int> findVertexCover(int level);

    void addEdgeToOverlayGraph(int u, int v);
    void constructApc(int K);

    bool checkVertexCover(const std::vector<int>& vc, int level);
    void createOverlayGraph(const std::vector<int> &vc, int level);
    static int getNumEdge(const graphUtils::Graph &G);
};
