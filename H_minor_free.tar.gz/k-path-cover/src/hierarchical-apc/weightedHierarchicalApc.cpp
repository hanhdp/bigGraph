#include <queue>
#include <vector>
#include <cassert>
#include <set>
#include <iostream>
#include "../common/graphUtils.hpp"
#include "weightedHierarchicalApc.hpp"

using namespace std;
using namespace graphUtils;

WeightedHierarchicalApc::WeightedHierarchicalApc(const WeightedGraph &G, VCHeuristics heuristic) : 
    V(G.size()),
    vertexLevel(vector<int>(V, 0)),
    K(0),
    heuristic(heuristic) {
    this->G = vector<WeightedGraph>(1, WeightedGraph(0));
    this->G[0] = G;
}


// use vertices around low-degree vertices
vector<int> WeightedHierarchicalApc::findVertexCoverLRDeg(int level) {
    vector<int> ans;
    WeightedGraph &G = this->G[level];
    int V = G.size();
    bool* used = new bool[V];

    for (int i = 0; i < V; i++) {
        used[i] = false;
    }

    priority_queue<pair<int, int>, vector<pair<int, int> >, greater<pair<int, int> > > q;
    
    for (int i = 0; i < V; i++) {
        if (this->vertexLevel[i] < level) continue;
        q.push({G.adj[i].size() + G.adjR[i].size(), i}); //degree, id
    }

    while (!q.empty()) {
        pair<int, int> e = q.top();
        q.pop();

        //int d = e.first;
        int v = e.second;

        if (!used[v]) {
            for (int i = 0; i < (int)G.adj[v].size(); i++) {
                int u = G.adj[v][i].to;
                if (!used[u]) {
                    used[u] = true;
                    ans.push_back(u);
                }
            }
            for (int i = 0; i < (int)G.adjR[v].size(); i++) {
                int u = G.adjR[v][i].to;
                if (!used[u]) {
                    used[u] = true;
                    ans.push_back(u);
                }
            }
        }
    }

    delete[] used;

    return ans;
}

// use high-adaptive-degree vertices
vector<int> WeightedHierarchicalApc::findVertexCoverLLAdaptive(int level) {
    vector<int> ans;
    WeightedGraph &G = this->G[level];
    int V = G.size();
    bool* used = new bool[V];
    vector<int> adaptiveDegree(V);

    for (int i = 0; i < V; i++) {
        used[i] = false;
    }

    priority_queue<pair<int, int> > q;
    
    for (int i = 0; i < V; i++) {
        if (this->vertexLevel[i] < level) continue;
        int degree = G.adj[i].size() + G.adjR[i].size();
        q.push({degree, i}); //degree, id
        adaptiveDegree[i] = degree;
    }

    while (!q.empty()) {
        pair<int, int> e = q.top();
        q.pop();

        int d = e.first;
        int v = e.second;

        if (d == 0) break;
        if (used[v]) continue;
        if (d != adaptiveDegree[v]) continue;

        used[v] = true;
        ans.push_back(v);
        for (int i = 0; i < (int)G.adj[v].size(); i++) {
            int u = G.adj[v][i].to;
            if (!used[u]) {
                adaptiveDegree[u]--;
                q.push({adaptiveDegree[u], u});
            }
        }
        for (int i = 0; i < (int)G.adjR[v].size(); i++) {
            int u = G.adjR[v][i].to;
            if (!used[u]) {
                adaptiveDegree[u]--;
                q.push({adaptiveDegree[u], u});
            }
        }
    }

    delete[] used;

    return ans;
}

// use vertices around low-adaptive-degree vertices
vector<int> WeightedHierarchicalApc::findVertexCoverLRAdaptive(int level) {
    vector<int> ans;
    WeightedGraph &G = this->G[level];
    int V = G.size();
    bool* used = new bool[V];
    vector<int> adaptiveDegree(V);

    for (int i = 0; i < V; i++) {
        used[i] = false;
    }

    priority_queue<pair<int, int>, vector<pair<int, int> >, greater<pair<int, int> > > q;
    
    for (int i = 0; i < V; i++) {
        if (this->vertexLevel[i] < level) continue;
        int degree = G.adj[i].size() + G.adjR[i].size();
        q.push({degree, i}); //degree, id
        adaptiveDegree[i] = degree;
    }

    while (!q.empty()) {
        pair<int, int> e = q.top();
        q.pop();

        int d = e.first;
        int v = e.second;

        if (used[v]) continue;
        if (d != adaptiveDegree[v]) continue;

        used[v] = true;
        for (int i = 0; i < (int)G.adj[v].size(); i++) {
            int u = G.adj[v][i].to;
            if (used[u]) continue;
            used[u] = true;
            ans.push_back(u);
            
            for (int j = 0; j < (int)G.adj[u].size(); j++) {
                int w = G.adj[u][j].to;
                if (v == w) continue;
                if (used[w]) continue;

                adaptiveDegree[w]--;
                q.push({adaptiveDegree[w], w});
            }
            for (int j = 0; j < (int)G.adjR[u].size(); j++) {
                int w = G.adjR[u][j].to;
                if (v == w) continue;
                if (used[w]) continue;

                adaptiveDegree[w]--;
                q.push({adaptiveDegree[w], w});
            }
        }

        for (int i = 0; i < (int)G.adjR[v].size(); i++) {
            int u = G.adjR[v][i].to;
            if (used[u]) continue;
            used[u] = true;
            ans.push_back(u);
            
            for (int j = 0; j < (int)G.adj[u].size(); j++) {
                int w = G.adj[u][j].to;
                if (v == w) continue;
                if (used[w]) continue;

                adaptiveDegree[w]--;
                q.push({adaptiveDegree[w], w});
            }
            for (int j = 0; j < (int)G.adjR[u].size(); j++) {
                int w = G.adjR[u][j].to;
                if (v == w) continue;
                if (used[w]) continue;

                adaptiveDegree[w]--;
                q.push({adaptiveDegree[w], w});
            }
        }
    }

    delete[] used;

    return ans;
}

// use high-degree vertices
vector<int> WeightedHierarchicalApc::findVertexCoverLLDeg(int level) {
    vector<int> ans;
    WeightedGraph &G = this->G[level];
    int V = G.size();
    bool* used = new bool[V];

    for (int i = 0; i < V; i++) {
        used[i] = false;
    }

    priority_queue<pair<int, int>, vector<pair<int, int> > > q;
    
    for (int i = 0; i < V; i++) {
        if (this->vertexLevel[i] < level) continue;
        q.push({G.adj[i].size() + G.adjR[i].size(), i}); //degree, id
    }

    while (!q.empty()) {
        pair<int, int> e = q.top();
        q.pop();
        
        //int d = e.first;
        int v = e.second;

        bool flag = true;
        for (int i = 0; i < (int)G.adj[v].size(); i++) {
            int u = G.adj[v][i].to;
            flag &= used[u];
        }
        for (int i = 0; i < (int)G.adjR[v].size(); i++) {
            int u = G.adjR[v][i].to;
            flag &= used[u];
        }
        if (!flag) {
            ans.push_back(v);
            used[v] = true;
        }
    }

    delete[] used;

    return ans;
}

vector<int> WeightedHierarchicalApc::findVertexCoverED(int level) {
    vector<int> ans;
    WeightedGraph &G = this->G[level];
    int V = G.size();
    bool* used = new bool[V];

    for (int i = 0; i < V; i++) {
        used[i] = false;
    }

    priority_queue<pair<int, int>, vector<pair<int, int> > > q;
    
    for (int i = 0; i < V; i++) {
        if (this->vertexLevel[i] < level) continue;
        q.push({G.adj[i].size() + G.adjR[i].size(), i}); //degree, id
    }

    while (!q.empty()) {
        pair<int, int> e = q.top();
        q.pop();

        //int d = e.first;
        int v = e.second;

        if (used[v]) continue;

        for (int i = 0; i < (int)G.adj[v].size(); i++) {
            int u = G.adj[v][i].to;
            if (used[v] == false && used[u] == false) {
                used[v] = true;
                used[u] = true;
                ans.push_back(v);
                ans.push_back(u);
                break;
            }
        }
    }

    delete[] used;

    return ans;
}

vector<int> WeightedHierarchicalApc::findVertexCover(int level) {
    vector<int> ans;
    switch (this->heuristic) {
    case LR_DEG:
        ans = findVertexCoverLRDeg(level);
        break;
    case LR_ADAPTIVE:
        ans = findVertexCoverLRAdaptive(level);
        break;
    case LL_DEG:
        ans = findVertexCoverLLDeg(level);
        break;
    case LL_ADAPTIVE:
        ans = findVertexCoverLLAdaptive(level);
        break;
    case ED:
        ans = findVertexCoverED(level);
        break;
    }

    return ans;
}

// construct 2^K APC
void WeightedHierarchicalApc::constructApc(int K) {
    if (this->K >= K) return;
    this->K = K;

    this->G.resize(K + 1, WeightedGraph(this->G[0].size()));

    for (int i = 0; i < K; i++) {
        vector<int> vc = findVertexCover(i);
        this->createOverlayGraph(vc, i);
    }
}

bool WeightedHierarchicalApc::checkVertexCover(const vector<int>& vc, int level) {
    WeightedGraph &G = this->G[level];
    int V = G.size();
    bool* used = new bool[V];

    for (int i = 0; i < V; i++) {
        used[i] = false;
    }

    for (int i = 0; i < (int)vc.size(); i++) {
        used[vc[i]] = true;
    }

    bool ans = true;

    for (int i = 0; i < V; i++) {
        int d = G.adj[i].size();
        int v = i;
        if (vertexLevel[v] < level) continue;
        for (int j = 0; j < d; j++) {
            int u = G.adj[v][j].to;
            if (vertexLevel[u] < level) continue;
            if (u != v && !used[v] && !used[u]) assert(false);
        }
    }
    delete[] used;    
    return ans;
}

void WeightedHierarchicalApc::createOverlayGraph(const vector<int> &vc, int level) {
    WeightedGraph &G = this->G[level + 1], &bG = this->G[level];
    checkVertexCover(vc, level);
    int V = G.size();    

    set<pair<int, int> > used;

    for (int i = 0; i < (int)vc.size(); i++) {
        int v = vc[i];
        vertexLevel[v] = level + 1;
    }

    for (int i = 0; i < V; i++) {
        if (vertexLevel[i] == level) {
            for (int j = 0; j < (int)bG.adjR[i].size(); j++) {
                int v = bG.adjR[i][j].to;
                int vw = bG.adjR[i][j].weight;
                assert(vertexLevel[v] == level + 1);
                for (int k = 0; k < (int)bG.adj[i].size(); k++) {
                    int u = bG.adj[i][k].to;
                    int uw = bG.adj[i][k].weight;
                    assert(vertexLevel[u] == level + 1);
                    if (v == u) continue;
                    G.addEdge(v, u, vw + uw);
                }
            }
        } else if (vertexLevel[i] == level + 1) {
            for (int j = 0; j < (int)bG.adj[i].size(); j++) {
                int v = bG.adj[i][j].to;
                int vw = bG.adj[i][j].weight;
                if (vertexLevel[v] == level + 1) {
                    G.addEdge(i, v, vw);
                }
            }
        }
    }
}

int WeightedHierarchicalApc::getNumEdge(const WeightedGraph &G) {
    int ans = 0;
    for (int i = 0; i < (int)G.size(); i++) {
        ans += G.adj[i].size();
    }
    return ans;
}

int WeightedHierarchicalApc::updateWeight(int from, int to, int weight) {
    return updateWeight(from, to, weight, 0);
}

int WeightedHierarchicalApc::updateWeight(int from, int to, int weight, int level) {
    assert(vertexLevel[from] >= level && vertexLevel[to] >= level);
    WeightedGraph &graph = G[level];
    int oldWeight = graph.getEdgeWeight(from, to);
    int ans = 1;
    assert(graph.edgeExists(from, to));
    if (oldWeight == weight) return 0;
    //cerr << "[" << level << "] update: " << from << " -> " << to << "  " << weight << " (" << oldWeight << ")" << endl;

    if (oldWeight > weight) {
        return addEdge(from, to, weight, level);
    }

    graph.updateWeight(from, to, weight);

    if (level == K) return ans;

    if (vertexLevel[from] > level && vertexLevel[to] > level) {
        // Case 1: both vertices exists in the overlay graph
        int newWeight = weight;
        {
            int i = 0, j = 0;
            while (i < (int)graph.adj[from].size() && j < (int)graph.adjR[to].size()) {
                WeightedEdge u = graph.adj[from][i], v = graph.adjR[to][j];
                if (u.to == v.to) {
                    if (vertexLevel[u.to] == level) {
                        newWeight = min(newWeight, u.weight + v.weight);
                    }
                    i++, j++;
                } else if (u.to < v.to) {
                    i++;
                } else {
                    j++;
                }
            }
        }
        ans += updateWeight(from, to, newWeight, level + 1);
    } else {
        // Case 2: one end of the edge is not in the overlay graph
        if (vertexLevel[from] == level) {
            for (int i = 0; i < (int)graph.adjR[from].size(); i++) {
                int newWeight = WeightedGraph::WEIGHT_MAX;
                int v = graph.adjR[from][i].to;
                if (v == to) continue;
                {
                    int j = 0, k = 0;
                    while (j < (int)graph.adj[v].size() && k < (int)graph.adjR[to].size()) {
                        WeightedEdge u = graph.adj[v][j], w = graph.adjR[to][k];
                        if (u.to == w.to) {
                            if (vertexLevel[u.to] == level) {
                                newWeight = min(newWeight, u.weight + w.weight);
                            }
                            j++, k++;
                        } else if (u.to < w.to) {
                            j++;
                        } else {
                            k++;
                        }
                    }
                }
                newWeight = min(newWeight, graph.getEdgeWeight(v, to)); // direct edge
                assert(newWeight != WeightedGraph::WEIGHT_MAX);
                ans += updateWeight(v, to, newWeight, level + 1);
            }
        } else if (vertexLevel[to] == level) {
            for (int i = 0; i < (int)graph.adj[to].size(); i++) {
                int newWeight = WeightedGraph::WEIGHT_MAX;
                int v = graph.adj[to][i].to;
                if (v == from) continue;
                {
                    int j = 0, k = 0;
                    while (j < (int)graph.adjR[v].size() && k < (int)graph.adj[from].size()) {
                        WeightedEdge u = graph.adjR[v][j], w = graph.adj[from][k];
                        if (u.to == w.to) {
                            if (vertexLevel[u.to] == level) {
                                newWeight = min(newWeight, u.weight + w.weight);
                            }
                            j++, k++;
                        } else if (u.to < w.to) {
                            j++;
                        } else {
                            k++;
                        }
                    }
                }
                newWeight = min(newWeight, graph.getEdgeWeight(from, v));
                assert(newWeight != WeightedGraph::WEIGHT_MAX);
                ans += updateWeight(from, v, newWeight, level + 1);
            }
        } else {
            assert(false);
        }
    }
    return ans;
}

void WeightedHierarchicalApc::deleteEdge(int from, int to, int level) {
    //cerr << "delete: " << from << " -> " << to << " (" << level << ")" << endl;
    assert(vertexLevel[from] >= level && vertexLevel[to] >= level);
    WeightedGraph &graph = G[level];
    if (!graph.edgeExists(from, to)) return;
    
    graph.deleteEdge(from, to);

    if (level == K) return;
    
    if (vertexLevel[from] > level && vertexLevel[to] > level) {
        // Case 1: both vertices exists in the overlay graph
        deleteEdge(from, to, level + 1);
    } else {
        // Case 2: one end of the edge is not in the overlay graph
        if (vertexLevel[from] == level) {
            for (int i = 0; i < (int)graph.adjR[from].size(); i++) {
                int newWeight = WeightedGraph::WEIGHT_MAX;
                int v = graph.adjR[from][i].to;
                if (v == to) continue;
                for (int j = 0; j < (int)graph.adj[v].size(); j++) {
                    // find vertices that will be contracted
                    int u = graph.adj[v][j].to;
                    if (vertexLevel[u] != level) continue;
                    newWeight = min(newWeight, graph.adj[v][j].weight + graph.getEdgeWeight(u, to));
                }
                newWeight = min(newWeight, graph.getEdgeWeight(v, to)); // direct edge
                if (newWeight == WeightedGraph::WEIGHT_MAX) {
                    deleteEdge(v, to, level + 1);
                } else {
                    updateWeight(v, to, newWeight, level + 1);
                }
            }
        } else if (vertexLevel[to] == level) {
            for (int i = 0; i < (int)graph.adj[to].size(); i++) {
                int newWeight = WeightedGraph::WEIGHT_MAX;
                int v = graph.adj[to][i].to;
                if (v == from) continue;
                for (int j = 0; j < (int)graph.adjR[v].size(); j++) {
                    int u = graph.adjR[v][j].to;
                    if (vertexLevel[u] != level) continue;
                    newWeight = min(newWeight, graph.adjR[v][j].weight + graph.getEdgeWeight(from,u));
                }
                newWeight = min(newWeight, graph.getEdgeWeight(from, v));
                if (newWeight == WeightedGraph::WEIGHT_MAX) {
                    deleteEdge(from, v, level + 1);
                } else {
                    updateWeight(from, v, newWeight, level + 1);
                }
            }
        } else {
            assert(false);
        }
    }
}

/* 
   Add an edge from u to v
   If there already exists one, keep shorter one.
*/
int WeightedHierarchicalApc::addEdge(int from, int to, int weight, int level) {
    //cerr << "add: " << from << " -> " << to << "  " << weight << " (" << level << ")" << endl;
    assert(vertexLevel[from] >= level && vertexLevel[to] >= level);
    WeightedGraph &graph = G[level];
    int ans = 1;
    if (graph.getEdgeWeight(from, to) <= weight) return 0;

    graph.addEdge(from, to, weight);

    if (level == K) return ans;

    if (vertexLevel[from] > level && vertexLevel[to] > level) {
        // Case 1: both vertices exists in the overlay graph
        ans += addEdge(from, to, weight, level + 1);
    } else if (vertexLevel[from] > level || vertexLevel[to] > level) {
        // Case 2: one end of the edge is not in the overlay graph
        if (vertexLevel[from] == level) {
            for (int i = 0; i < (int)graph.adjR[from].size(); i++) {
                int v = graph.adjR[from][i].to;
                if (v == to) continue;
                ans += addEdge(v, to, graph.adjR[from][i].weight + weight, level + 1); // new edge
            }
        } else if (vertexLevel[to] == level) {
            for (int i = 0; i < (int)graph.adj[to].size(); i++) {
                int v = graph.adj[to][i].to;
                if (v == from) continue;
                ans += addEdge(from, v, weight + graph.adj[to][i].weight, level + 1); // new edge
            }
        } else {
            assert(false);
        }
    } else {
        // Case 3: both ends of the edge are not in the overlay graph
        cerr << "not implemented" << endl;
        assert(false);
    }
    return ans;
}
