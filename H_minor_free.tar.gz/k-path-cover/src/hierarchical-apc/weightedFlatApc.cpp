#include "weightedFlatApc.hpp"
#include <algorithm>
#include "../common/jlog.h"

using namespace std;
using namespace graphUtils;

void WeightedFlatApc::constructApcViaHierarchical(int K, VCHeuristics heuristic) {
	this->K = K;

	WeightedHierarchicalApc hapc(G0, heuristic);
	hapc.constructApc(K);

	G1 = hapc.G.back();
	for (int i = 0; i < V; ++i) vertexApc[i] = (hapc.vertexLevel[i] == K);
}

int WeightedFlatApc::updateWeight(int from, int to, int weight) {
	assert(G0.edgeExists(from, to));
	int originalWeight = G0.getEdgeWeight(from, to);

	//increaseWeight(from, to, weight); exit(0);

	if (originalWeight > weight) return decreaseWeight(from, to, weight);
	if (originalWeight < weight) return increaseWeight(from, to, weight);
	return 0;
}

void WeightedFlatApc::outputStatistics() {
	JLOG_PUT("num_vs", V);
	//JLOG_PUT("num_es", G0.edgeList.size());
	JLOG_PUT("num_apc_vs", count(vertexApc.begin(), vertexApc.end(), true));
	//JLOG_PUT("num_apc_es", G1.edgeList.size());
}

int WeightedFlatApc::decreaseWeight(int from, int to, int weight) {
	assert(weight <= G0.getEdgeWeight(from, to));
	G0.updateWeight(from, to, weight);

	// Step1: Forward Dijkstra search from |to|
	map<int, int> fwdDist;
	{
		priority_queue<pair<int, int>, vector<pair<int, int>>, greater<pair<int, int>>> que;
		map<int, int> pot;
		que.push(make_pair(0, to));
		pot[to] = 0;
		while (!que.empty()) {
			int v = que.top().second;
			int d = que.top().first;
			que.pop();
			if (d > pot[v] || vertexApc[v]) continue;
			for (const auto &e : G0.adj[v]) {
				int tv = e.to, td = d + e.weight;
				if (!pot.count(tv) || td < pot[tv]) {
					que.push(make_pair(td, tv));
					pot[tv] = td;
				}
			}
		}
		for (auto p : pot) {
			if (vertexApc[p.first]) fwdDist[p.first] = p.second;
		}
	}

	// Step2: Backward Dijkstra search from |from|
	map<int, int> bwdDist;
	{
		priority_queue<pair<int, int>, vector<pair<int, int>>, greater<pair<int, int>>> que;
		map<int, int> pot;
		que.push(make_pair(0, from));
		pot[from] = 0;
		while (!que.empty()) {
			int v = que.top().second;
			int d = que.top().first;
			que.pop();
			if (d > pot[v] || vertexApc[v]) continue;
			for (const auto &e : G0.adjR[v]) {  // be careful :-)
				int tv = e.to, td = d + e.weight;
				if (!pot.count(tv) || td < pot[tv]) {
					que.push(make_pair(td, tv));
					pot[tv] = td;
				}
			}
		}
		for (auto p : pot) {
			if (vertexApc[p.first]) bwdDist[p.first] = p.second;
		}
	}

	if (0) {
		JLOG_PUT("num_fwd_vs", fwdDist.size());
		JLOG_PUT("num_bwd_vs", bwdDist.size());
	}

	// Step3: Examine possible overlay edges via the new edge
	int numChangedEdges = 0;
	for (auto f : fwdDist) {
		for (auto b : bwdDist) {
			int u = b.first, v = f.first;
			assert(vertexApc[u] && vertexApc[v]);
			if (u == v) continue;
			assert(G1.edgeExists(u, v));

			int d = b.second + weight + f.second;
			if (d < G1.getEdgeWeight(u, v)) {
				G1.updateWeight(u, v, d);
				++numChangedEdges;
			}
		}
	}
	return numChangedEdges;
}

int WeightedFlatApc::increaseWeight(int from, int to, int weight) {
	// assert(weight >= G0.getEdgeWeight(from, to));  // This function correctly works when decreased
	G0.updateWeight(from, to, weight);
	int numChangedEdges = 0;

	// Step1: Find boundary vertices
	vector<int> boundary_vs;  // boundary vertices
	{
		/*
		 * Note that we actually do not need to recognize whether given vertices are in the APC;
		 * the following carefully-written search finds appropriate boundaries automatically and efficiently.
		 */
		queue<int> que;
		set<int> vis;
		que.push(from);
		//que.push(to);
		vis.insert(from);
		//vis.insert(to);

		while (!que.empty()) {
			int v = que.front();
			que.pop();

			if (vertexApc[v]) {
				boundary_vs.push_back(v);
			} else {
				for (const auto &e : G0.adjR[v]) {
					if (vis.count(e.to)) continue;
					que.push(e.to);
					vis.insert(e.to);
				}
			}
		}

		if (0) {
			JLOG_OPEN("step1") {
				JLOG_PUT("num_boundary_vs", boundary_vs.size());
				JLOG_PUT("num_visited_vs", vis.size());
			}
		}
	}

	// Step 2: Conduct Dijkstra searches from boundary vertices
	for (int s : boundary_vs) {
		priority_queue<pair<int, int>, vector<pair<int, int>>, greater<pair<int, int>>> que;
		map<int, int> pot;
		que.push(make_pair(0, s));
		pot[s] = 0;

		while (!que.empty()) {
			int v = que.top().second;
			int d = que.top().first;
			que.pop();
			if (d > pot[v]) continue;

			if (vertexApc[v] && v != s) {
				assert(G1.edgeExists(s, v));
				if (d != G1.getEdgeWeight(s, v)) {
					G1.updateWeight(s, v, d);
					++numChangedEdges;
				}
			} else {
				for (const auto &e : G0.adj[v]) {
					int tv = e.to, td = d + e.weight;
					if (!pot.count(tv) || td < pot[tv]) {
						que.push(make_pair(td, tv));
						pot[tv] = td;
					}
				}
			}
		}
		if (0) {
			JLOG_ADD_OPEN("step2") {
				JLOG_PUT("num_visited_vs", pot.size());
			}
		}
	}

	return numChangedEdges;
}
