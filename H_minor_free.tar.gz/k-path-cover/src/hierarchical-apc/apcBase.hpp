#pragma once

class ApcBase {
public:
    ApcBase() {}
    virtual ~ApcBase() {}
    virtual int updateWeight(int u, int v, int weight) = 0;
};
