#pragma once

#include "../common/graphUtils.hpp"
#include "apcBase.hpp"
#include "weightedHierarchicalApc.hpp"

class WeightedFlatApc : ApcBase {
public:
	WeightedFlatApc(const graphUtils::WeightedGraph &G)
	: V(G.size()), K(0), G0(G), G1(0), vertexApc(V, false)	{}
	virtual ~WeightedFlatApc() {}

	int V, K;  // Meaning of K is...???
	graphUtils::WeightedGraph G0, G1;  // G0 := given graph, G1 := APC overlay graph
	std::vector<bool> vertexApc;  // true <=> in APC

	// Variables for update

	void constructApcViaHierarchical(int K, VCHeuristics heuristic);
	virtual int updateWeight(int u, int v, int weight);

	void outputStatistics();

private:
	int decreaseWeight(int u, int v, int weight);
	int increaseWeight(int u, int v, int weight);
};
