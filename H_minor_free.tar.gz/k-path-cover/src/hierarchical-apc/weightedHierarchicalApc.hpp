#pragma once
#include <queue>
#include <vector>
#include <cassert>
#include <set>
#include "../common/graphUtils.hpp"
#include "apcBase.hpp"

enum VCHeuristics {
    LR_DEG,
    LR_ADAPTIVE,
    LL_DEG,
    LL_ADAPTIVE,
    ED
};

class WeightedHierarchicalApc : ApcBase {
public:
    WeightedHierarchicalApc(const graphUtils::WeightedGraph &G, VCHeuristics heuristc);

    int V;

    std::vector<graphUtils::WeightedGraph> G;
    std::vector<int> vertexLevel;
    int K;
    
    VCHeuristics heuristic;

    std::vector<int> findVertexCoverLRDeg(int level);
    std::vector<int> findVertexCoverLRAdaptive(int level);
    std::vector<int> findVertexCoverLLDeg(int level);
    std::vector<int> findVertexCoverLLAdaptive(int level);
    std::vector<int> findVertexCoverED(int level);
    std::vector<int> findVertexCover(int level);

    void constructApc(int K);

    bool checkVertexCover(const std::vector<int>& vc, int level);
    void createOverlayGraph(const std::vector<int> &vc, int level);
    static int getNumEdge(const graphUtils::WeightedGraph &G);

    int updateWeight(int u, int v, int weight);
    int updateWeight(int u, int v, int weight, int level);
    void deleteEdge(int u, int v, int level = 0);
    int addEdge(int u, int v, int weight, int level = 0);
};
