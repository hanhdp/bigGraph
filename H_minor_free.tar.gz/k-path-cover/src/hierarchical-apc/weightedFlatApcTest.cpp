#include "weightedHierarchicalApc.hpp"
#include "weightedFlatApc.hpp"
#include "../common/graphUtils.hpp"
#include "../common/jlog.h"
#include <iostream>
#include <string>
#include <random>
#include <algorithm>

using namespace std;
using namespace graphUtils;

string heuristicsName[5] = {"LR_DEG", "LR_ADAPTIVE", "LL_DEG", "LL_ADAPTIVE", "ED"};

int main(int argc, char** argv) {
    const int K = 10;
    JLOG_INIT(&argc, argv);

    if (argc <= 1) {
        cout << "Usage: ./hierarchical_bench [input file]" << endl;
        return 0;
    }

    random_device seed_gen;
    unsigned int seed = seed_gen();
    default_random_engine engine(seed);

    WeightedGraph G(0);
    JLOG_PUT_BENCHMARK("time.load") {
    	G = readWeightedGraph(argv[1]);
    }

    cerr << "load" << endl;

    WeightedFlatApc apc(G);

    // Construct test set
    vector<pair<pair<int, int>, int> > edges;
    for (int i = 0; i < G.V; i++) {
        for (int j = 0; j < (int)G.adj[i].size(); j++) {
            WeightedEdge e = G.adj[i][j];
            edges.push_back({{i, e.to}, e.weight});
        }
    }
    const int numQuery = min(100, (int)edges.size());
    {
        // random shuffle
        for (int i = 0; i < numQuery; i++) {
            uniform_int_distribution<> distr(0, (int)edges.size() - 1 - i);
            swap(edges[i], edges[distr(engine) + i]);
        }
    }

    JLOG_OPEN("experiment") {
        JLOG_PUT("input_file", basename(argv[1]));
        JLOG_PUT("k", K);
        JLOG_PUT("num_query", numQuery);
        JLOG_PUT("seed", seed);
    }

    //for (int i = 0; i < 5; i++) {
    JLOG_ADD_OPEN("results") {
    // Verification
    {
        //JLOG_PUT("heuristic", heuristicsName[i]);
        JLOG_PUT_BENCHMARK("elapsed") {
            apc.constructApcViaHierarchical(K, LL_DEG);
        }
        apc.outputStatistics();
        /*
		WeightedGraph originalAPC = apc.G1;
		int numChangedEdges = 0;
		JLOG_PUT_BENCHMARK("total_update") {
			for (int j = 0; j < numQuery; ++j) {
				numChangedEdges += apc.updateWeight(edges[j].first.first, edges[j].first.second, edges[j].second / 2);
				numChangedEdges += apc.updateWeight(edges[j].first.first, edges[j].first.second, edges[j].second);
				assert(apc.G1.edgeList == originalAPC.edgeList);
			}
		}
		JLOG_PUT("total_num_changed_edges", numChangedEdges);
		JLOG_PUT("average_num_changed_edges", numChangedEdges / (2.0 * numQuery));;
        */
    }

    // Benchmark
    JLOG_OPEN("large"){
        int updated = 0;
        JLOG_PUT_BENCHMARK("update_time_decrease") {
            for (int j = 0; j < numQuery; j++) {
                updated += apc.updateWeight(edges[j].first.first, edges[j].first.second, edges[j].second / 2);
            }
        }
        JLOG_PUT("updated_edge_decrease", updated);

        updated = 0;

        JLOG_PUT_BENCHMARK("update_time_increase") {
            for (int j = numQuery - 1; j >= 0; j--) {
                updated += apc.updateWeight(edges[j].first.first, edges[j].first.second, edges[j].second);
            }
        }
        JLOG_PUT("updated_edge_increase", updated);
    }

    JLOG_OPEN("small"){
        int updated = 0;
        JLOG_PUT_BENCHMARK("update_time_decrease") {
            for (int j = 0; j < numQuery; j++) {
                updated += apc.updateWeight(edges[j].first.first, edges[j].first.second, edges[j].second / 2);
            }
        }
        JLOG_PUT("updated_edge_decrease", updated);

        updated = 0;

        JLOG_PUT_BENCHMARK("update_time_increase") {
            for (int j = numQuery - 1; j >= 0; j--) {
                updated += apc.updateWeight(edges[j].first.first, edges[j].first.second, edges[j].second);
            }
        }
        JLOG_PUT("updated_edge_increase", updated);
    }
    }
    //}

    return 0;
}
