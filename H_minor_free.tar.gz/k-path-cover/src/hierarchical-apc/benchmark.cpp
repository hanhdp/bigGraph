#include "hierarchicalApc.hpp"
#include "../common/graphUtils.hpp"
#include "../common/jlog.h"
#include <iostream>
#include <string>

using namespace std;
using namespace graphUtils;

string heuristicsName[5] = {"LR_DEG", "LR_ADAPTIVE", "LL_DEG", "LL_ADAPTIVE", "ED"};

int main(int argc, char** argv) {
    const int K = 10;
    JLOG_INIT(&argc, argv);
    
    if (argc <= 1) {
        cout << "Usage: ./hierarchical_bench [input file]" << endl;
        return 0;
    }
    Graph G = readUGraph(argv[1]);

    cerr << "load" << endl;

    JLOG_OPEN("experiment") {
        JLOG_PUT("input_file", basename(argv[1]));
        JLOG_PUT("k", K);
    }

    for (int i = 0; i < 5; i++) {
        JLOG_ADD_OPEN("results") {
        HierarchicalApc hapc(G, VCHeuristics(i));
        JLOG_PUT("heuristic", heuristicsName[i]);
        JLOG_PUT_BENCHMARK("elapsed") {
            hapc.constructApc(K);
        }
        for (int j = 0; j <= K; j++) {
            JLOG_ADD_OPEN("layer") {
            JLOG_PUT("k", 1 << j);
            JLOG_PUT("V", hapc.numVC[j]);
            JLOG_PUT("E", hapc.numEdge[j]);
            JLOG_PUT("max_degree", hapc.maxDegree[j]);
            }
        }
        }
    }

    return 0;
}
