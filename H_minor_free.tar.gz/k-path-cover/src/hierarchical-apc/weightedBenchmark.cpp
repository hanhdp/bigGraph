#include "weightedHierarchicalApc.hpp"
#include "../common/graphUtils.hpp"
#include "../common/jlog.h"
#include <iostream>
#include <string>
#include <random>
#include <algorithm>
#include <gflags/gflags.h>

using namespace std;
using namespace graphUtils;

DEFINE_int32(k, 2, "value of k");

string heuristicsName[5] = {"LR_DEG", "LR_ADAPTIVE", "LL_DEG", "LL_ADAPTIVE", "ED"};

int main(int argc, char** argv) {
    JLOG_INIT(&argc, argv);
    google::ParseCommandLineFlags(&argc, &argv, true);
    const int K = FLAGS_k;
    
    if (argc <= 1) {
        cout << "Usage: ./hierarchical_bench [input file]" << endl;
        return 0;
    }

    random_device seed_gen;
    unsigned int seed = seed_gen();
    default_random_engine engine(seed);

    WeightedGraph G(0);
    JLOG_PUT_BENCHMARK("load") {
      G = readWeightedGraph(argv[1]);
    }
    int V = G.size();
    int E = 0;
    for (int i = 0; i < V; i++) {
      E += G.adj[i].size();
    }    

    cerr << "load" << endl;

    JLOG_OPEN("experiment") {
        JLOG_PUT("input_file", basename(argv[1]));
        JLOG_PUT("k", 1 << K);
        JLOG_PUT("seed", seed);
        JLOG_PUT("method", "hierarchical");
        JLOG_PUT("V", V);
        JLOG_PUT("E", E);
    }

    for (int i = 0; i < 5; i++) {
        JLOG_ADD_OPEN("results") {
        WeightedHierarchicalApc hapc(G, VCHeuristics(i));
        JLOG_PUT("heuristic", heuristicsName[i]);
        JLOG_PUT_BENCHMARK("elapsed") {
            hapc.constructApc(K);
        }
        
        int numVC = 0;
        int maxDeg = 0;
        for (int k = 0; k < hapc.V; k++) {
            if (hapc.vertexLevel[k] >= K) numVC++;
            maxDeg = max(maxDeg, (int)hapc.G[K].adj[k].size() + (int)hapc.G[K].adjR[k].size());
        }
        
        JLOG_PUT("V", numVC);
        JLOG_PUT("E", WeightedHierarchicalApc::getNumEdge(hapc.G[K]));
        JLOG_PUT("max_degree", maxDeg);
        }
    }

    return 0;
}
