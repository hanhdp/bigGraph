#include <queue>
#include <vector>
#include <cassert>
#include <set>
#include <iostream>
#include <algorithm>
#include "../common/graphUtils.hpp"
#include "weightedFunkeApc.hpp"
#include "../common/jlog.h"

using namespace std;
using namespace graphUtils;

WeightedFunkeApc::WeightedFunkeApc(const WeightedGraph &G) : 
    V(G.size()),
    G0(0),
    G1(0),
    vertexLevel(vector<int>(V, 0)),
    K(0) {
    this->G0 = G;
}

// construct K APC
void WeightedFunkeApc::constructApc(int K) {
    vector<bool> visited(V);
    vector<int> cover;
    JLOG_PUT_BENCHMARK("time.cover") {
    this->K = K;
    vector<int> vertexOrder = getCompOrder(G0);

    vertexLevel = vector<int>(V, 1);
    for (int i = 0; i < (int)vertexOrder.size(); i++) {
        int v = vertexOrder[i];
        if (!isNecessary(v, K, v, 1, visited)) {
            vertexLevel[v] = 0;
        } else {
            cover.push_back(v);
        }
    }
    }

    JLOG_PUT_BENCHMARK("time.overlay") {
        createOverlayGraph(cover);
    }
}


void WeightedFunkeApc::createOverlayGraph(const vector<int> &C) {
    G1 = WeightedGraph(G0.V);
    priority_queue<pair<int, int>, vector<pair<int, int> >, greater<pair<int, int> > > q; // cost, id;
    vector<int> visited(G0.V, -1);

    for (int i = 0; i < G0.V; i++) {
        if (vertexLevel[i] == 0) continue;
        q.push({0, i});
        
        while (!q.empty()) {
            pair<int, int> e = q.top();
            q.pop();
            int cost = e.first;
            int v = e.second;
            
            if (visited[v] == i) continue;
            visited[v] = i;

            if (v != i && vertexLevel[v] > 0) {
                G1.addEdge(i, v, cost);
                continue;
            }

            for (int j = 0; j < (int)G0.adj[v].size(); j++) {
                q.push({cost + G0.adj[v][j].weight, G0.adj[v][j].to});
            }
        }
    }
}

int WeightedFunkeApc::updateWeight(int from, int to, int weight) {
    return 0;
}

vector<int> WeightedFunkeApc::getDegreeOrder(WeightedGraph &G) {
    vector<int> order;
    priority_queue<pair<int, int> > q;// degree, id;

    for (int i = 0; i < G.V; i++) {
        q.push({(int)G.adj[i].size() + G.adjR[i].size(), i});
    }

    while (!q.empty()) {
        pair<int, int> e = q.top();
        q.pop();
        order.push_back(e.second);
    }

    reverse(order.begin(), order.end());

    return order;
}

vector<int> WeightedFunkeApc::getCompOrder(WeightedGraph &G) {
  vector<int> order;
  vector<bool> vis(G.size());
  getCompOrderDfs(0, G, order, vis);
  return order;
}

void WeightedFunkeApc::getCompOrderDfs(int v, WeightedGraph &G, vector<int>& order, vector<bool>& visited) {
  if (visited[v]) return;
  visited[v] = true;
  for (int i = 0; i < (int)G.adj[v].size(); i++) {
    int u = G.adj[v][i].to;
    getCompOrderDfs(u, G, order, visited);
  }
  order.push_back(v);
}

bool WeightedFunkeApc::isNecessary(int v, int k, int root, int depth, vector<bool>& visited) {
    if (visited[v]) return false;
    if (v != root && vertexLevel[v]) return false;
    if (depth == k) return true;

    visited[v] = true;
    for (int i = 0; i < (int)G0.adjR[root].size(); i++) {
        if (reverseDFS(G0.adjR[root][i].to, k, depth + 1, visited)) {
            visited[v] = false;
            return true;
        }
    }

    // recurse
    for (int i = 0; i < (int)G0.adj[v].size(); i++) {
        if (isNecessary(G0.adj[v][i].to, k, root, depth + 1, visited)) {
            visited[v] = false;
            return true;
        }
    }

    visited[v] = false;
    return false;
}

bool WeightedFunkeApc::reverseDFS(int v, int k, int depth, vector<bool>& visited) {
    if (visited[v]) return false;
    if (vertexLevel[v]) return false;
    if (depth == k) return true;

    visited[v] = true;

    for (int i = 0; i < (int)G0.adj[v].size(); i++) {
        if (reverseDFS(G0.adj[v][i].to, k, depth + 1, visited)) {
            visited[v] = false;
            return true;
        }
    }

    visited[v] = false;
    return false;
}
