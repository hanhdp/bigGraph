#include "weightedFunkeApc.hpp"
#include "../common/graphUtils.hpp"
#include "../common/jlog.h"
#include <iostream>
#include <string>
#include <random>
#include <algorithm>
#include <gflags/gflags.h>

using namespace std;
using namespace graphUtils;

DEFINE_int32(k, 2, "value of k");

int main(int argc, char** argv) {
    JLOG_INIT(&argc, argv);
    google::ParseCommandLineFlags(&argc, &argv, true);

    const int K = 1 << FLAGS_k;

    if (argc <= 1) {
        cout << "Usage: ./weighted_funke_test [input file]" << endl;
        return 0;
    }

    random_device seed_gen;
    unsigned int seed = seed_gen();
    default_random_engine engine(seed);

    WeightedGraph G(0);
    JLOG_PUT_BENCHMARK("load") {
    	G = readWeightedGraph(argv[1]);
    }

    cerr << "load" << endl;

    WeightedFunkeApc apc(G);

    JLOG_OPEN("experiment") {
        JLOG_PUT("input_file", basename(argv[1]));
        JLOG_PUT("k", K);
        JLOG_PUT("seed", seed);
        JLOG_PUT("method", "Funke");
    }

    //for (int i = 0; i < 5; i++) {
    JLOG_ADD_OPEN("results") {
    // Verification
    {
        JLOG_PUT_BENCHMARK("elapsed") {
            apc.constructApc(K);
        }

        int numVC = 0;
        int numE = 0;
        int maxDeg = 0;
        for (int k = 0; k < apc.G1.V; k++) {
            if (apc.vertexLevel[k] > 0) numVC++;
            numE += apc.G1.adj[k].size();
            maxDeg = max(maxDeg, (int)apc.G1.adj[k].size() + (int)apc.G1.adjR[k].size());
        }
        

        JLOG_PUT("V", numVC);
        JLOG_PUT("E", numE);
        JLOG_PUT("max_degree", maxDeg);
    }
    }

    return 0;
}
