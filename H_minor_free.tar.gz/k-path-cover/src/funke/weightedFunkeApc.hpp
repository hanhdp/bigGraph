#pragma once
#include <queue>
#include <vector>
#include <cassert>
#include <set>
#include "../common/graphUtils.hpp"
#include "../hierarchical-apc/apcBase.hpp"

class WeightedFunkeApc : ApcBase {
public:
    WeightedFunkeApc(const graphUtils::WeightedGraph &G);

    int V;

    graphUtils::WeightedGraph G0, G1;
    std::vector<int> vertexLevel;
    int K;

    void constructApc(int K);
    void createOverlayGraph(const std::vector<int> &C);
    int updateWeight(int u, int v, int weight);

private:
    std::vector<int> getDegreeOrder(graphUtils::WeightedGraph &G);
    std::vector<int> getCompOrder(graphUtils::WeightedGraph &G);
    void getCompOrderDfs(int v, graphUtils::WeightedGraph &G, std::vector<int>& order, std::vector<bool>& vis);
    bool isNecessary(int v, int k, int root, int depth, std::vector<bool>& visited);
    bool reverseDFS(int v, int k, int depth, std::vector<bool>& visited);
};
