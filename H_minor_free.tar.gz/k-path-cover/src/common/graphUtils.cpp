#include <vector>
#include <string>
#include <fstream>
#include <algorithm>
#include <cstdio>
#include <map>
#include <set>
#include <cassert>
#include <iostream>
#include "graphUtils.hpp"

using namespace std;

namespace graphUtils {
    Graph readGraph(const char* fileName) {
        Graph res;
        ifstream ifs(fileName);
        string line;
        int it = 0;
        map<int, int> m;
        while (getline(ifs, line)) {
            if (line[0] == '#') continue;
            int u, v;
            sscanf(line.c_str(), "%d %d", &u, &v);
            if (m.find(u) == m.end()) {
                m[u] = it++;
                res.push_back(vector<int>());
            }
            if (m.find(v) == m.end()) {
                m[v] = it++;
                res.push_back(vector<int>());
            }

            if (u == v) continue;

            res[m[u]].push_back(m[v]);
            res[m[v]].push_back(m[u]);
        }
        return res;
    }

    Graph readUGraph(const char* fileName) {
        Graph res;
        ifstream ifs(fileName);
        string line;
        int it = 0;
        map<int, int> m;
        set<pair<int, int> > memo;
        while (getline(ifs, line)) {
            if (line[0] == '#') continue;
            int u, v;
            sscanf(line.c_str(), "%d %d", &u, &v);
            if (m.find(u) == m.end()) {
                m[u] = it++;
                res.push_back(vector<int>());
            }
            if (m.find(v) == m.end()) {
                m[v] = it++;
                res.push_back(vector<int>());
            }

            int uid = m[u], vid = m[v];
            if (uid > vid) swap(uid, vid);
            if (memo.find(make_pair(uid,vid)) != memo.end()) continue;
            memo.insert(make_pair(uid, vid));

            res[uid].push_back(vid);
            res[vid].push_back(uid);
        }
        return res;
    }

    WeightedGraph readWeightedGraph(const char* fileName) {
        ifstream ifs(fileName);
        string line;
        int it = 0;
        map<int, int> m;
        set<pair<pair<int, int>, int> > memo;
        while (getline(ifs, line)) {
            if (line[0] == '#') continue;
            int u, v, w;
            sscanf(line.c_str(), "%d %d %d", &u, &v, &w);
            if (u == v) continue;
            if (m.find(u) == m.end()) {
                m[u] = it++;
            }
            if (m.find(v) == m.end()) {
                m[v] = it++;
            }

            int uid = m[u], vid = m[v];
            memo.insert(make_pair(make_pair(uid, vid), w));
        }
        WeightedGraph res(it);
        for (auto &x : memo) {
            res.addEdge(x.first.first, x.first.second, x.second);
        }
        return res;
    }

    void saveGraph(Graph G, const char* fileName) {
        ofstream ofs(fileName);
        /*
        ofs << G.size() << endl;
        int E = 0;
        for (int i = 0; i < (int)G.size(); i++) {
            E += G[i].size();
        }
        //ofs << E << endl;
        */
        for (int i = 0; i < (int)G.size(); i++) {
            for (int j = 0; j < (int)G[i].size(); j++) {
                if (i > G[i][j]) continue;
                ofs << i << "\t\t" << G[i][j] << endl;
            }
        }
    }

    double getSec() {
        struct timeval tv;
        gettimeofday(&tv, NULL);
        return (double)tv.tv_sec + tv.tv_usec * 1.0e-6;
    }

    void WeightedGraph::addEdge(int from, int to, int weight) {
        auto it = lower_bound(adj[from].begin(), adj[from].end(), WeightedEdge(to, 0));
        if (it != adj[from].end() && it->to == to) {
            if (it->weight > weight) {
                // updateWeight
                it->weight = weight;
                it = lower_bound(adjR[to].begin(), adjR[to].end(), WeightedEdge(from, 0));
                assert(it != adjR[to].end() && it->to == from && it->weight > weight);
                it->weight = weight;
            }
        } else {
            adj[from].insert(it, WeightedEdge(to, weight));
            it = lower_bound(adjR[to].begin(), adjR[to].end(), WeightedEdge(from, 0));
            assert(!(it != adjR[to].end() && it->to == from));
            adjR[to].insert(it, WeightedEdge(from, weight));
        }
    }

    void WeightedGraph::deleteEdge(int from, int to) {
        auto it = lower_bound(adj[from].begin(), adj[from].end(), WeightedEdge(to, 0));
        if (it != adj[from].end() && it->to == to) {
            adj[from].erase(it);
            it = lower_bound(adjR[to].begin(), adjR[to].end(), WeightedEdge(from, 0));
            assert(it != adjR[to].end() && it->to == from);
            adjR[to].erase(it);
        }
    }

    void WeightedGraph::updateWeight(int from, int to, int weight) {
        auto it = lower_bound(adj[from].begin(), adj[from].end(), WeightedEdge(to, 0));
        if (it != adj[from].end() && it->to == to) {
            it->weight = weight;
            it = lower_bound(adjR[to].begin(), adjR[to].end(), WeightedEdge(from, 0));
            assert(it != adjR[to].end() && it->to == from);
            it->weight = weight;
        } else {
            // addEdge
            adj[from].insert(it, WeightedEdge(to, weight));
            it = lower_bound(adjR[to].begin(), adjR[to].end(), WeightedEdge(from, 0));
            assert(!(it != adjR[to].end() && it->to == from));
            adjR[to].insert(it, WeightedEdge(from, weight));
        }
    }

    bool WeightedGraph::edgeExists(int from, int to) {
        auto it = lower_bound(adj[from].begin(), adj[from].end(), WeightedEdge(to, 0));
        return it != adj[from].end() && it->to == to;
    }

    int WeightedGraph::getEdgeWeight(int from, int to) {
        auto it = lower_bound(adj[from].begin(), adj[from].end(), WeightedEdge(to, 0));
        return (it == adj[from].end() || it->to != to) ? WeightedGraph::WEIGHT_MAX : it->weight;
    }
};
