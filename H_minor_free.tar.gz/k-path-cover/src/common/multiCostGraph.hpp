#pragma once

#include <vector>
#include <string>
#include <utility>
#include <cstdint>
#include <memory>

namespace multiCostGraph {

    typedef double Cost;
    typedef std::vector<Cost> CostVector;  
    typedef unsigned int Vertex;

    class MultiCostEdge {
    public:
        Vertex to;
        std::vector<CostVector> cost;
    };

    class MultiCostGraph {
    public:
        int V;
        int dimension;
        std::vector<std::vector<MultiCostEdge> > edgeFw, edgeBw;

        void addEdge(Vertex from, Vertex to, CostVector c);
    };
    
    MultiCostGraph* readMultiCostGraph(const char* fileName);
}
