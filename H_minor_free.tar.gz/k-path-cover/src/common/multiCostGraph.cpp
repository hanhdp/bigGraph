#include <fstream>
#include <vector>
#include <unordered_map>
#include <cassert>
#include <sstream>
#include "multiCostGraph.hpp"

using namespace std;
using namespace multiCostGraph;

void MultiCostGraph::addEdge(Vertex from, Vertex to, CostVector c) {
    MultiCostEdge ef, eb;
    ef.to = to;
    ef.cost.push_back(c);
    eb.to = from;
    eb.cost.push_back(c);
    this->edgeFw[from].push_back(ef);
    this->edgeBw[to].push_back(eb);
}

MultiCostGraph* readMultiCostGraph(const char* fileName) {
    MultiCostGraph* graph = new MultiCostGraph;
    ifstream ifs(fileName);

    {
        string line;
        int V = 0;
        int dimension = -1;
        while (getline(ifs, line)) {
            stringstream ss(line);
            int from, to;
            ss >> from >> to;
            CostVector cost;
            Cost val;
            while (ss >> val) {
                cost.push_back(val);
            }
            V++;
            if (dimension == -1) {
                dimension = cost.size();
            } else {
                assert(dimension == (int)cost.size());
            }
            graph->addEdge(from, to, cost);
        }
    }

    return graph;
}
