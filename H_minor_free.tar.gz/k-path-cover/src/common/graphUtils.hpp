#pragma once

#include <vector>
#include <string>
#include <map>
#include <sys/time.h>

namespace graphUtils {
    typedef std::vector<std::vector<int> > Graph;
    
    Graph readGraph(const char* fileName);
    Graph readUGraph(const char* fileName);
    void saveGraph(Graph G, const char* fileName);

    double getSec();

    class WeightedEdge {
    public:
        int to;
        int weight;

        WeightedEdge(int to, int weight) : to(to), weight(weight) {
        }

        inline bool operator<(const WeightedEdge& a) const {
            return to < a.to;
        }
        inline bool operator==(const WeightedEdge& a) const {
            return to == a.to && weight == a.weight;
        }
    };

    class WeightedGraph {
    public:
        static const int WEIGHT_MAX = 1 << 29;
        static const int WEIGHT_MIN = -(1 << 29);
        int V;
        std::vector<std::vector<WeightedEdge> > adj, adjR;

        explicit WeightedGraph(int V) : V(V) {
            adj.resize(V);
            adjR.resize(V);
        }

        void addEdge(int from, int to, int weight);
        void deleteEdge(int from, int to);
        void updateWeight(int from, int to, int weight);
        bool edgeExists(int from, int to);
        int getEdgeWeight(int from, int to);
        int size() const {
            return V;
        }
    };

    WeightedGraph readWeightedGraph(const char* fileName);
};
