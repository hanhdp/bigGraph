#ifndef GRAPH_DISTANCE_APC_H
#define GRAPH_DISTANCE_APC_H

#include <vector>
#include <tuple>
#include <set>
#include <map>
#include <array>
#include <mutex>
#include <stdint.h>
#include "k-path-cover/src/hierarchical-apc/hierarchicalApc.hpp"
#include "jlog.hpp"
#include "two_level_queue.hpp"

#define fst first
#define snd second

class GraphDistanceApc {
  typedef std::tuple<char, int, int> query_t;
  const uint32_t ALIVE   = 0;
  const uint32_t DEAD    = 1;
  const uint32_t UNKNOWN = 2;
  const uint32_t MASK    = 3;
  
  inline uint32_t GetID(uint32_t v) const { return v >> 2; }
  inline uint32_t GetEdgeState(uint32_t v) const { return v & MASK; }
  inline uint32_t ToEdge(uint32_t v) const { assert(v >= 0); return (v << 2) | ALIVE;}

  int connected_counter = 0;
  double update_time1 = 0;
  double update_time2 = 0;
  double query_time= 0;
  std::vector<int> vtable;
  std::vector<std::tuple<int, int, int, char> > updates; // <source, target, timestamp, type>
  std::vector<std::tuple<int, int, int> > queries; // <source, target, timestamp>
  std::map<char, int> query_counter;
  std::vector<std::vector<uint8_t> > Ds;
  std::vector<std::array<std::vector<std::queue<int> >, 2> > PQs;
  std::vector<TwoLevelQueue<int> > TQs;
  std::vector<std::vector<std::vector<uint16_t> > > costs;
  std::vector<std::vector<int> > used_vss;
  std::vector<std::vector<uint32_t> > G[2];
  std::vector<bool> is_cover;
  double time_connected = 0;
  double time_disconnected = 0;

  // <target with state, cost>
  std::vector< std::vector<std::pair<int, int> > > overlay_graph[2];
  
  int inline QueryDistance(int u, int v, int time,
                           const std::vector<std::tuple<int, int, int, char> > &qs);
  void InsertEdgeIntoGraph(std::vector<uint32_t> &vs, uint32_t v, bool);
  void DeleteEdgeFromGraph(std::vector<uint32_t> &vs, uint32_t v, bool);
  void UpdateOverlayGraphBeforeQuerying(const std::vector<std::tuple<int, int, int, char> > &updates);
  void UpdateBeforeQuerying(const std::vector<std::tuple<int, int, int, char> > &updates);
  void UpdateOverlayGraphAfterQuerying(const std::vector<std::tuple<int, int, int, char> > &updates);
  void UpdateAfterQuerying(const std::vector<std::tuple<int, int, int, char> > &updates);
public:
  std::vector<int> ProcessBatch(const std::vector<query_t> &batch);
  
  // level == 0 -> overlay_graph = originalGraph
  void Build(int n, std::vector<std::pair<int, int> > es, int level = 1);
  void PrintGraph();
  void PrintOverlayGraph();
  ~GraphDistanceApc();
};

#endif /* GRAPH_DISTANCE_APC_H */
