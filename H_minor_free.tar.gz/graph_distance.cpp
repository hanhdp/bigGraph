#include "graph_distance.hpp"
#include <cassert>
#include <algorithm>
#include <omp.h>
#include "jlog.hpp"
using namespace std;

double update_time1 = 0;
double update_time2 = 0;
double query_time= 0;
double second_slowest_query_time = 0;
double fastest_thread = 0;
double omp_query = 0;
double process_batch_time = 0;
vector<double> last_step;

#ifndef _OPENMP
#define _OPENMP
int omp_get_thread_num(){
  return 0;
}

int omp_get_max_threads(){
  return 1;
}

void omp_set_num_threads(int a){
}

#endif

namespace {
  bool inline Check(int v, int w, int time, uint32_t state,
                    const vector<tuple<int, int, int, char> > &qs){
    
    auto iter = lower_bound(qs.begin(), qs.end(), make_tuple(v, w, time, 0));
    if (qs.empty() || iter == qs.begin()){
      return (state & 1) == 0;
    }
    
    auto last = *(--iter);
    if (v == get<0>(last) && w == get<1>(last)){
      return get<3>(last) == 'A';
    } else {
      return (state & 1) == 0;
    }
  }
}


int GraphDistance::QueryDistance(int s, int t, int time,
                                 const vector<tuple<int, int, int, char> > &qs){
  
  if (s == t) {   return 0;  }
  
  {
    const auto iter = lower_bound(zeroG[0][t].begin(), zeroG[0][t].end(), ToEdge(s));
    if(iter != zeroG[0][t].end() &&
       GetID(*iter) == (uint32_t)s &&
       (GetEdgeState(*iter) == ALIVE ||
        ((GetEdgeState(*iter) & UNKNOWN) &&
         Check(s, t, time, GetEdgeState(*iter), qs))))
      return 1;
  }
  bool valid_path = true;
  int dist_ub =  1e9;

  if (use_pll){
    auto path = pll.QueryShortestPath(s, t);
    for (size_t i = 1; i < path.size(); ++i){
      int u = path[i - 1];
      int v = path[i];
      int pos = lower_bound(G[0][u].begin(), G[0][u].end(), ToEdge(v)) - G[0][u].begin();
      assert(GetID(G[0][u][pos]) == v);
      auto state = GetEdgeState(G[0][u][pos]);
      if (!(state == ALIVE || ((state & UNKNOWN) && Check(u, v, time, state, qs)))){
        valid_path = false;
      }
    }
    dist_ub =  (valid_path && !path.empty()) ? path.size() - 1 : 1e9; 
  } else {
    valid_path = false;
  }

    
  auto &Q = Qs[omp_get_thread_num()];
  auto &D = Ds[omp_get_thread_num()];
  const int D_unit = sizeof(D[0]) * 4;
  int res = -1, dis[2] = {0, 0};
  int weight[2] = {0, 0};

  for (int dir = 0; dir < 2; dir++){
    int v = dir == 0 ? s : t;
    Q[dir].clear();
    Q[dir].push(v);
    Q[dir].next();

    D[v / D_unit] |= 1 << (dir + v % D_unit * 2);
    weight[dir] += G[dir][v].size();
  }
  
  int counter[2] = {0, 0};

  double start = jlog_internal::get_current_time_sec();

  auto bfs_step = [&](int use) -> bool{
    start = jlog_internal::get_current_time_sec();
    dis[use]++;
    const auto & G_ = G[use];
    const auto & S_ = S[use];
    auto &       Q_ = Q[use];
    weight[use] = 0;
    
    while (!Q_.empty()) {
      int v = Q_.front();
      weight[use] += S_[v];
      Q_.pop();
      
      for (uint32_t w_ : G_[v]) {
        counter[use]++;
        uint32_t w = GetID(w_);
        auto & d = D[w / D_unit];
        const int bit_pos = w % D_unit * 2 + use;
        if (d & (1 << bit_pos)) continue;
        uint32_t state = GetEdgeState(w_);
        if (state == ALIVE || ((state & UNKNOWN) &&
                               (use == 0 ?
                                Check(v, w, time, state, qs) :
                                Check(w, v, time, state, qs)))){
          if (d & (1 << (1 - 2 * use + bit_pos))) {
            res = dis[0] + dis[1];
            connected_counter++;
            return true;
          } else {
            Q_.push(w);
            d |= 1 << bit_pos;
          }
        }
      }
    }
    Q_.next();    
    return false;
  };
  
  /*
    双方向の最初の一歩だけは両方から行う
    そうしないと入次数0のやつを消した時にバグる
  */
  
  for (int use = 0; use < 2; ++use) {
    if(bfs_step(use)) goto LOOP_END;
  }
  
  while (!Q[0].empty() && !Q[1].empty()) {
    const int use = (weight[0] <= weight[1]) ? 0 : 1;
    if (dis[0] + dis[1] + 1 == dist_ub){
      res = dis[0] + dis[1] + 1;
      goto LOOP_END;
    }
    if(bfs_step(use)) goto LOOP_END;
  }
  
 LOOP_END:
  last_step[omp_get_thread_num()] += jlog_internal::get_current_time_sec() - start;
  for (int dir = 0; dir < 2; dir++) {
    for (int v : Q[dir]) {
      D[v / D_unit] = false;
    }
    Q[dir].clear();
  }
  // double elapsed_time = jlog_internal::get_current_time_sec() - start_time;
  // if (res == -1) time_disconnected += elapsed_time;
  // else time_connected += elapsed_time;
  // if (res != -1){
  //   forward_visit.push_back(counter[0]);
  //   backward_visit.push_back(counter[1]);
  //   st_dist.push_back(res);
  // }
  return res;
}

void GraphDistance::InsertEdgeIntoGraph(vector<uint32_t> &vs, uint32_t v, bool unknown){
  auto iter = lower_bound(vs.begin(), vs.end(), v);
  if (iter != vs.end() && GetID(*iter) == GetID(v)){
    if (unknown){
      *iter |= UNKNOWN;
    } else {
      *iter = ToEdge(GetID(v)) | ALIVE;
    }
  } else {
    if (unknown){
      vs.insert(iter, ToEdge(GetID(v)) | DEAD | UNKNOWN);
    } else {
      vs.insert(iter, ToEdge(GetID(v)) | ALIVE);
    }
  }
}

void GraphDistance::DeleteEdgeFromGraph(vector<uint32_t> &vs, uint32_t v, bool unknown){
  auto iter = lower_bound(vs.begin(), vs.end(), v);
  if (iter != vs.end() && GetID(*iter) == GetID(v)){
    if (unknown){
      *iter |= UNKNOWN;
    } else {
      *iter = ToEdge(GetID(v)) | DEAD;
    }
  }
}

void GraphDistance::Build(int n, const vector<pair<int, int> > &es){
  int cur = omp_get_max_threads();
  // omp_set_num_threads(min<int>(cur, es.size() / 750000));
  
  Qs.clear();
  Ds.clear();
  cerr << omp_get_max_threads() << endl;

  outdegree[0].resize(n);
  outdegree[1].resize(n);
  
  for (const auto& e : es) {
    ++outdegree[0][e.fst];
    ++outdegree[1][e.snd];
  }

  for (int t = 0; t < omp_get_max_threads(); t++){
    Qs.emplace_back(2, TwoLevelQueue<int>(n));
    Ds.emplace_back(n / (sizeof(Ds[t][0]) * 4));
  }

  G[0].resize(n);
  G[1].resize(n);
  zeroG[0].resize(n);
  zeroG[1].resize(n);
  
  for (auto &e : es){
    if(outdegree[0][e.snd] > 0)
      G[0][e.fst].push_back(ToEdge(e.snd));
    else
      zeroG[0][e.snd].push_back(ToEdge(e.fst));
    
    if(outdegree[1][e.fst] > 0)
      G[1][e.snd].push_back(ToEdge(e.fst));
    else
      zeroG[1][e.fst].push_back(ToEdge(e.snd));
  }
  
  for (int v = 0; v < n; v++){
    sort(G[0][v].begin(), G[0][v].end());
    sort(G[1][v].begin(), G[1][v].end());

    sort(zeroG[0][v].begin(), zeroG[0][v].end());
    sort(zeroG[1][v].begin(), zeroG[1][v].end());
  }
  
  for (int dir = 0; dir < 2; dir++){
    S[dir].resize(n);
    for (int v = 0; v < n; v++){
      for (uint32_t w : G[dir][v]){
        S[dir][v] += G[dir][GetID(w)].size();
      }
    }
  }
  if (use_pll){
  JLOG_PUT_BENCHMARK("time.pll_indexing"){
    pll.ConstructIndex(es);
  }
  }
}


vector<int> GraphDistance::ProcessBatch(const vector<query_t> &batch){
  double process_start = jlog_internal::get_current_time_sec();
  double start= jlog_internal::get_current_time_sec();

  auto update_zeroG = [this](vector<uint32_t>& zero_es, int v, int state){
    auto iter = lower_bound(zero_es.begin(), zero_es.end(), ToEdge(v));
    if(iter != zero_es.end() && GetID(*iter) == (uint32_t)v)
      *iter = ToEdge(v) | state;
  };

#pragma omp parallel for
  for (int dir = 0; dir < 2; ++dir){
    
    for (size_t i = 0; i < batch.size(); i++){
      query_t query = batch[i];
      char cmd; int u, v;
      tie(cmd, u, v) = query;

      if(u == v && cmd != 'Q') continue;

      if (dir && int(G[0].size()) < max(u, v) + 1){
        int V = max(u, v) + 1;
        for (int dir = 0; dir < 2; dir++){
          G[dir].resize(V);
          zeroG[dir].resize(V);
        }

        for (int t = 0; t < omp_get_max_threads(); t++){
          Ds[t].resize(V / (sizeof(Ds[t][0]) * 4) + 1);
          for (int dir = 0; dir < 2; dir++){
            Qs[t][dir].resize(V);
          }
        }
      }
    
      if (cmd != 'Q') {
        
        auto copy_zeroG = [this](int dir, int u){
          auto& zero_es = zeroG[dir][u];
          for (const auto& e : zero_es) {
            const int eid = GetID(e);
            auto& G_es = G[dir][eid];
            const auto iter = lower_bound(G_es.begin(), G_es.end(), ToEdge(u));
            G_es.insert(iter, ToEdge(u) | GetEdgeState(e));
          }
          zero_es.clear();
        };

        copy_zeroG(dir, dir ? v : u);
        update_zeroG(zeroG[dir][dir ? u : v], dir ? v : u, UNKNOWN);
      }
      
      switch(cmd){
      case 'A':
        InsertEdgeIntoGraph(G[dir][dir ? v : u], ToEdge(dir ? u : v), true);
        if(dir) updates.push_back(make_tuple(u, v, i, 'A'));
        break;
      case 'D':
        DeleteEdgeFromGraph(G[dir][dir ? v : u], ToEdge(dir ? u : v), true);
        if(dir) updates.push_back(make_tuple(u, v, i, 'D'));
        break;
      case 'Q':
        if(dir) queries.push_back(make_tuple(u, v, i));
        break;
      default:
        assert(false);
      }
    }
  }
  
  sort(updates.begin(), updates.end());
  update_time1 += jlog_internal::get_current_time_sec() - start;

  vector<int> res(queries.size());
  
  start= jlog_internal::get_current_time_sec();
  vector<double> query_time_thread(omp_get_max_threads());
  last_step.resize(omp_get_max_threads());
#pragma omp parallel for schedule(dynamic)
  for (size_t i = 0; i < queries.size(); i++){
    double qstart = jlog_internal::get_current_time_sec();
    auto q = queries[i];
    res[i] = QueryDistance(get<0>(q), get<1>(q), get<2>(q), updates);
    query_time_thread[omp_get_thread_num()] += jlog_internal::get_current_time_sec() - qstart;
  }

  omp_query += jlog_internal::get_current_time_sec() - start;
  
  sort(query_time_thread.begin(), query_time_thread.end(), greater<double>());
  
  query_time += query_time_thread[0];
  if (1 < query_time_thread.size())
    second_slowest_query_time += query_time_thread[1];

  for (int i = (int)query_time_thread.size() - 1; i >= 0; --i) {
    if (query_time_thread[i] > 0) {
      fastest_thread += query_time_thread[i];
      break;
    }
  }
  
  start = jlog_internal::get_current_time_sec();
  for (auto upd : updates){
    char cmd; int u, v, t;
    tie(u, v, t, cmd) = upd;

    switch (cmd){
    case 'A':
      InsertEdgeIntoGraph(G[0][u], ToEdge(v), false);
      InsertEdgeIntoGraph(G[1][v], ToEdge(u), false);
      update_zeroG(zeroG[0][v], u, ALIVE);
      update_zeroG(zeroG[1][u], v, ALIVE);
      break;
    case 'D':
      DeleteEdgeFromGraph(G[0][u], ToEdge(v), false);
      DeleteEdgeFromGraph(G[1][v], ToEdge(u), false);
      update_zeroG(zeroG[0][v], u, DEAD);
      update_zeroG(zeroG[1][u], v, DEAD);
      break;
    default:
      assert(false);
    }
  }
  queries.clear();
  updates.clear();
  update_time2 += jlog_internal::get_current_time_sec() - start;

  process_batch_time += jlog_internal::get_current_time_sec() - process_start;
  return res;
}

double average(const vector<int> &vec){
  return (double) accumulate(vec.begin(), vec.end(), 0) / vec.size();
}

GraphDistance::~GraphDistance(){
  // JLOG_PUT("insert", query_counter['A']);
  // JLOG_PUT("delete", query_counter['D']);
  // JLOG_PUT("query", query_counter['Q']);
  // JLOG_PUT("query_disconnected", query_counter['Q'] - connected_counter);
  // JLOG_PUT("query_disconnected_time", time_disconnected);
  // JLOG_PUT("second_query_time", second_slowest_query_time);
  // JLOG_PUT("fastest_query", fastest_thread);
  // JLOG_PUT("last_step_time_sum", accumulate(last_step.begin(), last_step.end(), 0.0));
  // JLOG_PUT("last_step_time_max", *max_element(last_step.begin(), last_step.end()));
  // JLOG_PUT("query_time", query_time);
  // JLOG_PUT("omp_query_time", omp_query);
  JLOG_PUT("process_time", process_batch_time);
  JLOG_PUT("update_before_query", update_time1);
  JLOG_PUT("update_after_query", update_time2);
  
  // JLOG_PUT("avg_forward_visit", average(forward_visit));
  // JLOG_PUT("avg_backward_visit", average(backward_visit));
  // JLOG_PUT("avg_st_dist", average(st_dist));
}
