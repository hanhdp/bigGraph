#ifndef PRUNED_LANDMARK_LABELING_H
#define PRUNED_LANDMARK_LABELING_H

#include <vector>
#include <iostream>
#include <algorithm>
#include <xmmintrin.h>
#include <cassert>
#include <climits>
#include <cstring>
#include <malloc.h>

class PrunedLandmarkLabeling {
 public:
  // Constructs an index from a graph, given as a list of edges.
  // Vertices should be described by numbers starting from zero.
  // Returns |true| when successful.
  bool ConstructIndex(const std::vector<std::pair<int, int> > &es);
  bool ConstructIndex(std::istream &ifs);
  bool ConstructIndex(const char *filename);

  // Returns shortest paths (v = v1, v2, ..., vk= vw) vetween vertices |v| and |w| if they are connected.
  // Otherwise, returns ().
  std::vector<int> QueryShortestPath(int v, int w);

  int GetNumVertices() { return num_v_; }
  void Free();
  double GetAverageLabelSize();

  PrunedLandmarkLabeling()
    : num_v_(0), time_load_(0), time_indexing_(0) {
    index_[0] = index_[1] = nullptr;
    index_l_[0] = index_l_[1] = 0;
  }
  virtual ~PrunedLandmarkLabeling() {
    Free();
  }

  // private:
  static const uint8_t INF8;    // For unreachable pairs
  static const uint32_t INF32;  // For sentinel
  static const int kInitialLabelCapacity;

  struct index_t {
    uint32_t *spt_v;
    uint8_t *spt_d;
    uint32_t *spt_p;
    uint32_t spt_l;
    
    void Expand() {
      int new_spt_l = std::max(kInitialLabelCapacity, int((spt_l + 1) * 1.5));
      uint32_t *new_spt_v = (uint32_t*)memalign(64, new_spt_l * sizeof(uint32_t));
      uint8_t  *new_spt_d = (uint8_t *)memalign(64, new_spt_l * sizeof(uint8_t ));
      assert(new_spt_v && new_spt_d);
      memcpy(new_spt_v, spt_v, spt_l * sizeof(int32_t));
      memcpy(new_spt_d, spt_d, spt_l * sizeof(int8_t ));
      memset(new_spt_v + spt_l, 0, (new_spt_l - spt_l) * sizeof(int32_t));
      free(spt_v);
      free(spt_d);
      spt_v = new_spt_v;
      spt_d = new_spt_d;
      // printf(" EXPAND: %d -> %d\n", spt_l, new_spt_l);
      spt_l = new_spt_l;
    }
  } __attribute__((aligned(64)));  // Aligned for cache lines

  int num_v_;
  std::vector<std::vector<int> > adj_[2];
  index_t *index_[2];
  int index_l_[2];  // We don't need to use |size_t|
  std::vector<int> ord_;  // ord_[i] = v (e.g., ord[spt_v[0]] = the vertex with the highest degree)

  // Statistics
  double time_load_, time_indexing_;
};



#endif /* PRUNED_LANDMARK_LABELING_H */
