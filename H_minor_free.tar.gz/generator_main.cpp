#include <algorithm>
#include <bitset>
#include <cassert>
#include <cctype>
#include <cstdio>
#include <cstdlib>
#include <cmath>
#include <cstring>
#include <ctime>
#include <fstream>
#include <iomanip>
#include <iostream>
#include <limits>
#include <map>
#include <numeric>
#include <queue>
#include <set>
#include <stack>
#include <sstream>
#include <vector>
using namespace std;

#define REP2(i, m, n) for(int i = (int)(m); i < (int)(n); i++)
#define REP(i, n) REP2(i, 0, n)
#define ALL(c) (c).begin(), (c).end()
#define FOREACH(i, c) for(auto i = (c).begin(); i != (c).end(); ++i)
#define BIT(n, m) (((n) >> (m)) & 1)

template <typename S, typename T> ostream &operator<<(ostream &out, const pair<S, T> &p){
  return out << "(" << p.first << ", " << p.second << ")";
}

template <typename T> ostream &operator<<(ostream &out, const vector<T> &vec){
  out << "[";
  REP(i, vec.size()){
    out << (i == 0 ? "" : ", ") << vec[i];
  }
  return out << "]";
}

typedef long long ll;

const ll inf = 1e15;
const ll mod = 1000 * 1000 * 1000 + 7;
const double eps = 1e-9;
#define fst first
#define snd second
const int num_queries = 100000;
                
int V;
vector<vector<int> > G;
vector<vector<int> > H;
vector<int> D;
int C = 0;
vector<int> visit_vs;

int bfs(int v, const vector<vector<int> > &G){
  if (visit_vs.size() < G.size()) visit_vs.resize(G.size());

  int num_visit = 0;
  queue<int> Q;  
  D[v] = ++C;
  Q.push(v);
  visit_vs[num_visit++] = v;
  
  
  while (!Q.empty()){
    int v = Q.front(); Q.pop();
    visit_vs[num_visit++] = v;
    
    for (int w : G[v]){
      if (D[w] != C && !G[w].empty()){
        Q.push(w);
        D[w] = C;
      }
    }
  }
  return num_visit;
}
int main(){
  
  vector<pair<int, int> > es;
  V = 0;

  vector<int> vs;
  for (int u, v; cin >> u >> v; ){
    es.emplace_back(u, v);
    V = max(V, u + 1);
    V = max(V, v + 1);
    vs.push_back(u);
    vs.push_back(v);
  }
  G.resize(V);
  H.resize(V);
  D.resize(V);
  for (auto &e : es){
    G[e.fst].push_back(e.snd);
    H[e.snd].push_back(e.fst);
  }
  sort(ALL(vs));
  vs.erase(unique(ALL(vs)), vs.end());
  sort(vs.begin(), vs.end(), [&](int a, int b) { return H[a].size() < H[b].size(); });
  vector<int> visit(V, -1);
  for (int v : vs){
    if (visit[v] == -1){
      
    }
  }

  const int num_queries = 60000;
  REP(q, num_queries){
    int v = vs[rand() % vs.size()];
    int num_visit = bfs(v, G);
    int w = visit_vs[num_visit * 0.9];
    if (num_visit > 1000){
      cout << 'Q' << "\t" << v << "\t" << w << endl;
    } else {
      q--;
    }
  }
  
  return 0;
}
  
