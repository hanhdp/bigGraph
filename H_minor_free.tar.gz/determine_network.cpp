#ifndef DETERMINE_NETWORK_H
#define DETERMINE_NETWORK_H

#include "determine_network.hpp"
#include "graph_distance.hpp"
#include <iostream>
#include <vector>
using namespace std;

pair<double, double> get_average_dist(int n, const vector<pair<int, int> >& es, int num_sample) {
  GraphDistance graph_distance;
  graph_distance.NotUsePLL();
  graph_distance.Build(n, es);
  
  int disconnected = 0;
  int connected = 0;
  int connected_dist_sum = 0;
  vector<tuple<char, int, int> > batch;
  
  for (int i = 0; i < num_sample; ++i)
    batch.emplace_back('Q', rand() % n, rand() % n);

  auto ret = graph_distance.ProcessBatch(batch);
  for (auto e : ret) {
    if(e == -1) ++disconnected;
    else {
      ++connected;
      connected_dist_sum += e;
    }
  }

  return {connected_dist_sum * 1.0 / (connected + 1e-9),
        connected * 1.0 / num_sample};
}
  

#endif /* DETERMINE_NETWORK_H */
