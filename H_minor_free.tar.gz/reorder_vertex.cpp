#include "reorder_vertex.hpp"
#include <algorithm>
#include <cassert>
#include <iostream>
#include <functional>
#include <queue>
#include <set>
#include "jlog.hpp"

using namespace std;

template<typename T> bool ValidIndex(int v, const vector<T> &vec){
  return 0 <= v && v < int(vec.size());
};

uint32_t ReorderVertex::GetReorderedID(uint32_t v){
  auto it = reordered_vertex.find(v);
  if(it != reordered_vertex.end()) return it->second;
  
  auto sz = reordered_vertex.size();
  reordered_vertex[v] = sz;
  return sz;
}
  
void ReorderVertex::Reorder(const std::vector<std::pair<int, int> > &es,
                            int type){
  vector<int> sorted_vertex;
  for(auto e : es){
    sorted_vertex.push_back(e.first);
    sorted_vertex.push_back(e.second);
  }
  sort(sorted_vertex.begin(), sorted_vertex.end());
  sorted_vertex.erase(unique(sorted_vertex.begin(), sorted_vertex.end()),
                      sorted_vertex.end());

  if(type == ReorderVertex::DEFAULT ||
     type == ReorderVertex::RANDOM){
    if(type == ReorderVertex::RANDOM)
      random_shuffle(sorted_vertex.begin(), sorted_vertex.end());
    for(size_t i = 0; i < sorted_vertex.size(); ++i)
      reordered_vertex[sorted_vertex[i]] = i;
    return;
  }

  const int n = sorted_vertex.size();
  
  if(type == ReorderVertex::DEGREE){
    vector<pair<int, int> > degree(n);
    for(int i = 0; i < n; ++i) degree[i].second = i;
    for(auto e : es){
      int fst = lower_bound(sorted_vertex.begin(), sorted_vertex.end(), e.first) -
        sorted_vertex.begin();
      int snd = lower_bound(sorted_vertex.begin(), sorted_vertex.end(), e.second) -
        sorted_vertex.begin();
      ++degree[snd].first;
      ++degree[fst].first;
    }

    sort(degree.begin(), degree.end());

    for(int i = 0; i < n; ++i)
      reordered_vertex[sorted_vertex[degree[i].second]] = i;
    return;
  }
  
  if(type == ReorderVertex::BFS){
    vector<vector<int> > G(n);
    vector<int> indegree(n);
    for(auto e : es){
      int fst = lower_bound(sorted_vertex.begin(), sorted_vertex.end(), e.first) -
        sorted_vertex.begin();
      int snd = lower_bound(sorted_vertex.begin(), sorted_vertex.end(), e.second) -
        sorted_vertex.begin();
      G[fst].push_back(snd);
      ++indegree[snd];
    }
    
    for(int i = 0; i < n; ++i)
      sort(G[i].begin(), G[i].end());
    
    vector<bool> vis(n);
    vector<pair<int, int> > order(n);
    for(int i = 0; i < n; ++i)
      order[i] = make_pair(indegree[i], i);

    //sort(order.begin(), order.end());
    
    for(const auto& v : order){
      const int bfs_start = v.second;
      if(vis[bfs_start]) continue;
      queue<int> q;
      q.push(bfs_start);
      while(!q.empty()){
        int cv = q.front();
        q.pop();
        if(vis[cv]) continue;
        vis[cv] = true;
        int sz = reordered_vertex.size();
        reordered_vertex[sorted_vertex[cv]] = sz;
        for(auto e : G[cv]) if(!vis[cv]) q.push(e);
      }
    }
    
    
    return;
  }
  
  int m = 0;
  vector<map<int, int> > G(n);
  vector<int> degree(n);
  
  for(auto e : es){
    int fst = lower_bound(sorted_vertex.begin(), sorted_vertex.end(), e.first) -
      sorted_vertex.begin();
    int snd = lower_bound(sorted_vertex.begin(), sorted_vertex.end(), e.second) -
      sorted_vertex.begin();

    // directed -> bidirectional undirected
    G[fst][snd] += 1;
    G[snd][fst] += 1;
    degree[fst] += 1;
    degree[snd] += 1;
    m += 1;
  }

  set<pair<int, int> > sorted_by_degree;
  for(int i = 0; i < n; ++i){
    sorted_by_degree.insert(make_pair(degree[i], i));
  }
  
  vector<vector<int> > tree(n);
  vector<int> clusters;
  
  vector<int> original_vertex(n);
  vector<int> current_vertex(n);
  for (int i = 0; i < n; ++i){
    original_vertex[i] = i;
    current_vertex[i] = i;
  }
  vector<int> in_cluster(2 * n, 0);
  
    
  while(!sorted_by_degree.empty()){
    const pair<int, int> it = *sorted_by_degree.begin();
    sorted_by_degree.erase(it);
    const int u = it.second;
    assert(ValidIndex(u, original_vertex));
    const int gu = original_vertex[u];
    assert(ValidIndex(gu, degree));
    const int du = degree[gu];
    
    assert(du == it.first);
    pair<double, int> maxQ(-1, 0);
    assert(ValidIndex(gu, G));
    for(auto v_ : G[gu]){
      assert(ValidIndex(v_.first, in_cluster));
      if (!in_cluster[v_.first]){
        const int gv = v_.first;
        assert(gu != gv);
        const int wuv = v_.second;
        assert(ValidIndex(gv, degree));
        const int dv = degree[gv];
        const double deltaQ = (double)2*m*wuv-(double)du*dv;
        maxQ = max(maxQ, make_pair(deltaQ, gv));
      }
    }
    if(maxQ.first < 1e-9){
      clusters.push_back(u);
      assert(ValidIndex(u, in_cluster));
      in_cluster[u] = true;
      continue;
    }
    
    int gv = maxQ.second;
    assert(ValidIndex(gv, current_vertex));
    int v = current_vertex[gv];
    assert(ValidIndex(v, in_cluster));
    assert(!in_cluster[v]);

    assert(ValidIndex(gv, degree));
    assert(sorted_by_degree.count(make_pair(degree[gv], v)));
    sorted_by_degree.erase(make_pair(degree[gv], v));
    int newv = tree.size();
    tree.emplace_back(vector<int>());
    tree[newv].push_back(u);
    tree[newv].push_back(v);
    

    assert(ValidIndex(gu, G));
    assert(ValidIndex(gv, G));
    int merged_v = G[gu].size() < G[gv].size() ? gu : gv;
    int master_v = G[gu].size() < G[gv].size() ? gv : gu;
    original_vertex.push_back(master_v);
    assert(ValidIndex(master_v, current_vertex));
    current_vertex[master_v] = newv;
    // m -= G[master_v][merged_v];
    // assert(G[master_v][merged_v] == G[merged_v][master_v]);
    // なぜか↓の文をコメントアウトしないとmake runがueのassertでおちる
    // degree[master_v] -= G[master_v][merged_v];
    assert(ValidIndex(master_v, G));
    assert(ValidIndex(merged_v, G));
    assert(ValidIndex(master_v, degree));
    G[master_v].erase(merged_v);

    auto g_merged = G[merged_v];
    for (auto e : g_merged){
      if(e.first == master_v) continue;
      assert(ValidIndex(e.first, G));
      G[e.first].erase(merged_v);
      G[e.first][master_v] += e.second;
      G[master_v][e.first] += e.second;
      degree[master_v] += e.second;
    }
    assert(degree[master_v] >= 0);
    assert(ValidIndex(merged_v, G));
    G[merged_v].clear();
    sorted_by_degree.insert(make_pair(degree[master_v], newv));
  }

  int depth = 0;
  std::function<void(int)> dfs = [&](int v){
    // assert(depth < 1000000);
    
    assert(ValidIndex(v, tree));
    if(tree[v].empty()){
      assert(ValidIndex(v, sorted_vertex));
      int original_v = sorted_vertex[v];
      int sz = reordered_vertex.size();
      reordered_vertex[original_v] = sz;
    }
    
    for(auto e : tree[v]){
      depth++;
      dfs(e);
      depth--;
    } 
  };
  for(auto e : clusters) dfs(e);
  JLOG_PUT("num_clusters", clusters.size());
  // assert(es.size() < 400 * 10000);
  assert((int)reordered_vertex.size() == n);
}
