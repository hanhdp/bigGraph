#ifndef REORDER_VERTEX_H
#define REORDER_VERTEX_H

#include <vector>
#include <map>
#include <unordered_map>

class ReorderVertex{
  std::unordered_map<int, uint32_t> reordered_vertex;
  
public:
  enum{
    RANDOM,
    DEFAULT,
    SHIOKAWA,
    BFS,
    DEGREE,
  };
  
  inline uint32_t size(){ return reordered_vertex.size(); }
  uint32_t GetReorderedID(uint32_t);
  void Reorder(const std::vector<std::pair<int, int> > &es, int type = SHIOKAWA);
};

#endif
