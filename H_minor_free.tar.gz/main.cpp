#include <vector>
#include <cstdlib>
#include <cstdio>
#include <tuple>
#include <cassert>
#include <iostream>
#include <algorithm>
#include <unordered_map>
#include "jlog.hpp"
#include "graph_reader.hpp"
#include "graph_distance.hpp"
#include "graph_distance_apc.hpp"
#include "reorder_vertex.hpp"
#include "determine_network.hpp"

using namespace std;

inline bool readeof() {
  for (;;) {
    int c = getc_unlocked(stdin);
    if (c == EOF) {
      return true;
    } else if (isspace(c)) {
      continue;
    } else {
      ungetc(c, stdin);
      return false;
    }
  }
  assert(false);
}

inline int readint() {
  int c, s;
  int x;
  while (!isdigit(c = getc_unlocked(stdin)) && c != '-');
  if (c == '-') {
    s = -1;
    x = 0;
  } else {
    assert(isdigit(c));
    s = 1;
    x = c - '0';
  }
  while (isdigit(c = getc_unlocked(stdin))) {
    x = (x * 10 + (c - '0'));
  }
  return s * x;
}

inline int readuint() {
  int c;
  int x;
  while (!isdigit(c = getc_unlocked(stdin)));
  x = c - '0';
  while (isdigit(c = getc_unlocked(stdin))) {
    x = (x * 10 + (c - '0'));
  }
  return x;
}

namespace {
  unordered_map<int, int> vmap;
  ReorderVertex reorder;

  int getid(int v){
    auto iter = vmap.find(v);
    if(iter != vmap.end()) return iter->second;
    const auto ret = vmap.size();
    return vmap[v] = ret;
  }
  
  int getid_without_change(int v){
    auto iter = vmap.find(v);
    if(iter != vmap.end())
      return iter->second;
    return -1;
  }
  
  int init(vector<pair<int, int> > & es, bool shiokawa_flag = false){
    if (shiokawa_flag) reorder.Reorder(es);
    map<int, int> vdegree;
    for (auto e : es) {
      --vdegree[e.first];
      --vdegree[e.second];
      // vdegree[e.first] = 1;
      // vdegree[e.second] = 1;
    }
    
    vector<pair<int, int> > degv;
    for (auto e : vdegree) degv.emplace_back(e.second, e.first);
    sort(degv.begin(), degv.end());
    
    for (size_t i = 0; i < degv.size(); ++i) {
      vmap[degv[i].second] = shiokawa_flag ? reorder.GetReorderedID(degv[i].second) : i;
    }
    
    for (auto &e : es) {
      e.first = getid(e.first);
      e.second = getid(e.second);
    }
    
    return (vmap.size() + 1e5) * 4 / 3;
  }

}

int main(int argc, char *argv[])
{
  // JLOG_INIT(&argc, argv);
  vector<pair<int, int> > es;

  GraphReader graph_reader;
  int n = graph_reader.Read(es);
  n = init(es);

  void* p = NULL;


  auto network_info = get_average_dist(n, es);
  cerr << network_info.first << " " << network_info.second << endl;
  bool is_road = network_info.first >= 30;
  
#ifdef APC
  is_road = true;
#endif  
  // JLOG_PUT("is_raod", is_road);
  
  if (is_road) p = new GraphDistanceApc();
  else p = new GraphDistance();

  if (is_road) ((GraphDistanceApc*)(p))->Build(n, es, 12);
  else {
    if (network_info.second < 0.2) ((GraphDistance*)(p))->NotUsePLL();
    ((GraphDistance*)(p))->Build(n, es);
  }
  
  
  vector<tuple<char, int, int> > batch;
  batch.reserve(10000);
  vector<pair<bool, bool> > renamed;
  renamed.reserve(10000);

  // warm memory
  if (!es.empty()) {
    for (int i = 0; i < 1000; ++i) {
      int a = rand() % 2 ?
          es[rand() % es.size()].first :
          es[rand() % es.size()].second;
      int b = rand() % 2 ?
          es[rand() % es.size()].first :
          es[rand() % es.size()].second;
      batch.emplace_back('Q', getid(a), getid(b));
    }
    
    if (is_road) ((GraphDistanceApc*)(p))->ProcessBatch(batch);
    else         ((GraphDistance*)(p))->ProcessBatch(batch);
    
    batch.clear();
  }
  
  puts("R");
  cout.flush();
  // sleep(1);
  
  double total = 0;
  while (true){
    
    //  1. Read a batch.
    double start = jlog_internal::get_current_time_sec();
    if(readeof()) break;    
    char cmd; int u, v;
    
    while ((cmd = getc_unlocked(stdin)) && cmd != 'F'){
      u = readint();
      v = readint();
      batch.push_back(make_tuple(cmd, u, v));
      renamed.emplace_back(false, false);
    }

#pragma omp parallel for
    for (size_t i = 0; i < renamed.size(); ++i){
      int u = get<1>(batch[i]);
      int v = get<2>(batch[i]);
      u = getid_without_change(u);
      v = getid_without_change(v);
      if(u != -1){
        get<1>(batch[i]) = u;
        renamed[i].first = true;
      }
      
      if(v != -1){
        get<2>(batch[i]) = v;
        renamed[i].second = true;
      }      
    }

    for (size_t i = 0; i < renamed.size(); ++i){
      if(!renamed[i].first){
        int u = get<1>(batch[i]);
        get<1>(batch[i]) = getid(u);
      }

      if(!renamed[i].second){
        int u = get<2>(batch[i]);
        get<2>(batch[i]) = getid(u);
      }
    }
    
    total += jlog_internal::get_current_time_sec() - start;
    
    //  2. Process the batch.
    vector<int> dists;
    double batch_start = jlog_internal::get_current_time_sec();
    dists = is_road ?
        ((GraphDistanceApc*)(p))->ProcessBatch(batch) :
        ((GraphDistance*)(p))->ProcessBatch(batch);
    double batch_end = jlog_internal::get_current_time_sec();
#ifndef APC
    // usleep((batch_end - batch_start) * 2e6);
#endif
    
    string out;
    for (auto d : dists) {
      char num[20];
      sprintf(num, "%d\n",  d);
      out += num;
    }
    fputs_unlocked(out.c_str(), stdout);
    fflush_unlocked(stdout);
    
    if (batch.empty()) break;
    batch.clear();
    renamed.clear();
#ifdef APC
    // ((GraphDistanceApc*)p)->PrintGraph();
    // ((GraphDistanceApc*)p)->PrintOverlayGraph();
#endif
  }
  // JLOG_PUT("batch_reading_time", total);

  if (is_road) delete ((GraphDistanceApc*)p);
  else delete ((GraphDistance*)p);
  
  return 0;
}
