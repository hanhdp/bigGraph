#ifndef GRAPH_READER_H
#define GRAPH_READER_H

#include <vector>

class GraphReader {
public:
  int Read(std::vector<std::pair<int, int> > &es);
};

#endif /* GRAPH_READER_H */
