#pragma once

struct FixedEdgeList {
	uint32_t bitmapEdges;
	uint32_t singleEdges;
	uint32_t data[0];
};

struct BitmapEdge {
	uint32_t index;
	uint32_t map;
};

class FixedEdges
{
public:
	uint32_t numEntries = 0;
	uint32_t nextOutEntry = 1;
	uint32_t nextInEntry = 1;
	uint32_t *outEdges[2];
	uint32_t *inEdges[2];

	FixedEdges()
	{
	}

	void setSize(uint32_t numEntries)
	{
		this->numEntries = numEntries;

#ifndef NUMA_ENABLED
		outEdges[0] = (uint32_t*)malloc(numEntries * sizeof(uint32_t));
		outEdges[1] = (uint32_t*)malloc(numEntries * sizeof(uint32_t));
		inEdges[0] = (uint32_t*)malloc(numEntries * sizeof(uint32_t));
		inEdges[1] = (uint32_t*)malloc(numEntries * sizeof(uint32_t));
#endif
#ifdef NUMA_ENABLED
		outEdges[0] = (uint32_t*)numa_alloc_onnode(numEntries * sizeof(uint32_t), 0);
		outEdges[1] = (uint32_t*)numa_alloc_onnode(numEntries * sizeof(uint32_t), 1);
		inEdges[0] = (uint32_t*)numa_alloc_onnode(numEntries * sizeof(uint32_t), 0);
		inEdges[1] = (uint32_t*)numa_alloc_onnode(numEntries * sizeof(uint32_t), 1);
#endif

	}

	uint32_t getNextFreeOutEntry()
	{
		return nextOutEntry;
	}	

	void increaseOutPointer(uint32_t count)
	{
		nextOutEntry += count;
	}

	uint32_t getNextFreeInEntry()
	{
		nextInEntry++;
		return (nextInEntry - 1);
	}

	void syncOutEdges(uint32_t firstIndex, uint32_t count)
	{
		for (uint32_t i = firstIndex; i < (firstIndex + count); i++) {
			outEdges[1][i] = outEdges[0][i];
		}
	}

	void syncInEdges(uint32_t firstIndex, uint32_t count)
	{
		for (uint32_t i = firstIndex; i < (firstIndex + count); i++) {
			inEdges[1][i] = inEdges[0][i];
		}
	}

	void syncWithPointer(uint32_t *ptr, uint32_t count)
	{
		if ((uint64_t)ptr >(uint64_t)(outEdges[0])) {
			uint32_t index = ((uint64_t)ptr - (uint64_t)(outEdges[0])) / sizeof(uint32_t);
			if (index < numEntries) syncOutEdges(index, count);
		}
		if ((uint64_t)ptr >(uint64_t)(inEdges[0])) {
			uint32_t index = ((uint64_t)ptr - (uint64_t)(inEdges[0])) / sizeof(uint32_t);
			if (index < numEntries) syncInEdges(index, count);
		}
	}

	void increaseInPointer(uint32_t count)
	{
		nextInEntry += count;
	}
};
