#pragma once

#include <thread>
#include <vector>
#include <unistd.h>

using namespace std;

#define WORKER_QUEUE_SIZE 4

struct QueryTask {
	uint32_t queryId;
	uint32_t txId;
	uint32_t iSrcId;
	uint32_t iDesId;
};

class WorkerThread {
public:	
	uint32_t id;
	thread *myThread;
	int numaNode = 0;
	volatile bool finished = false;

	QueryTask *queue;
	volatile uint32_t readPos = 0;
	volatile uint32_t writePos = 0;

	WorkerThread()
	{
		queue = new QueryTask[WORKER_QUEUE_SIZE];
		memset((void*)queue, 0, sizeof(QueryTask) * WORKER_QUEUE_SIZE);
		readPos = 0;
		writePos = 0;
		finished = false;
	}

	bool insertQuery(uint32_t queryId, uint32_t txId, uint32_t iSrcId, uint32_t iDesId)
	{
		if (((writePos + 1) % WORKER_QUEUE_SIZE) == readPos) return false;

		queue[writePos].queryId = queryId;
		queue[writePos].txId = txId;
		queue[writePos].iSrcId = iSrcId;
		queue[writePos].iDesId = iDesId;
		writePos = (writePos + 1) % WORKER_QUEUE_SIZE;
		return true;
	}
};

WorkerThread workerThreads[128];
#ifndef LOCAL
int numWorkers = 24;
#endif
#ifdef LOCAL
int numWorkers = 2;
#endif

mutex startupMutex;

void threadMain(WorkerThread *worker)
{
	startupMutex.lock();

#ifndef LOCAL
	// Set thread affinity
	cpu_set_t cpuset;
	CPU_ZERO(&cpuset);
	uint32_t idd = worker->id;
	CPU_SET(idd, &cpuset);
	int rc = pthread_setaffinity_np(worker->myThread->native_handle(), sizeof(cpu_set_t), &cpuset);
	sched_yield();
	cyclesleep(worker->id * 21000);
	worker->numaNode = numa_node_of_cpu(sched_getcpu()) % 2;
#endif

	// Initialize local variables
	QueryTask *queue = worker->queue;
	uint32_t taskCounter = 0;

	// Allocate per-thread resources
	BdbfsBitmap bitmap(worker->numaNode);
	BfsQueue inQueue;
	BfsQueue outQueue;

	startupMutex.unlock();

	// Task / Query processing
	while (true) {
		// Wait until there are query tasks
		uint32_t readPos = worker->readPos;
		if (readPos == worker->writePos) {
			if (taskCounter > 0) {
				resultBuffer.increaseCounter(taskCounter);
				taskCounter = 0;
			}
			if (worker->finished == true) return;
			//cyclesleep(100);
			continue;
		}

		// Read query
		uint32_t queryId = queue[readPos].queryId;
		uint32_t txId = queue[readPos].txId;
		uint32_t iSrcId = queue[readPos].iSrcId;
		uint32_t iDesId = queue[readPos].iDesId;		

		// Run query
		int len = speedGraph.shortestPathQuery(worker->numaNode, iSrcId, iDesId, txId, bitmap, outQueue, inQueue);
		//bitmap.release();

		// Store result
		resultBuffer.setResult(queryId, len);
		taskCounter++;

		// Increase read pointer
		worker->readPos = (worker->readPos + 1) % WORKER_QUEUE_SIZE;
	}
}

void initializeWorkerThreads()
{
	// Initialize NUMA
#ifdef NUMA_ENABLED
	if (numa_available() != -1) {
		numWorkers = numa_num_task_cpus();
		if (numWorkers > 128) numWorkers = 128;
	}
#endif

	// Run threads
	for (int i = 1; i < numWorkers; i++) {
		workerThreads[i].id = i;
		workerThreads[i].myThread = new thread(&threadMain, &workerThreads[i]);
	}
}

void stopAndJoinWorkerThreads()
{
	// Set finished flag
	for (int i = 1; i < numWorkers; i++) workerThreads[i].finished = true;

	// Join
	for (int i = 1; i < numWorkers; i++) workerThreads[i].myThread->join();
}
