#pragma once

#define INIT_QUEUE_SIZE (2 * 1024 * 1024)

class BfsQueue {
public:
	uint32_t *queue0;			// Queues
	uint32_t *queue1;
	uint32_t sizeQueue0;		// Allocated size of the queues
	uint32_t sizeQueue1;

	uint32_t *queueDepth0;		// Pointer to the current queue
	uint32_t *queueDepth1;
	uint32_t *sizeQueueDepth1;	// Pointer to the size of queue depth 1
	uint32_t numDepth0;			// Current elements in queue with depth 0
	uint32_t numDepth1;			// Current elements in queue with depth 1
	uint32_t readPos;			// Read position at queue depth 0

	int currentDepth;			// Current depth


	BfsQueue()
	{
		// Allocate queues
		sizeQueue0 = INIT_QUEUE_SIZE;
		sizeQueue1 = INIT_QUEUE_SIZE;

#ifdef NUMA_ENABLED
		queue0 = (uint32_t*)numa_alloc_local(sizeof(uint32_t) * sizeQueue0);
		queue1 = (uint32_t*)numa_alloc_local(sizeof(uint32_t) * sizeQueue1);
#endif
#ifndef NUMA_ENABLED
		queue0 = (uint32_t*)malloc(sizeof(uint32_t) * sizeQueue0);
		queue1 = (uint32_t*)malloc(sizeof(uint32_t) * sizeQueue1);
#endif
		memset(queue0, 0, sizeof(uint32_t) * sizeQueue0);
		memset(queue1, 0, sizeof(uint32_t) * sizeQueue1);

		// Initialize attributes
		initialize();
	}

	void initialize()
	{
		queueDepth0 = queue0;
		queueDepth1 = queue1;
		sizeQueueDepth1 = &sizeQueue1;
		numDepth0 = 0;
		numDepth1 = 0;
		readPos = 0;
		currentDepth = 0;
	}

	// Push node (into depth 0 list)
	void setInit(uint32_t id)
	{
		queueDepth0[numDepth0] = id;
		numDepth0++;
	}

	void increaseQueueSize()
	{
		uint32_t newSizeQueue0 = sizeQueue0 + INIT_QUEUE_SIZE;
		uint32_t newSizeQueue1 = sizeQueue1 + INIT_QUEUE_SIZE;

#ifdef NUMA_ENABLED
		queue0 = (uint32_t*)numa_realloc((void*)queue0, sizeof(uint32_t) * sizeQueue0, sizeof(uint32_t) * newSizeQueue0);
		queue1 = (uint32_t*)numa_realloc((void*)queue1, sizeof(uint32_t) * sizeQueue1, sizeof(uint32_t) * newSizeQueue1);
#endif
#ifndef NUMA_ENABLED
		queue0 = (uint32_t*)realloc((void*)queue0, sizeof(uint32_t) * newSizeQueue0);
		queue1 = (uint32_t*)realloc((void*)queue1, sizeof(uint32_t) * newSizeQueue1);
		
#endif
		sizeQueue0 = newSizeQueue0;
		sizeQueue1 = newSizeQueue1;
		if (sizeQueueDepth1 == &sizeQueue1) {
			queueDepth0 = queue0;
			queueDepth1 = queue1;
		}
		else {
			queueDepth1 = queue0;
			queueDepth0 = queue1;
		}
	}

	// Push next node (into depth 1 list)
	void push(uint32_t id)
	{
		if (*sizeQueueDepth1 <= numDepth1) increaseQueueSize();

		queueDepth1[numDepth1] = id;
		numDepth1++;
	}

	void pushBitmapRange(uint32_t id, uint32_t bitmap)
	{
		// Push index and bitmap
		push(id | 0x80000000);
		push(bitmap);		
	}

	// Empty state of current node list (depth 0)
	inline bool isEmptyDepth0()
	{
		if (readPos >= numDepth0) return true;
		else return false;
	}

	// Pop node from current node list (depth == 0)
	inline uint32_t pop()
	{
		readPos++;
		return queueDepth0[readPos - 1];
	}

	inline int workSize()
	{
		return numDepth0;
	}

	// Swap queues to switch to the next depth level
	void nextDepth()
	{
		if (queueDepth0 == queue0) {
			queueDepth0 = queue1;
			queueDepth1 = queue0;
			sizeQueueDepth1 = &sizeQueue0;
		}
		else {
			queueDepth0 = queue0;
			queueDepth1 = queue1;
			sizeQueueDepth1 = &sizeQueue1;
		}
		numDepth0 = numDepth1;
		numDepth1 = 0;

		currentDepth++;
		readPos = 0;
	}
	
};