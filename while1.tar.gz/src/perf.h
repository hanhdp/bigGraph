
#include <x86intrin.h>

#define SECTION_GETLINE      0
#define SECTION_INITPARSE    10
#define SECTION_PARSE        1
#define SECTION_ADD          2
#define SECTION_REMOVE       3
#define SECTION_QUERY        4
#define SECTION_QUERY_TRUE   5
#define SECTION_QUERY_FALSE  6
#define SECTION_BATCH        7
#define SECTION_DISTRIBUTE   8
#define SECTION_OUTPUT       9
#define SECTION_MERGE        11

uint64_t startTicks[16];
uint64_t totalTicks[16];

void printPerformance()
{
#ifdef LOCAL
	float clockDivisor = 3200000.0f;
#endif
#ifndef LOCAL
	float clockDivisor = 2100000.0f;
#endif
	cerr << "SECTION_PARSE = " << (float)(totalTicks[SECTION_PARSE]) / clockDivisor << " ms" << endl;
	cerr << "SECTION_ADD = " << (float)(totalTicks[SECTION_ADD]) / clockDivisor << " ms" << endl;
	cerr << "SECTION_REMOVE = " << (float)(totalTicks[SECTION_REMOVE]) / clockDivisor << " ms" << endl;
	cerr << "SECTION_DISTRIBUTE = " << (float)(totalTicks[SECTION_DISTRIBUTE]) / clockDivisor << " ms" << endl;
	cerr << "SECTION_BATCH = " << (float)(totalTicks[SECTION_BATCH]) / clockDivisor << " ms" << endl;
	cerr << "SECTION_OUTPUT = " << (float)(totalTicks[SECTION_OUTPUT]) / clockDivisor << " ms" << endl;
	cerr << "SECTION_MERGE = " << (float)(totalTicks[SECTION_MERGE]) / clockDivisor << " ms" << endl;
}

void initSectionTicks()
{
	for (int i = 0; i < 16; i++) {
		startTicks[i] = 0;
		totalTicks[i] = 0;
	}
}

void startSection(int section)
{
	startTicks[section] = __rdtsc();
}

void endSection(int section, bool print = false)
{
	uint64_t ticks = __rdtsc() - startTicks[section];
	totalTicks[section] += ticks;
	if (print == true) {
		cerr << ticks;
	}
}


system_clock::time_point _startTimePoint;

void startTimer()
{
	_startTimePoint = system_clock::now();
}

uint64_t finishTimer()
{
	return duration_cast<milliseconds>(system_clock::now() - _startTimePoint).count();
}