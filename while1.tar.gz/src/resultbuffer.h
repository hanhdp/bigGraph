#pragma once

#define RESULT_BUFFER_SIZE 256 * 1024

class ResultBuffer {
public:
	int *results;					// Contains the results (shortest path length)
	char *resultTextBuffer;			// Buffer for the output text
	uint32_t resultTextBufferSize;

	mutex counterLock;				// Counter (and its lock) for the number of finished queries
	volatile uint32_t counter = 0;

	ResultBuffer()
	{
		results = new int[RESULT_BUFFER_SIZE];
		resultTextBufferSize = 16384;
		resultTextBuffer = new char[resultTextBufferSize + 32];
	}

	void reset()
	{
		counter = 0;
	}

	void setResult(uint32_t id, int len)
	{
		results[id] = len;
	}

	void increaseCounter(uint32_t count)
	{
		counterLock.lock();
		counter += count;
		counterLock.unlock();
	}

	// Convert one integer to string
	int writeIntToText(char *text, uint32_t res)
	{
		// Special case: -1
		if (res == -1) {
			text[0] = '-';
			text[1] = '1';
			text[2] = '\n';
			return 3;
		}
		// Special case: 0
		if (res == 0) {
			text[0] = '0';
			text[1] = '\n';
			return 2;
		}
		
		// Integers between 1 and 999'999
		int numChars = 0;
		int highest = 100000;
		while (highest >= 1) {
			if (res >= highest) {
				text[numChars] = ((res / highest) % 10) + 0x30;
				numChars++;
			}
			highest = highest / 10;
		}
		text[numChars] = '\n';
		numChars += 1;
		return numChars;
	}

	// Convert the result ints to string and output it to stdio
	void writeResultsToStdout(uint32_t size)
	{
		char *text = resultTextBuffer;
		for (uint32_t i = 0; i < size; i++) {
			text += writeIntToText(text, results[i]);

			// Write, if size is greater than ResultBufferSize
			if ((text - resultTextBuffer) > resultTextBufferSize) {
				write(STDOUT_FILENO, (void*)resultTextBuffer, (text - resultTextBuffer));
				text = resultTextBuffer;
			}
		}

		// Write
		if ((text - resultTextBuffer) > 0) {
			write(STDOUT_FILENO, (void*)resultTextBuffer, (text - resultTextBuffer));
		}
	}


};