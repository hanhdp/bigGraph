
class Parser
{
public:
	bool initGraphParsedComplete = false;
	bool endOfFile = false;
	uint32_t bufferSize;	// Total size of allocated buffer
	uint32_t contentSize;	// Size of read bytes in the buffer

	char *buffer;			// Buffer
	char *readPos;			// Current read position in the buffer
	char *noMoreLinePtr;	// Pointer to the buffer where no more complete lines are

	Parser()
	{
		bufferSize = 128 * 1024;
		buffer = new char[bufferSize + 32];
		noMoreLinePtr = buffer;
		readPos = buffer;
		contentSize = 0;
		endOfFile = false;
	}

	void readRemainingLines()
	{
		// Read until there are remaining lines
		while (readPos >= noMoreLinePtr) {
			// Copy remaining size to the beginning of the buffer
			uint32_t remainingSize = contentSize - (readPos - buffer);
			if ((remainingSize > 0) && (readPos != buffer)) {
				for (int i = 0; i < remainingSize; i++) buffer[i] = readPos[i];
			}
			contentSize = remainingSize;
			readPos = buffer;

			// Read
			contentSize += read(STDIN_FILENO, (void*)&buffer[remainingSize], (readPos - buffer) + bufferSize);
			if (contentSize == 0) {
				endOfFile = true;
				return;
			}

			// Determine the position where nor more complete lines are
			noMoreLinePtr = &buffer[contentSize - 1];
			while (noMoreLinePtr > buffer) {
				if (*noMoreLinePtr == '\n') {
					noMoreLinePtr++;
					break;
				}
				noMoreLinePtr--;
			}
		}
	}

	int parseIntPair(char *text, uint32_t *srcNodeId, uint32_t *desNodeId)
	{
		uint32_t num1 = 0;
		uint32_t num2 = 0;
		int textLen = 0;

		while ((*text != ' ') && (*text != 0x09)) {
			num1 = (num1 * 10) + ((uint8_t)(*text) - 0x30);
			text++;
			textLen++;
		}
		text++;
		textLen++;

		while ((*text != 0x0A) && (*text != 0x0D)) {
			num2 = (num2 * 10) + ((uint8_t)(*text) - 0x30);
			text++;
			textLen++;
		}

		if (*text == 0x0D) textLen++;
		textLen++;

		*srcNodeId = num1;
		*desNodeId = num2;
		return textLen;
	}

	bool getInitGraphEdge(uint32_t *srcNodeId, uint32_t *desNodeId)
	{
		// Check active and read buffer if necessary
		if (initGraphParsedComplete == true) return false;
		readRemainingLines();

		// End of init graph
		if (*readPos == 'S') {
			readPos += 2;
			initGraphParsedComplete = true;
			return false;
		}

		// Scan current line
		int bytesScanned = parseIntPair(readPos, srcNodeId, desNodeId);
		readPos += bytesScanned;
		return true;
	}

	void getGraphOperation(char *command, uint32_t *srcNodeId, uint32_t *desNodeId)
	{
		// Read buffer if necessary
		readRemainingLines();
		if (endOfFile == true) return;

		// Read command
		*command = *readPos;
		readPos += 2;

		// End of batch
		if (*command == 'F') return;

		// Scan current line
		int bytesScanned = parseIntPair(readPos, srcNodeId, desNodeId);
		readPos += bytesScanned;
	}


	bool getInitGraphEdge_old(uint32_t *srcNodeId, uint32_t *desNodeId)
	{
		if (initGraphParsedComplete == true) return false;

		// Read line
		string mystr;
		getline(cin, mystr);

		// No more edges for the init graph
		if (mystr.at(0) == 'S') {
			initGraphParsedComplete = true;
			return false;
		}

		// Parse edge
		sscanf(mystr.c_str(), "%d %d", srcNodeId, desNodeId);

		return true;
	}

	void getGraphOperation_old(char *command, uint32_t *srcNodeId, uint32_t *desNodeId)
	{
		string mystr;
		getline(cin, mystr);

		if (mystr.length() == 0) exit(0);

		//cerr << lineNumber << " : (" << mystr.length() << ")" << mystr << endl;
		//lineNumber++;

		sscanf(mystr.c_str(), "%c %d %d", command, srcNodeId, desNodeId);
	}

	
};