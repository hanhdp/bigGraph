#pragma once

#define TXEDGE_MAP_SIZE 512
#define TXEDGE_NUM_EDGES 7

struct TransactionEdge {
	uint32_t nodeId;
	uint32_t desNodeId;
	uint32_t addTx;
	uint32_t removeTx;
};

struct TransactionEdgeList
{
	uint32_t count;
	uint32_t size;
	TransactionEdge edges[TXEDGE_NUM_EDGES];
	TransactionEdgeList *next;
};


class TransactionEdges
{
public:
	TransactionEdgeList outEdgeMap[TXEDGE_MAP_SIZE];
	TransactionEdgeList inEdgeMap[TXEDGE_MAP_SIZE];	
	uint32_t allocs = 0;

	TransactionEdgeList *preallocatedEdgeLists;
	uint32_t remainingPreallocatedEdgeLists = 0;

	TransactionEdges()
	{
		// Initialize transaction edge map
		for (int i = 0; i < TXEDGE_MAP_SIZE; i++) {
			outEdgeMap[i].count = 0;
			outEdgeMap[i].size = TXEDGE_NUM_EDGES;
			outEdgeMap[i].next = nullptr;
			inEdgeMap[i].count = 0;
			inEdgeMap[i].size = TXEDGE_NUM_EDGES;
			inEdgeMap[i].next = nullptr;
		}

		// Initialize free (preallocated) transaction edge lists
		allocateNewEdgeLists();
	}

	void allocateNewEdgeLists()
	{
		remainingPreallocatedEdgeLists = 8192;
		preallocatedEdgeLists = (TransactionEdgeList*)malloc(remainingPreallocatedEdgeLists * sizeof(TransactionEdgeList));
		memset(preallocatedEdgeLists, 0, remainingPreallocatedEdgeLists * sizeof(TransactionEdgeList));
		allocs++;
	}

	TransactionEdgeList* allocateEdgeList()
	{
		// Allocate new edge lists
		if (remainingPreallocatedEdgeLists == 0) allocateNewEdgeLists();

		// Take an edge list
		remainingPreallocatedEdgeLists--;
		return &preallocatedEdgeLists[remainingPreallocatedEdgeLists];
	}

	void addTransactionEdgeIntoEdgeList(TransactionEdgeList *edgeList, uint32_t nodeId, uint32_t desNodeId, uint32_t addTx, uint32_t removeTx)
	{
		if (edgeList->count >= edgeList->size) {
			// Go to the next list
			if (edgeList->next != nullptr) addTransactionEdgeIntoEdgeList(edgeList->next, nodeId, desNodeId, addTx, removeTx);
			
			// Allocate new edge list
			else {
				TransactionEdgeList *newList = allocateEdgeList();
				newList->size = TXEDGE_NUM_EDGES;
				newList->count = 0;
				newList->next = nullptr;				
				addTransactionEdgeIntoEdgeList(newList, nodeId, desNodeId, addTx, removeTx);
				edgeList->next = newList;
			}
		}

		// Add to the current edge list
		else {
			TransactionEdge *edge = &edgeList->edges[edgeList->count];
			edge->nodeId = nodeId;
			edge->desNodeId = desNodeId;
			edge->addTx = addTx;
			edge->removeTx = removeTx;
			edgeList->count++;
		}
	}

	TransactionEdgeList* getFirstOutgoingEdgeList(uint32_t nodeId)
	{
		uint32_t mapIndex = nodeId % TXEDGE_MAP_SIZE;
		return &outEdgeMap[mapIndex];
	}

	TransactionEdgeList* getFirstIngoingEdgeList(uint32_t nodeId)
	{
		uint32_t mapIndex = nodeId % TXEDGE_MAP_SIZE;
		return &inEdgeMap[mapIndex];
	}

	// Add transaction edge
	void addTransactionEdge(uint32_t nodeId, bool ingoing, uint32_t desNodeId, uint32_t addTx, uint32_t removeTx)
	{
		uint32_t mapIndex = nodeId % TXEDGE_MAP_SIZE;
		if (ingoing == true) addTransactionEdgeIntoEdgeList(&inEdgeMap[mapIndex], nodeId, desNodeId, addTx, removeTx);
		else addTransactionEdgeIntoEdgeList(&outEdgeMap[mapIndex], nodeId, desNodeId, addTx, removeTx);
	}

	void setTransactionEdgeAsRemovedInEdgeList(TransactionEdgeList *edgeList, uint32_t nodeId, uint32_t desNodeId, uint32_t removeTx)
	{
		for (int i = 0; i < edgeList->count; i++) {
			TransactionEdge *edge = &edgeList->edges[i];
			if ((edge->nodeId == nodeId) && (edge->desNodeId == desNodeId) && (edge->removeTx > removeTx)) {
				edge->removeTx = removeTx;
			}
		}
		if (edgeList->next != nullptr) setTransactionEdgeAsRemovedInEdgeList(edgeList->next, nodeId, desNodeId, removeTx);
	}

	void setTransactionEdgeAsRemoved(uint32_t nodeId, bool ingoing, uint32_t desNodeId, uint32_t removeTx)
	{
		uint32_t mapIndex = nodeId % TXEDGE_MAP_SIZE;
		if (ingoing == true) setTransactionEdgeAsRemovedInEdgeList(&inEdgeMap[mapIndex], nodeId, desNodeId, removeTx);
		else setTransactionEdgeAsRemovedInEdgeList(&outEdgeMap[mapIndex], nodeId, desNodeId, removeTx);
	}


};