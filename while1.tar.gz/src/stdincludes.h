
#include <iostream>
#include <string>
#include <vector>
#include <chrono>
#include <queue>
#include <unistd.h>
#include <x86intrin.h>
#include <stdio.h>
#include <string.h>
#include <algorithm>

#include <unistd.h>
#include <thread>
#include <mutex>
#include <pthread.h>
#include <sched.h>

#include <sched.h>
#include <stdlib.h>
#include <unistd.h>
#include <stdio.h>
#include <assert.h>
#include <sys/types.h>

using namespace std;
using namespace std::chrono;

void cyclesleep(uint64_t cycles)
{
	uint64_t startCycles = __rdtsc();
	while (__rdtsc() - startCycles < cycles) {};

}