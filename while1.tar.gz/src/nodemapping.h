#pragma once

#define LOW_MAPPING_SIZE (24 * 1024 * 1024)

class NodeMapping
{
public:
	uint32_t count = 0;
	unordered_map<uint32_t, uint32_t> highMapping;
	uint32_t *lowMapping;

	NodeMapping()
	{
		// Initialize high mapping
		highMapping.clear();
		highMapping.reserve(1 * 1024 * 1024);

		// Initialize low mapping
		lowMapping = new uint32_t[LOW_MAPPING_SIZE];
		memset((void*)lowMapping, 0xFF, LOW_MAPPING_SIZE);
	}

	uint32_t insert(uint32_t externalId, uint32_t internalId)
	{
		if (externalId < LOW_MAPPING_SIZE) lowMapping[externalId] = internalId;
		else highMapping[externalId] = internalId;
		return internalId;
	}

	uint32_t resolve(uint32_t nodeId)
	{
		if (nodeId < LOW_MAPPING_SIZE) return lowMapping[nodeId];
		if (highMapping.count(nodeId) == 0) return 0xFFFFFFFF;
		else return highMapping[nodeId];
	}
		
};