#pragma once

#define NODE_LOCAL_SIZE  4

#define USE_BITMAP_THRESHOLD  5

#define BIT_TXAVAILABLE    31
#define BIT_FIXEDAVAILABLE 30

#define MASK_TXAVAILABLE	(1 << 31)
#define MASK_FIXEDAVAILABLE (1 << 30)
#define MASK_LOCALCOUNT		((1 << 29) | (1 << 28) | (1 << 27))
#define POS_LOCALCOUNT		27
#define MASK_FIXEDPOINTER	0x07FFFFFF

#define MASK_NODE 0x07FFFFFF

struct SpeedNode {
	uint32_t data[NODE_LOCAL_SIZE];
};

class SpeedGraph
{
public:
	// Mapping from external to internal node id
	NodeMapping mapping;

	// Internal node information
	uint32_t numNodes = 1;
	SpeedNode *outNodes[2];
	SpeedNode *inNodes[2];

	// Fixed Edges
	FixedEdges fixedEdges;

	// Transaction Edges
	TransactionEdges txEdges;

	// Track what has changed
	uint32_t maxTrack = 8192;
	uint32_t currentTrack = 0;
	uint32_t trackNodeId[8192];


	SpeedGraph()
	{
	}

	void setSize(uint64_t numNodes, uint64_t numEdges)
	{
		uint64_t numAllocatedNodes = 24 * 1024 * 1024;
		if (numNodes > numAllocatedNodes) numAllocatedNodes = numNodes + 2 * 1024 * 1024;
		uint64_t numAllocatedEdges = 64 * 1024 * 1024;
		if ((numEdges * 5) > numAllocatedEdges) numAllocatedEdges = (numEdges * 2);

#ifdef NUMA_ENABLED
		inNodes[0] = (SpeedNode*)numa_alloc_onnode(numAllocatedNodes * sizeof(SpeedNode), 0);
		inNodes[1] = (SpeedNode*)numa_alloc_onnode(numAllocatedNodes * sizeof(SpeedNode), 1);
		outNodes[0] = (SpeedNode*)numa_alloc_onnode(numAllocatedNodes * sizeof(SpeedNode), 0);
		outNodes[1] = (SpeedNode*)numa_alloc_onnode(numAllocatedNodes * sizeof(SpeedNode), 1);
#endif
#ifndef NUMA_ENABLED
		inNodes[0] = (SpeedNode*)malloc(numAllocatedNodes * sizeof(SpeedNode));
		inNodes[1] = (SpeedNode*)malloc(numAllocatedNodes * sizeof(SpeedNode));
		outNodes[0] = (SpeedNode*)malloc(numAllocatedNodes * sizeof(SpeedNode));
		outNodes[1] = (SpeedNode*)malloc(numAllocatedNodes * sizeof(SpeedNode));
#endif
		fixedEdges.setSize(numAllocatedEdges);
	}

	// Allocate new internal id
	uint32_t allocMainNodeId()
	{
		if (numNodes >= maxBitmapSize) maxBitmapSize += 1 * 1024 * 1024;

		inNodes[0][numNodes].data[0] = 0;
		outNodes[0][numNodes].data[0] = 0;
		inNodes[1][numNodes].data[0] = 0;
		outNodes[1][numNodes].data[0] = 0;

		numNodes++;
		return (numNodes - 1);
	}

	void addEdge(uint32_t srcNodeId, uint32_t desNodeId, uint32_t txId)
	{
		// Resolve external node id to internal id, and create if not exists
		uint32_t iSrcId = mapping.resolve(srcNodeId);
		if (iSrcId == 0xFFFFFFFF) iSrcId = mapping.insert(srcNodeId, allocMainNodeId());
		uint32_t iDesId = mapping.resolve(desNodeId);
		if (iDesId == 0xFFFFFFFF) iDesId = mapping.insert(desNodeId, allocMainNodeId());

		// Add outgoing edge to source
		txEdges.addTransactionEdge(iSrcId, false, iDesId, txId, 0xFFFFFFFF);
		outNodes[0][iSrcId].data[0] |= MASK_TXAVAILABLE;
		outNodes[1][iSrcId].data[0] |= MASK_TXAVAILABLE;

		// Add ingoing edge to destination
		txEdges.addTransactionEdge(iDesId, true, iSrcId, txId, 0xFFFFFFFF);
		inNodes[0][iDesId].data[0] |= MASK_TXAVAILABLE;
		inNodes[1][iDesId].data[0] |= MASK_TXAVAILABLE;

		// Add tracking
		addNodeTracking(iSrcId);
		addNodeTracking(iDesId);
	}

	bool removeFixedEdge(FixedEdgeList *fixedEdgeList, uint32_t nodeId, bool remove)
	{
		bool edgeRemoved = false;

		// Fixed bitmap edges
		uint32_t bmOffset = nodeId % 32;
		uint32_t bmIndex = nodeId - bmOffset;
		BitmapEdge *bitmapEdge = (BitmapEdge*)&fixedEdgeList->data[0];
		for (int i = 0; i < fixedEdgeList->bitmapEdges; i++) {
			if (bitmapEdge[i].index == bmIndex) {
				uint32_t testBit = (1 << bmOffset);
				if ((bitmapEdge[i].map & testBit) == testBit) {
					if (remove == true) {
						bitmapEdge[i].map &= ~testBit;
						fixedEdges.syncWithPointer(&bitmapEdge[i].map, 1);
					}
					edgeRemoved = true;
					if (remove == false) return true;
				}
			}
		}

		// Fixed single edges
		uint32_t *singleEdge = (uint32_t*)&fixedEdgeList->data[fixedEdgeList->bitmapEdges * 2];
		for (int i = 0; i < fixedEdgeList->singleEdges; i++) {
			if (singleEdge[i] == nodeId) {
				if (remove == true) {
					singleEdge[i] = singleEdge[fixedEdgeList->singleEdges - 1];
					fixedEdges.syncWithPointer(&singleEdge[i], 1);
					fixedEdgeList->singleEdges--;
					fixedEdges.syncWithPointer(&fixedEdgeList->singleEdges, 1);
				}
				edgeRemoved = true;
				if (remove == false) return true;
			}
		}

		return edgeRemoved;
	}

	bool removeLocalOutEdge(uint32_t iSrcId, uint32_t iDesId, bool remove)
	{
		bool edgeRemoved = false;

		// Local edge list		
		uint32_t localCount = (outNodes[0][iSrcId].data[0] >> POS_LOCALCOUNT) & 7;
		uint32_t localFirst = (outNodes[0][iSrcId].data[0] >> BIT_FIXEDAVAILABLE) & 1;
		if (localCount > 0) {
			uint32_t *localEdges = &outNodes[0][iSrcId].data[0];
			uint32_t *localEdgesRemote = &outNodes[1][iSrcId].data[0];
			for (int i = localFirst; i < (localFirst + localCount); i++) {
				if ((localEdges[i] & MASK_NODE) == iDesId) {
					if (remove == true) {
						uint32_t currentLocalCount = (localEdges[0] >> POS_LOCALCOUNT) & 7;
						localEdges[i] = (localEdges[i] & (~MASK_NODE)) | (localEdges[currentLocalCount - 1] & MASK_NODE);
						localEdgesRemote[i] = localEdges[i];

						//cerr << "[OUT: " << i << " <- " << currentLocalCount << "]" << endl;

						// Decrease local count						
						currentLocalCount--;
						localEdges[0] = (localEdges[0] & (~MASK_LOCALCOUNT)) | (currentLocalCount << POS_LOCALCOUNT);
						localEdgesRemote[0] = localEdges[0];
					}
					edgeRemoved = true;
					if (remove == false) return true;
				}

			}
		}

		return edgeRemoved;
	}

	bool removeLocalInEdge(uint32_t iSrcId, uint32_t iDesId, bool remove)
	{
		bool edgeRemoved = false;

		// Local edge list
		uint32_t localCount = (inNodes[0][iDesId].data[0] >> POS_LOCALCOUNT) & 7;
		uint32_t localFirst = (inNodes[0][iDesId].data[0] >> BIT_FIXEDAVAILABLE) & 1;
		if (localCount > 0) {
			uint32_t *localEdges = &inNodes[0][iDesId].data[0];
			uint32_t *localEdgesRemote = &inNodes[1][iDesId].data[0];
			for (int i = localFirst; i < (localFirst + localCount); i++) {
				if ((localEdges[i] & MASK_NODE) == iSrcId) {
					if (remove == true) {
						uint32_t currentLocalCount = (localEdges[0] >> POS_LOCALCOUNT) & 7;
						localEdges[i] = (localEdges[i] & (~MASK_NODE)) | (localEdges[currentLocalCount - 1] & MASK_NODE);
						localEdgesRemote[i] = localEdges[i];

						//cerr << "[IN: " << i << " <- " << currentLocalCount << "]" << endl;

						// Decrease local count						
						currentLocalCount--;
						localEdges[0] = (localEdges[0] & (~MASK_LOCALCOUNT)) | (currentLocalCount << POS_LOCALCOUNT);
						localEdgesRemote[0] = localEdges[0];
					}
					edgeRemoved = true;
					if (remove == false) return true;
				}

			}
		}

		return edgeRemoved;
	}

	void removeEdge(uint32_t srcNodeId, uint32_t desNodeId, uint32_t txId)
	{
		bool tracking = false;

		// Resolve external node id
		uint32_t iSrcId = mapping.resolve(srcNodeId);
		uint32_t iDesId = mapping.resolve(desNodeId);
		if ((iSrcId == 0xFFFFFFFF) || (iDesId == 0xFFFFFFFF)) return;

		// Remove outgoing local edge
		if (removeLocalOutEdge(iSrcId, iDesId, false) == true) {
			txEdges.addTransactionEdge(iSrcId, false, iDesId, 0, txId);
			removeLocalOutEdge(iSrcId, iDesId, true);
			tracking = true;
		}

		// Remove outgoing fixed edge
		// First find out, if there exists one, then add an transaction edge with lifetime until now
		// end finally remove the edge from the fixed edge list
		uint32_t outData0 = outNodes[0][iSrcId].data[0];
		if ((outData0 & MASK_FIXEDAVAILABLE) == MASK_FIXEDAVAILABLE) {
			FixedEdgeList *fixedEdgeList = (FixedEdgeList*)&fixedEdges.outEdges[0][outData0 & MASK_FIXEDPOINTER];
			if (removeFixedEdge(fixedEdgeList, iDesId, false) == true) {
				txEdges.addTransactionEdge(iSrcId, false, iDesId, 0, txId);
				outNodes[0][iSrcId].data[0] |= MASK_TXAVAILABLE;
				outNodes[1][iSrcId].data[0] |= MASK_TXAVAILABLE;
				removeFixedEdge(fixedEdgeList, iDesId, true);
				tracking = true;
			}
		}

		// Remove outgoing edge from the transaction edge list
		txEdges.setTransactionEdgeAsRemoved(iSrcId, false, iDesId, txId);

		// Remove outgoing local edge
		if (removeLocalInEdge(iSrcId, iDesId, false) == true) {
			txEdges.addTransactionEdge(iDesId, true, iSrcId, 0, txId);
			removeLocalInEdge(iSrcId, iDesId, true);
			tracking = true;
		}

		// Remove ingoing fixed edge
		// First find out, if there exists one, then add an transaction edge with lifetime until now
		// end finally remove the edge from the fixed edge list
		uint32_t inData0 = inNodes[0][iDesId].data[0];
		if ((inData0 & MASK_FIXEDAVAILABLE) == MASK_FIXEDAVAILABLE) {
			FixedEdgeList *fixedEdgeList = (FixedEdgeList*)&fixedEdges.inEdges[0][inData0 & MASK_FIXEDPOINTER];
			if (removeFixedEdge(fixedEdgeList, iSrcId, false) == true) {
				txEdges.addTransactionEdge(iDesId, true, iSrcId, 0, txId);
				inNodes[0][iDesId].data[0] |= MASK_TXAVAILABLE;
				inNodes[1][iDesId].data[0] |= MASK_TXAVAILABLE;
				removeFixedEdge(fixedEdgeList, iSrcId, true);
				tracking = true;
			}
		}

		// Add ingoing edge from the transaction edge list
		txEdges.setTransactionEdgeAsRemoved(iDesId, true, iSrcId, txId);

		// Add tracking
		if (tracking == true) {
			addNodeTracking(iSrcId);
			addNodeTracking(iDesId);
		}
	}

	uint32_t storeFixedEdges(vector<uint32_t> &edges, FixedEdgeList *edgeList, uint32_t *localNodes)
	{
		// Create 32-bit bitmaps
		uint32_t bitmapCount = 0;
		std::unordered_map<uint32_t, uint32_t> bitmapMap;
		bitmapMap.clear();
		for (int k = 0; k < edges.size(); k++) {
			uint32_t offset = edges[k] % 32;
			uint32_t index = edges[k] - offset;
			if (bitmapMap.count(index) == 0) {
				bitmapMap[index] = (1 << offset);
				bitmapCount++;
			}
			else bitmapMap[index] = bitmapMap[index] | (1 << offset);
		}

		// Count bitmaps and single edges
		uint32_t bitmapEdges = 0;
		uint32_t singleEdges = 0;
		for (auto o : bitmapMap) {
			uint32_t numBits = _mm_popcnt_u32(o.second);
			if (numBits > 0) {
				if (numBits >= USE_BITMAP_THRESHOLD) bitmapEdges++;
				else singleEdges += numBits;
			}
		}
		uint32_t localFirst = 1;
		uint32_t localCount = 0;
		uint32_t localRemaining = NODE_LOCAL_SIZE - 1;
		if ((bitmapEdges == 0) && (singleEdges <= NODE_LOCAL_SIZE)) {
			localFirst = 0;
			localRemaining++;
		}

		// Store bitmap edges
		if (bitmapEdges > 0) {
			BitmapEdge *bmEdge = (BitmapEdge*)&edgeList->data[0];
			int cur = 0;
			for (auto o : bitmapMap) {
				uint32_t numBits = _mm_popcnt_u32(o.second);
				if ((numBits > 0) && (numBits >= USE_BITMAP_THRESHOLD)) {
					bmEdge[cur].index = o.first;
					bmEdge[cur].map = o.second;
					cur++;
				}
			}
		}

		// Store single edges
		if (singleEdges > 0) {
			uint32_t *singleEdge = (uint32_t*)&edgeList->data[bitmapEdges * 2];
			int cur = 0;
			for (auto o : bitmapMap) {
				uint32_t numBits = _mm_popcnt_u32(o.second);
				if ((numBits > 0) && (numBits < USE_BITMAP_THRESHOLD)) {
					uint32_t nodeArray[32];
					uint32_t nodeCount = bitmapToArray(o.first & 0x7FFFFFFF, o.second, &nodeArray[0]);
					for (int i = 0; i < nodeCount; i++) {
						// Add to local edge list
						if (localRemaining > 0) {
							localNodes[localFirst + localCount] = nodeArray[i];
							localRemaining--;
							localCount++;
						}

						// Add to fixed edge list
						else {
							singleEdge[cur] = nodeArray[i];
							cur++;
						}
					}
				}
			}
		}

		// Store local edge count
		if (localCount > 0) {
			localNodes[0] |= localCount << POS_LOCALCOUNT;
		}

		edgeList->bitmapEdges = bitmapEdges;
		edgeList->singleEdges = singleEdges - localCount;
		return (bitmapEdges * 2 + (singleEdges - localCount));
	}

	void import(SimpleGraph *simpleGraph)
	{
		// Temporary mapping from internal to external id
		vector<SimpleNode*> externalNodes;
		externalNodes.clear();
		externalNodes.push_back(0);

		// Allocate internal node ids
		for (int i = 0; i < simpleGraph->sortedNodeList.size(); i++)
		{
			SimpleNode *node = simpleGraph->sortedNodeList[i];
			node->internalId = allocMainNodeId();
			mapping.insert(node->externalId, node->internalId);
			externalNodes.push_back(node);
		}

		// Add edges for each node
		for (int i = 1; i < numNodes; i++) {
			SimpleNode *node = externalNodes[i];

			// Get valid outgoing edges and sort them
			vector<uint32_t> outgoing;
			outgoing.clear();
			for (auto outNode : node->out) {
				outgoing.push_back(outNode->internalId);
			}
			std::sort(outgoing.begin(), outgoing.end());

			// Get valid ingoing edges and sort them
			vector<uint32_t> ingoing;
			ingoing.clear();
			for (auto inNode : node->in) {
				ingoing.push_back(inNode->internalId);
			}
			std::sort(ingoing.begin(), ingoing.end());

			// Initialize
			outNodes[0][i].data[0] = 0;
			inNodes[0][i].data[0] = 0;
			outNodes[1][i].data[0] = 0;
			inNodes[1][i].data[0] = 0;

			// Store outgoing edges as fixed edges
			if (outgoing.size() > 0) {
				outNodes[0][i].data[0] = fixedEdges.getNextFreeOutEntry();
				FixedEdgeList *edgeList = (FixedEdgeList*)&fixedEdges.outEdges[0][outNodes[0][i].data[0]];
				uint32_t usedEntries = storeFixedEdges(outgoing, edgeList, &outNodes[0][i].data[0]);
				if (usedEntries > 0) {
					fixedEdges.increaseOutPointer(usedEntries + 2);
					outNodes[0][i].data[0] |= MASK_FIXEDAVAILABLE;

				}
				for (int m = 0; m < NODE_LOCAL_SIZE; m++) outNodes[1][i].data[m] = outNodes[0][i].data[m];
			}

			// Store ingoing edges as fixed edges
			if (ingoing.size() > 0) {
				inNodes[0][i].data[0] = fixedEdges.getNextFreeInEntry();
				FixedEdgeList *edgeList = (FixedEdgeList*)&fixedEdges.inEdges[0][inNodes[0][i].data[0]];
				uint32_t usedEntries = storeFixedEdges(ingoing, edgeList, &inNodes[0][i].data[0]);
				if (usedEntries > 0) {
					fixedEdges.increaseInPointer(usedEntries + 2);
					inNodes[0][i].data[0] |= MASK_FIXEDAVAILABLE;
				}
				for (int m = 0; m < NODE_LOCAL_SIZE; m++) inNodes[1][i].data[m] = inNodes[0][i].data[m];
			}

		}

		// Synchronize fixed edge list with node 1 buffers
		fixedEdges.syncOutEdges(0, fixedEdges.nextOutEntry);
		fixedEdges.syncInEdges(0, fixedEdges.nextInEntry);
	}

	void shortestPathQuery_processOutgoingEdge(uint32_t outNodeId, int numaNode, uint32_t &totalInSet, uint32_t txId, BdbfsBitmap &bitmap, BfsQueue &outQueue, BfsQueue &inQueue)
	{
		// Local edge list
		uint32_t localCount = (outNodes[numaNode][outNodeId].data[0] >> POS_LOCALCOUNT) & 7;
		uint32_t localFirst = (outNodes[numaNode][outNodeId].data[0] >> BIT_FIXEDAVAILABLE) & 1;
		if (localCount > 0) {
			uint32_t *localEdges = &outNodes[numaNode][outNodeId].data[0];
			for (int i = localFirst; i < (localFirst + localCount); i++) {
				uint32_t outSet, inSet;
				bitmap.setOutWithReturnState(localEdges[i] & MASK_NODE, outSet, inSet);
				if (outSet == 1) continue;
				totalInSet |= inSet;
				outQueue.push(localEdges[i] & MASK_NODE);
			}
		}

		// Fixed edge list
		if ((outNodes[numaNode][outNodeId].data[0] & MASK_FIXEDAVAILABLE) == MASK_FIXEDAVAILABLE) {
			uint32_t outPointer = outNodes[numaNode][outNodeId].data[0] & MASK_FIXEDPOINTER;
			FixedEdgeList *fixedEdgeList = (FixedEdgeList*)&fixedEdges.outEdges[numaNode][outPointer];

			BitmapEdge *bitmapEdge = (BitmapEdge*)&fixedEdgeList->data[0];
			for (int i = 0; i < fixedEdgeList->bitmapEdges; i++) {
				uint32_t outSet, inSet;
				bitmap.setOutRangeWithReturnState(bitmapEdge[i].index, bitmapEdge[i].map, outSet, inSet);
				totalInSet |= inSet;
				outQueue.pushBitmapRange(bitmapEdge[i].index, outSet);
			}

			uint32_t *singleEdge = (uint32_t*)&fixedEdgeList->data[fixedEdgeList->bitmapEdges * 2];
			for (int i = 0; i < fixedEdgeList->singleEdges; i++) {
				uint32_t outSet, inSet;
				bitmap.setOutWithReturnState(singleEdge[i], outSet, inSet);
				if (outSet == 1) continue;
				totalInSet |= inSet;
				outQueue.push(singleEdge[i]);
			}
		}

		// Transaction edge list
		if ((outNodes[numaNode][outNodeId].data[0] & MASK_TXAVAILABLE) == MASK_TXAVAILABLE) {
			TransactionEdgeList *edgeList = txEdges.getFirstOutgoingEdgeList(outNodeId);
			while (edgeList != nullptr) {
				for (int i = 0; i < edgeList->count; i++) {
					TransactionEdge *edge = &edgeList->edges[i];
					if ((edge->nodeId == outNodeId) && (txId >= edge->addTx) && (txId < edge->removeTx)) {
						uint32_t outSet, inSet;
						bitmap.setOutWithReturnState(edge->desNodeId, outSet, inSet);
						if (outSet != 1) {
							totalInSet |= inSet;
							outQueue.push(edge->desNodeId);
						}
					}

				}
				edgeList = edgeList->next;
			}
		}
	}

	void shortestPathQuery_processIngoingEdge(uint32_t inNodeId, int numaNode, uint32_t &totalOutSet, uint32_t txId, BdbfsBitmap &bitmap, BfsQueue &outQueue, BfsQueue &inQueue)
	{
		// Local edge list
		uint32_t localCount = (inNodes[numaNode][inNodeId].data[0] >> POS_LOCALCOUNT) & 7;
		uint32_t localFirst = (inNodes[numaNode][inNodeId].data[0] >> BIT_FIXEDAVAILABLE) & 1;
		if (localCount > 0) {
			uint32_t *localEdges = &inNodes[numaNode][inNodeId].data[0];
			for (int i = localFirst; i < (localFirst + localCount); i++) {
				uint32_t outSet, inSet;
				bitmap.setInWithReturnState(localEdges[i] & MASK_NODE, outSet, inSet);
				if (inSet == 1) continue;
				totalOutSet |= outSet;
				inQueue.push(localEdges[i] & MASK_NODE);
			}
		}

		// Fixed edge list		
		if ((inNodes[numaNode][inNodeId].data[0] & MASK_FIXEDAVAILABLE) == MASK_FIXEDAVAILABLE) {
			uint32_t inPointer = inNodes[numaNode][inNodeId].data[0] & MASK_FIXEDPOINTER;
			FixedEdgeList *fixedEdgeList = (FixedEdgeList*)&fixedEdges.inEdges[numaNode][inPointer];

			BitmapEdge *bitmapEdge = (BitmapEdge*)&fixedEdgeList->data[0];
			for (int i = 0; i < fixedEdgeList->bitmapEdges; i++) {
				uint32_t outSet, inSet;
				bitmap.setInRangeWithReturnState(bitmapEdge[i].index, bitmapEdge[i].map, outSet, inSet);
				totalOutSet |= outSet;
				inQueue.pushBitmapRange(bitmapEdge[i].index, inSet);
			}

			uint32_t *singleEdge = (uint32_t*)&fixedEdgeList->data[fixedEdgeList->bitmapEdges * 2];
			for (int i = 0; i < fixedEdgeList->singleEdges; i++) {
				uint32_t outSet, inSet;
				bitmap.setInWithReturnState(singleEdge[i], outSet, inSet);
				if (inSet == 1) continue;
				totalOutSet |= outSet;
				inQueue.push(singleEdge[i]);
			}
		}

		// Transaction edge list
		if ((inNodes[numaNode][inNodeId].data[0] & MASK_TXAVAILABLE) == MASK_TXAVAILABLE) {
			TransactionEdgeList *edgeList = txEdges.getFirstIngoingEdgeList(inNodeId);
			while (edgeList != nullptr) {
				for (int i = 0; i < edgeList->count; i++) {
					TransactionEdge *edge = &edgeList->edges[i];
					if ((edge->nodeId == (inNodeId)) && (txId >= edge->addTx) && (txId < edge->removeTx)) {
						uint32_t outSet, inSet;
						bitmap.setInWithReturnState(edge->desNodeId, outSet, inSet);
						if (inSet != 1) {
							totalOutSet |= outSet;
							inQueue.push(edge->desNodeId);
						}
					}

				}
				edgeList = edgeList->next;
			}
		}
	}


	inline int shortestPathQuery(int numaNode, uint32_t iSrcId, uint32_t iDesId, uint32_t txId, BdbfsBitmap &bitmap, BfsQueue &outQueue, BfsQueue &inQueue)
	{
		numaNode = 1;

		// Check some early stop conditions
		uint32_t outSet, inSet;
		if (iSrcId == iDesId) return 0;
		if (outNodes[numaNode][iSrcId].data[0] == 0) return -1;
		if (inNodes[numaNode][iDesId].data[0] == 0) return -1;

		// Initialize
		bitmap.checkSize(maxBitmapSize);
		bitmap.clear(numNodes);	
		//bitmap.initialize();
		outQueue.initialize();
		inQueue.initialize();

		// Set start nodes
		outQueue.setInit(iSrcId);
		inQueue.setInit(iDesId);
		bitmap.setOut(iSrcId);
		bitmap.setIn(iDesId);

		while (true) {
			// Follow outgoing edges
			if (outQueue.workSize() <= inQueue.workSize()) {
				//if (true) {
				uint32_t totalInSet = 0;

				while (outQueue.isEmptyDepth0() == false) {
					// Get node id
					uint32_t outNodeId = outQueue.pop();

					// Single edge
					if ((outNodeId & 0x80000000) == 0) {
						shortestPathQuery_processOutgoingEdge(outNodeId, numaNode, totalInSet, txId, bitmap, outQueue, inQueue);
					}

					// Bitmap edges
					else {
						uint32_t map = outQueue.pop();
						uint32_t nodeArray[32];
						uint32_t nodeCount = bitmapToArray(outNodeId & 0x7FFFFFFF, map, &nodeArray[0]);

						for (int n = 0; n < nodeCount; n++) {
							shortestPathQuery_processOutgoingEdge(nodeArray[n], numaNode, totalInSet, txId, bitmap, outQueue, inQueue);
						}
					}

					if (totalInSet >= 1) return (outQueue.currentDepth + inQueue.currentDepth + 1);

				}

				if (totalInSet >= 1) return (outQueue.currentDepth + inQueue.currentDepth + 1);

				// Next outgoing depth
				outQueue.nextDepth();
				if (outQueue.isEmptyDepth0() == true) return -1;
			}
			

			// Follow ingoing edges
			if (inQueue.workSize() <= outQueue.workSize()) {
				//if (true) {
				uint32_t totalOutSet = 0;
				while (inQueue.isEmptyDepth0() == false) {

					uint32_t inNodeId = inQueue.pop();

					// Single edge
					if ((inNodeId & 0x80000000) == 0) {
						shortestPathQuery_processIngoingEdge(inNodeId, numaNode, totalOutSet, txId, bitmap, outQueue, inQueue);
					}

					// Bitmap edge
					else {
						uint32_t map = inQueue.pop();
						uint32_t nodeArray[32];
						uint32_t nodeCount = bitmapToArray(inNodeId & 0x7FFFFFFF, map, &nodeArray[0]);

						for (int n = 0; n < nodeCount; n++) {
							shortestPathQuery_processIngoingEdge(nodeArray[n], numaNode, totalOutSet, txId, bitmap, outQueue, inQueue);
						}
					}

					if (totalOutSet >= 1) return (outQueue.currentDepth + inQueue.currentDepth + 1);

				}

				if (totalOutSet >= 1) return (outQueue.currentDepth + inQueue.currentDepth + 1);

				// Next outgoing depth
				inQueue.nextDepth();
				if (inQueue.isEmptyDepth0() == true) return -1;
			}
		}

		return -1;
	}

	void addNodeTracking(uint32_t nodeId)
	{
		if (currentTrack >= maxTrack) return;
		trackNodeId[currentTrack] = nodeId;
		currentTrack++;
	}

	// Merge one node id
	void mergeOutNodeEdges(uint32_t nodeId, TransactionEdgeList *edgeList, uint32_t currentTx, int &notRemoved)
	{
		for (int i = 0; i < edgeList->count; i++) {
			if (edgeList->edges[i].nodeId == nodeId) {
				bool remove = false;
				uint32_t *localEdges = &outNodes[0][nodeId].data[0];
				uint32_t *remoteEdges = &outNodes[1][nodeId].data[0];
				uint32_t localCount = (localEdges[0] >> POS_LOCALCOUNT) & 7;
				uint32_t localFirst = (localEdges[0] >> BIT_FIXEDAVAILABLE) & 1;
				uint32_t localSpace = (NODE_LOCAL_SIZE - localFirst) - localCount;

				// If outdated
				if (edgeList->edges[i].removeTx < currentTx) remove = true;

				// If valid edge and space in local edge list
				else if ((edgeList->edges[i].addTx <= currentTx) && (edgeList->edges[i].removeTx == 0xFFFFFFFF)) {
					if (localSpace > 0) {
						localEdges[localFirst + localCount] = (localEdges[localFirst + localCount] & (~MASK_NODE)) | (edgeList->edges[i].desNodeId & MASK_NODE);
						remoteEdges[localFirst + localCount] = localEdges[localFirst + localCount];
						localCount++;
						localSpace--;
						localEdges[0] = (localEdges[0] & (~MASK_LOCALCOUNT)) | (localCount << POS_LOCALCOUNT);
						remoteEdges[0] = localEdges[0];
						remove = true;
					}
				}

				// Remove entry
				if (remove == true) {
					edgeList->edges[i].nodeId = edgeList->edges[edgeList->count - 1].nodeId;
					edgeList->edges[i].desNodeId = edgeList->edges[edgeList->count - 1].desNodeId;
					edgeList->edges[i].addTx = edgeList->edges[edgeList->count - 1].addTx;
					edgeList->edges[i].removeTx = edgeList->edges[edgeList->count - 1].removeTx;
					edgeList->count--;
					return mergeOutNodeEdges(nodeId, edgeList, currentTx, notRemoved);
				}
				else notRemoved++;
			}
		}

		if (edgeList->next != nullptr) mergeOutNodeEdges(nodeId, edgeList->next, currentTx, notRemoved);
	}

	// Merge one node id
	bool mergeInNodeEdges(uint32_t nodeId, TransactionEdgeList *edgeList, uint32_t currentTx, int &notRemoved)
	{
		bool couldMergeAll = true;

		for (int i = 0; i < edgeList->count; i++) {
			if (edgeList->edges[i].nodeId == nodeId) {
				bool remove = false;
				uint32_t *localEdges = &inNodes[0][nodeId].data[0];
				uint32_t *remoteEdges = &inNodes[1][nodeId].data[0];
				uint32_t localCount = (localEdges[0] >> POS_LOCALCOUNT) & 7;
				uint32_t localFirst = (localEdges[0] >> BIT_FIXEDAVAILABLE) & 1;
				uint32_t localSpace = (NODE_LOCAL_SIZE - localFirst) - localCount;

				// If outdated
				if (edgeList->edges[i].removeTx < currentTx) remove = true;

				// If valid edge and space in local edge list
				else if ((edgeList->edges[i].addTx <= currentTx) && (edgeList->edges[i].removeTx == 0xFFFFFFFF)) {
					if (localSpace > 0) {
						localEdges[localFirst + localCount] = (localEdges[localFirst + localCount] & (~MASK_NODE)) | (edgeList->edges[i].desNodeId & MASK_NODE);
						remoteEdges[localFirst + localCount] = localEdges[localFirst + localCount];
						localCount++;
						localSpace--;
						localEdges[0] = (localEdges[0] & (~MASK_LOCALCOUNT)) | (localCount << POS_LOCALCOUNT);
						remoteEdges[0] = localEdges[0];
						remove = true;
					}
				}

				// Remove entry
				if (remove == true) {					
					edgeList->edges[i].nodeId = edgeList->edges[edgeList->count - 1].nodeId;
					edgeList->edges[i].desNodeId = edgeList->edges[edgeList->count - 1].desNodeId;
					edgeList->edges[i].addTx = edgeList->edges[edgeList->count - 1].addTx;
					edgeList->edges[i].removeTx = edgeList->edges[edgeList->count - 1].removeTx;
					edgeList->count--;
					return mergeInNodeEdges(nodeId, edgeList, currentTx, notRemoved);
				}
				else notRemoved++;
			}
		}
		
		if (edgeList->next != nullptr) mergeInNodeEdges(nodeId, edgeList->next, currentTx, notRemoved);
	}

	// Try to merge the transaction edges into local edges
	void mergeTrackedNodeEdges(uint32_t currentTx)
	{
		for (int i = 0; i < currentTrack; i++) {
			int notRemoved = 0;
			uint32_t *localEdges = &outNodes[0][trackNodeId[i]].data[0];
			uint32_t *remoteEdges = &outNodes[1][trackNodeId[i]].data[0];
			if ((localEdges[0] & MASK_TXAVAILABLE) == MASK_TXAVAILABLE) {
				mergeOutNodeEdges(trackNodeId[i], txEdges.getFirstOutgoingEdgeList(trackNodeId[i]), currentTx, notRemoved);
				if (notRemoved == 0) {
					localEdges[0] &= (~MASK_TXAVAILABLE);
					remoteEdges[0] = localEdges[0];
				}
			}

			notRemoved = 0;
			localEdges = &inNodes[0][trackNodeId[i]].data[0];
			remoteEdges = &inNodes[1][trackNodeId[i]].data[0];
			if ((localEdges[0] & MASK_TXAVAILABLE) == MASK_TXAVAILABLE) {
				mergeInNodeEdges(trackNodeId[i], txEdges.getFirstIngoingEdgeList(trackNodeId[i]), currentTx, notRemoved);
				if (notRemoved == 0) {
					localEdges[0] &= (~MASK_TXAVAILABLE);
					remoteEdges[0] = localEdges[0];
				}
			}

		}
		currentTrack = 0;
	}

};