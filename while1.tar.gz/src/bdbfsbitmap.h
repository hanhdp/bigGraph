#pragma once

// Init value (can be increased during runtime)
uint32_t maxBitmapSize = 16 * 1024 * 1024;

class BdbfsBitmap {
public:
	int numaNode = 0;
	uint32_t numWords = 0;
	uint64_t *data = nullptr;

	// Create and allocate the bitmap
	BdbfsBitmap(int numaNode)
	{
		this->numaNode = numaNode;
		numWords = 0;
		data = nullptr;

		numWords = (maxBitmapSize) / 32;
#ifdef NUMA_ENABLED
		data = (uint64_t*)numa_alloc_local(numWords * sizeof(uint64_t));
#endif
#ifndef NUMA_ENABLED
		data = (uint64_t*)malloc(numWords * sizeof(uint64_t));
#endif
		memset(data, 0, numWords * sizeof(uint64_t));
	}

	// Check if the size of the bitmap has to be increased
	void checkSize(uint32_t numBits)
	{
		uint32_t newNumWords = (numBits + 31) / 32;
		if (newNumWords > numWords) {
#ifdef NUMA_ENABLED
			data = (uint64_t*)numa_realloc((void*)data, numWords * sizeof(uint64_t), newNumWords * sizeof(uint64_t));
#endif
#ifndef NUMA_ENABLED
			data = (uint64_t*)realloc((void*)data, newNumWords * sizeof(uint64_t));
#endif
			numWords = newNumWords;
		}
	}

	// Zero the first x bits in the bitmap
	void clear(uint32_t numBits)
	{
		uint32_t localNumWords = (numBits + 31) / 32;
		memset((void*)&data[0], 0, localNumWords * 8);
	}

	inline void setOutWithReturnState(uint32_t id, uint32_t &outSet, uint32_t &inSet)
	{
		uint32_t wordId = id / 32;
		uint32_t offset = id % 32;
		uint64_t word = data[wordId];

		inSet = ((word >> (offset + 32)) & 1);
		outSet = ((word >> offset) & 1);
		data[wordId] = word | (1LL << offset);
	}

	inline void setOutRangeWithReturnState(uint32_t id, uint32_t map, uint32_t &outSet, uint32_t &inSet)
	{
		uint32_t wordId = id / 32;
		uint32_t offset = 0;
		uint64_t word = data[wordId];
		uint32_t inWord = word >> 32;
		uint32_t outWord = word & 0xFFFFFFFF;

		inSet = inWord & map;
		outSet = (outWord ^ map) & map;

		data[wordId] = (uint64_t)(outWord | map) | ((uint64_t)inWord << 32);
	}

	inline void setInWithReturnState(uint32_t id, uint32_t &outSet, uint32_t &inSet)
	{
		uint32_t wordId = id / 32;
		uint32_t offset = id % 32;
		uint64_t word = data[wordId];

		inSet = ((word >> (offset + 32)) & 1);
		outSet = ((word >> offset) & 1);
		data[wordId] = word | (1LL << (offset + 32));
	}

	inline void setInRangeWithReturnState(uint32_t id, uint32_t map, uint32_t &outSet, uint32_t &inSet)
	{
		uint32_t wordId = id / 32;
		uint32_t offset = 0;
		uint64_t word = data[wordId];
		uint32_t inWord = word >> 32;
		uint32_t outWord = word & 0xFFFFFFFF;

		inSet = (inWord ^ map) & map;
		outSet = outWord & map;
		
		data[wordId] = (uint64_t)(outWord) | (((uint64_t)inWord | (uint64_t)map) << 32);
	}

	void setOut(uint32_t id)
	{
		uint32_t wordId = id / 32;
		uint32_t offset = id % 32;
		data[wordId] |= (1LL << offset);
	}

	void setIn(uint32_t id)
	{
		uint32_t wordId = id / 32;
		uint32_t offset = (id % 32) + 32;
		data[wordId] |= (1LL << offset);
	}

};
