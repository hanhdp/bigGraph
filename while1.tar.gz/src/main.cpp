
#include "stdincludes.h"

#ifdef NUMA_ENABLED
#include <numa.h>
#endif

uint32_t numQueries = 0;

#include "parser.h"
#include "perf.h"
#include "resultbuffer.h"

ResultBuffer resultBuffer;

#include "simplelookup.h"

#include "bdbfsbitmap.h"
#include "bfsqueue.h"

#include "fixededges.h"
#include "txedges.h"
#include "simplegraph.h"
#include "nodemapping.h"
#include "speedgraph.h"

Parser parser;
SimpleGraph simpleGraph;
SpeedGraph speedGraph;

#include "worker.h"

#include <stdlib.h>
#include <unistd.h>


int main()
{
	initLookupTable();
	initSectionTicks();
	initializeWorkerThreads();

	// Some variables
	char command = '0';
	uint32_t srcNodeId = 0;
	uint32_t desNodeId = 0;

	// Read init graph
	cerr << "Read init graph ... ";
	uint64_t numEdges = 0;
	startTimer();
	while (parser.getInitGraphEdge(&srcNodeId, &desNodeId) == true) {
		simpleGraph.addEdge(srcNodeId, desNodeId);
		numEdges++;
	}
	cerr << "done (" << finishTimer() << " ms)" << endl;

	// Preprocessing
	simpleGraph.preprocess();

	// Import edges to the optimized SpeedGraph
	cerr << "Importing ... ";
	startTimer();
	speedGraph.setSize(simpleGraph.nodes.size(), numEdges);
	speedGraph.import(&simpleGraph);
	cerr << "done (" << finishTimer() << " ms)" << endl;

	// Start batch processing
	cout << "R" << endl;

	// Variables for each batch
	uint32_t numOutstandingQueries = 0;
	resultBuffer.reset();

	uint64_t cycleSum = 0;
	uint32_t numBatches = 0;
	uint32_t currentWorker = 1;
	uint32_t currentWorkerCounter = 0;
	uint32_t numFiltered = 0;

	// Current transaction id
	uint32_t currentTxId = 0;

	while (true) {
		// Parse command		
		startSection(SECTION_PARSE);
		parser.getGraphOperation(&command, &srcNodeId, &desNodeId);
		endSection(SECTION_PARSE);
		if (parser.endOfFile == true) break;

		// Increase transaction id
		currentTxId++;

		// Shortest Path Query
		if (command == 'Q') {
			startSection(SECTION_DISTRIBUTE);

			// Get internal source and destination node id
			uint32_t iSrcId = speedGraph.mapping.resolve(srcNodeId);
			uint32_t iDesId = speedGraph.mapping.resolve(desNodeId);

			// Some checks and filters
			if (srcNodeId == desNodeId) {
				numFiltered++;
				resultBuffer.setResult(numOutstandingQueries, 0);
			}
			else if ((iSrcId == 0xFFFFFFFF) || (iDesId == 0xFFFFFFFF)) {
				numFiltered++;
				resultBuffer.setResult(numOutstandingQueries, -1);
			}
			else if ((speedGraph.outNodes[0][iSrcId].data[0] == 0) || (speedGraph.inNodes[0][iDesId].data[0] == 0)) {
				numFiltered++;
				resultBuffer.setResult(numOutstandingQueries, -1);
			}

			// Distribute
			else {
				// Insert query
				while (workerThreads[currentWorker].insertQuery(numOutstandingQueries, currentTxId, iSrcId, iDesId) == false) {
					currentWorkerCounter = 0;
					currentWorker = (currentWorker % (numWorkers - 1)) + 1;
				}

				// Increment counter for distributing queries to the workers
				currentWorkerCounter++;
				uint32_t taskThreshold = 1;
				if (currentWorkerCounter >= taskThreshold) {
					currentWorkerCounter = 0;
					currentWorker = (currentWorker % (numWorkers - 1)) + 1;
				}
			}

			// Increment number of outstanding queries
			numOutstandingQueries++;

			endSection(SECTION_DISTRIBUTE);
			numQueries++;
		}

		// Add edge
		else if (command == 'A') {
			startSection(SECTION_ADD);
			speedGraph.addEdge(srcNodeId, desNodeId, currentTxId);
			endSection(SECTION_ADD);
		}

		// Delete edge
		else if (command == 'D') {
			startSection(SECTION_REMOVE);
			speedGraph.removeEdge(srcNodeId, desNodeId, currentTxId);
			endSection(SECTION_REMOVE);
		}

		// Finish batch
		if ((command == 'F') || (numOutstandingQueries >= RESULT_BUFFER_SIZE)) {
			numBatches++;

			// Wait for all worker queues being completed
			startSection(SECTION_BATCH);
			resultBuffer.increaseCounter(numFiltered);
			while (resultBuffer.counter != numOutstandingQueries);//sched_yield();
			endSection(SECTION_BATCH);

			// Write results to the output
			startSection(SECTION_OUTPUT);
			resultBuffer.writeResultsToStdout(numOutstandingQueries);
			endSection(SECTION_OUTPUT);

			// Reset some variables
			resultBuffer.reset();
			numOutstandingQueries = 0;
			numFiltered = 0;

			// Merge tracked node edges
			startSection(SECTION_MERGE);
			speedGraph.mergeTrackedNodeEdges(currentTxId);
			endSection(SECTION_MERGE);
		}
	}

	// Stop and join threads
	stopAndJoinWorkerThreads();
}

