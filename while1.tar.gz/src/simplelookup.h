#pragma once

// Simple lookup table for converting a bitmap/bitmask to index numbers
uint64_t lookupTable[256];
uint8_t lookupCount[256];

void initLookupTable()
{
	for (int i = 0; i < 256; i++) {
		lookupCount[i] = 0;
		lookupTable[i] = 0;

		for (int b = 0; b < 8; b++) {
			if (((i >> b) & 1) == 1) {
				lookupCount[i]++;
				lookupTable[i] = (lookupTable[i] << 8) | b;
			}
		}
	}
}

uint32_t bitmapToArray(uint32_t index, uint32_t bitmap, uint32_t *result)
{
	uint32_t resultCount = 0;

	for (int i = 0; i < 32; i += 8) {
		uint8_t byte = (bitmap >> i) & 0xFF;
		if (byte == 0) continue;

		uint64_t value = lookupTable[byte];
		uint32_t count = lookupCount[byte];

		for (uint32_t k = 0; k < count; k++) {
			result[resultCount] = index + i + ((value >> (k * 8)) & 0xFF);
			resultCount++;
		}
	}
	return resultCount;
}
