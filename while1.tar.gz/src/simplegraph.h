
#include <vector>
#include <unordered_map>
#include <set>
#include <unordered_set>

using namespace std;

enum NodeType { NODE_SIMPLE , NODE_OUT1, NODE_IN1, NODE_OUTX, NODE_INX, NODE_IN1OUT1 };

class SimpleNode {
public:
	NodeType type = NODE_SIMPLE;
	uint32_t externalId;
	uint32_t internalId = 0xFFFFFFFF;
	vector<SimpleNode*> in;
	vector<SimpleNode*> out;

	SimpleNode()
	{
		in.clear();
		out.clear();
	}

};

bool simpleNodeSortFunction(SimpleNode *node1, SimpleNode *node2)
{ 
	return (node1->in.size() + node1->out.size()) > (node2->in.size() + node2->out.size());
}

class SimpleGraph
{
public:
	unordered_map<uint32_t, SimpleNode*> nodes;
	vector<SimpleNode*> sortedNodeList;

	SimpleGraph()
	{
		nodes.clear();
		nodes.reserve(8 * 1024 * 1024);
	}

	void addEdge(SimpleNode *srcNode, SimpleNode *desNode)
	{
		srcNode->out.push_back(desNode);
		desNode->in.push_back(srcNode);
	}

	void addEdge(uint32_t srcNodeId, uint32_t desNodeId)
	{
		// Get source node
		SimpleNode *srcNode = nullptr;
		if (nodes.count(srcNodeId) == 0) {
			srcNode = new SimpleNode();
			srcNode->externalId = srcNodeId;
			nodes[srcNodeId] = srcNode;
		}
		else srcNode = nodes[srcNodeId];

		// Get destination node
		SimpleNode *desNode = nullptr;
		if (nodes.count(desNodeId) == 0) {
			desNode = new SimpleNode();
			desNode->externalId = desNodeId;
			nodes[desNodeId] = desNode;
		}
		else desNode = nodes[desNodeId];

		// Add edge
		addEdge(srcNode, desNode);
	}

	void deleteEdge(SimpleNode *srcNode, SimpleNode *desNode)
	{
		// ToDo / Unused
	}

	void deleteEdge(uint32_t srcNodeId, uint32_t desNodeId)
	{
		// ToDo / Unused
	}

	void preprocess()
	{
		uint32_t out1 = 0;
		uint32_t in1 = 0;
		uint32_t outx = 0;
		uint32_t inx = 0;
		uint32_t out1p = 0;
		uint32_t in1p = 0;
		uint32_t pt = 0;
		uint32_t in1outx = 0;
		uint32_t out1inx = 0;

		uint32_t out2 = 0;
		uint32_t out3 = 0;
		uint32_t out4 = 0;
		uint32_t out5 = 0;
		uint32_t in2 = 0;
		uint32_t in3 = 0;
		uint32_t in4 = 0;
		uint32_t in5 = 0;

		uint32_t upto4 = 0;
		uint32_t upto6 = 0;
		uint32_t upto8 = 0;
		uint32_t upto10 = 0;
		uint32_t upto12 = 0;
		
		for (auto nodePair : nodes)
		{
			SimpleNode *node = nodePair.second;

			if (node->out.size() <= 2) out2++;
			if (node->out.size() <= 3) out3++;
			if (node->out.size() <= 4) out4++;
			if (node->out.size() <= 5) out5++;
			if (node->in.size() <= 2) in2++;
			if (node->in.size() <= 3) in3++;
			if (node->in.size() <= 4) in4++;
			if (node->in.size() <= 5) in5++;


			if ((node->in.size() == 1) && (node->out.size() > 1)) in1outx++;
			if ((node->out.size() == 1) && (node->in.size() > 1)) out1inx++;

			if (node->in.size() == 0) {
				if (node->out.size() == 1) {
					node->type = NODE_OUT1;
					out1++;
					if ((node->out[0]->in.size() == 1) && (node->out[0]->out.size() >= 1)) out1p++;
				}
				if (node->out.size() >= 1) {
					node->type = NODE_OUTX;
					outx++;
				}
			}
			else if (node->out.size() == 0) {
				if (node->in.size() == 1) {
					node->type = NODE_IN1;
					in1++;
					if ((node->in[0]->out.size() == 1) && (node->in[0]->in.size() >= 1)) in1p++;
				}
				if (node->in.size() >= 1) {
					node->type = NODE_INX;
					inx++;
				}
			}
			else if ((node->in.size() == 1) && (node->out.size() == 1)) {
				node->type = NODE_IN1OUT1;
				pt++;
			}

			uint32_t num = node->out.size() + node->in.size();
			if (num <= 4) upto4++;
			if (num <= 6) upto6++;
			if (num <= 8) upto8++;
			if (num <= 10) upto10++;
			if (num <= 12) upto12++;
		}

		/*cerr << "out2 = " << out2 << endl;
		cerr << "out3 = " << out3 << endl;
		cerr << "out4 = " << out4 << endl;
		cerr << "out5 = " << out5 << endl;
		cerr << "in2 = " << in2 << endl;
		cerr << "in3 = " << in3 << endl;
		cerr << "in4 = " << in4 << endl;
		cerr << "in5 = " << in5 << endl;*/

		/*cerr << "upto4 = " << upto4 << endl;
		cerr << "upto6 = " << upto6 << endl;
		cerr << "upto8 = " << upto8 << endl;
		cerr << "upto10 = " << upto10 << endl;
		cerr << "upto12 = " << upto12 << endl;

		cerr << "out1 = " << out1 << endl;
		cerr << "out1p = " << out1p << endl;
		cerr << "in1 = " << in1 << endl;
		cerr << "in1p = " << in1p << endl;
		cerr << "outx = " << outx << endl;
		cerr << "inx = " << inx << endl;
		cerr << "pt = " << pt << endl;
		cerr << "in1outx = " << in1outx << endl;
		cerr << "out1inx = " << out1inx << endl;*/

		// Create a node list which is sorted by the number of edges
		sortedNodeList.clear();
		for (auto nodePair : nodes)
		{
			SimpleNode *node = nodePair.second;
			if ((node->in.size() == 0) && (node->out.size() == 0)) continue;
			sortedNodeList.push_back(node);
		}
		//std::sort(sortedNodeList.begin(), sortedNodeList.end(), simpleNodeSortFunction);

		/*for (int i = 0; i < 10; i++) {
			cerr << "Node " << sortedNodeList[i]->externalId << " with inout = " << (sortedNodeList[i]->in.size() + sortedNodeList[i]->out.size()) << " edges" << endl;
		}*/
	}

	// op : 0 = equal , 1 = greater , 2 = less 
	void printInOutNodeThreshold(uint32_t threshold, int op = 0)
	{
		uint32_t inCount = 0, outCount = 0, inoutCountAnd = 0, inoutCountOr = 0;
		for (auto nodePair : nodes)
		{
			SimpleNode *node = nodePair.second;
			if (op == 0) {
				if (node->in.size() == threshold) inCount++;
				if (node->out.size() == threshold) outCount++;
				if ((node->in.size() == threshold) && (node->out.size() == threshold)) inoutCountAnd++;
				if ((node->in.size() == threshold) || (node->out.size() == threshold)) inoutCountOr++;
			}
			if (op == 1) {
				if (node->in.size() > threshold) inCount++;
				if (node->out.size() > threshold) outCount++;
				if ((node->in.size() > threshold) && (node->out.size() > threshold)) inoutCountAnd++;
				if ((node->in.size() > threshold) || (node->out.size() > threshold)) inoutCountOr++;
			}
			if (op == 2) {
				if (node->in.size() < threshold) inCount++;
				if (node->out.size() < threshold) outCount++;
				if ((node->in.size() < threshold) && (node->out.size() < threshold)) inoutCountAnd++;
				if ((node->in.size() < threshold) || (node->out.size() < threshold)) inoutCountOr++;
			}
		}

		if (op == 0) cerr << "Nodes with exactly " << threshold << " ingoing / outgoing edges" << endl;
		else if (op == 1) cerr << "Nodes with more than " << threshold << " ingoing / outgoing edges" << endl;
		else if (op == 2) cerr << "Nodes with less than " << threshold << " ingoing / outgoing edges" << endl;
		cerr << "  inCount = " << inCount << endl;
		cerr << "  outCount = " << outCount << endl;
		cerr << "  in & out = " << inoutCountAnd << endl;
		cerr << "  in | out = " << inoutCountOr << endl;
	}

	
};