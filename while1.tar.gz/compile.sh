#!/bin/bash

g++ src/main.cpp -o main -O3 -std=c++14 -pthread -lnuma -msse4.2 -DNUMA_ENABLED

