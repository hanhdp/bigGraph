#!/bin/bash

./main
