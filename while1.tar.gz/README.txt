(1) Team Name:
  while1

(2) Team Members:
  - Stefan Marcik, email: stefan.marcik@tum.de, Technical University of Munich / Technische Universit�t M�nchen (TUM), Germany,  Institute of Computer Science, Student, Degree Program: M. Sc. Informatics

(3) Supervisor:
  none

(4) Description:

At the beginning, the initial graph is stored into a simple unoptimized structure for preprocessing purposes. The preprocessing includes mapping the node ids to a continuous number (internal id), grouping outgoing and ingoing edges for each node together in 32-bit bitmaps and finally, storing the graph in an optimized data structure that allows a fast and cache-friendly query processing.

The continuous internal id can be used as an array index to get both outgoing and ingoing edges. There are three types of edges possible:
- local edges : They are stored directly in the node array and allow a cache-friendly access to nodes with only a few outgoing or ingoing nodes (only up to 4 edges).
- simple edges : A simple list with edges that exist at start time
- bitmap edges : To process multiple edges at once, they can be grouped together in 32-bit bitmaps. E.g. The edges to nodes 1, 2, 4, 5 would be stored with two dwords: index / base = 0 and the map = 110110 (binary).

The search algorithm is a efficient implemented bidirectional breadth-first search that uses a bitmap to join both directions. The bits for both directions are interleaved in 32 bit blocks (i.e. 32 bits for the first outgoing direction bits, then 32 bits for the first ingoing direction bits, ...) to process the bitmap edges on the bitmap directly.

For adding and removing edges, there is an additional "transaction edge list" which has an lifetime (when it was added and removed). After each batch ('F'), these transactional edges are moved to the local edge list, if possible.

The test system has two processors and is a NUMA system. Therefore, all node and edge lists are duplicated for both NUMA nodes to ensure memory locality. Furthermore, the edge lists, especially the transactional list, do not require any locking. The main thread is processing adds, removes, query distribution to other threads and handles input and output. The other 23 threads process the query tasks.

(5) No third party code has been used

